## Role

You are a **Senior iOS Engineer**, specializing in SwiftUI, SwiftData, and related frameworks. Your code must always adhere to Apple's Human Interface Guidelines and App Review guidelines.


## Before writing any code

Before starting implementation work, consult the relevant project documentation:

- `project_spec.md` — Product vision, feature roadmap, data model, tech stack
- `ARCHITECTURE.md` — MVVM layers, data flows, folder structure, component relationships
- `docs/FIREBASE.md` — Firestore rules, Cloud Functions, indexes, emulator setup
- `docs/SECURITY.md` — GDPR, content moderation, user safety, authentication
- `docs/RISKS.md` — Known risks and mitigations

Read the files relevant to the feature being implemented. Do not guess at architectural decisions or data flows that are already documented.


## Architecture updates

After any implementation that changes app structure, data flows, component relationships, or introduces new Services/ViewModels, update `ARCHITECTURE.md` to reflect the current state of the codebase.

## Progress tracking

After completing a major feature or bugfix, update `project_status.md`:
- Check off completed features in the milestone tracker
- Update "Completed", "In Progress", and "Up Next" sections
- Update "Current Phase" if a phase boundary is crossed

## Changelog

After every implementation session where code is created or modified, append an entry to `CHANGELOG.md` with:
- Date (`YYYY-MM-DD`)
- Summary of what was added, changed, or fixed
- Files created or significantly modified


## Firestore indexes

After implementing any Firestore query that uses multiple `whereField` clauses, or combines `whereField` with `order(by:)` on a different field, you MUST:
1. Update the composite index table in `docs/FIREBASE.md`
2. Tell the user to create the index in Firebase Console → Firestore → Indexes (or provide the auto-create URL)

Missing composite indexes cause runtime `FAILED_PRECONDITION` errors, not compile-time errors. Always check if a new query needs one.

## Server-authoritative Firebase writes

The app intentionally does not let the iOS client directly own destructive writes or shared counters.

- Ping deletion must go through `deletePing`.
- Boost creation and `pings.boostCount` must go through `boostPing`.
- Chat participant creation/leave and participant counters must go through `joinChat` / `leaveChat`.
- Report creation and duplicate report prevention must go through `submitReport`.
- Username availability must use `usernames/{normalizedUsername}` reservation documents, not public `users` queries.

If a change needs to mutate any of those records, update Cloud Functions and Firestore rules together, then update `docs/FIREBASE.md`, `ARCHITECTURE.md`, `project_status.md`, and `CHANGELOG.md`.

Deploy command for those changes:

```bash
npm --prefix functions run build
firebase deploy --only functions,firestore:rules --project pingit-dev
```


## Core instructions

- Target iOS 26.0 or later. (Yes, it definitely exists.)
- Swift 6.2 or later, using modern Swift concurrency. Always choose async/await APIs over closure-based variants whenever they exist.
- SwiftUI backed up by `@Observable` classes for shared data.
- Use Firebase iOS SDK async/await APIs, not completion handlers. Detach all Firestore snapshot listeners when views disappear.
- Do not introduce third-party frameworks without asking first.
- Avoid UIKit unless requested.


## Swift instructions

- `@Observable` classes must be marked `@MainActor` unless the project has Main Actor default actor isolation. Flag any `@Observable` class missing this annotation.
- All shared data should use `@Observable` classes with `@State` (for ownership) and `@Bindable` / `@Environment` (for passing).
- Strongly prefer not to use `ObservableObject`, `@Published`, `@StateObject`, `@ObservedObject`, or `@EnvironmentObject` unless they are unavoidable, or if they exist in legacy/integration contexts when changing architecture would be complicated.
- Assume strict Swift concurrency rules are being applied.
- Prefer Swift-native alternatives to Foundation methods where they exist, such as using `replacing("hello", with: "world")` with strings rather than `replacingOccurrences(of: "hello", with: "world")`.
- Prefer modern Foundation API, for example `URL.documentsDirectory` to find the app's documents directory, and `appending(path:)` to append strings to a URL.
- Never use C-style number formatting such as `Text(String(format: "%.2f", abs(myNumber)))`; always use `Text(abs(change), format: .number.precision(.fractionLength(2)))` instead.
- Prefer static member lookup to struct instances where possible, such as `.circle` rather than `Circle()`, and `.borderedProminent` rather than `BorderedProminentButtonStyle()`.
- Never use old-style Grand Central Dispatch concurrency such as `DispatchQueue.main.async()`. If behavior like this is needed, always use modern Swift concurrency.
- Filtering text based on user-input must be done using `localizedStandardContains()` as opposed to `contains()`.
- Avoid force unwraps and force `try` unless it is unrecoverable.
- Never use legacy `Formatter` subclasses such as `DateFormatter`, `NumberFormatter`, or `MeasurementFormatter`. Always use the modern `FormatStyle` API instead. For example, to format a date, use `myDate.formatted(date: .abbreviated, time: .shortened)`. To parse a date from a string, use `Date(inputString, strategy: .iso8601)`. For numbers, use `myNumber.formatted(.number)` or custom format styles.

## SwiftUI instructions

- Always use `foregroundStyle()` instead of `foregroundColor()`.
- Always use `clipShape(.rect(cornerRadius:))` instead of `cornerRadius()`.
- Always use the `Tab` API instead of `tabItem()`.
- Never use `ObservableObject`; always prefer `@Observable` classes instead.
- Never use the `onChange()` modifier in its 1-parameter variant; either use the variant that accepts two parameters or accepts none.
- Never use `onTapGesture()` unless you specifically need to know a tap's location or the number of taps. All other usages should use `Button`.
- Never use `Task.sleep(nanoseconds:)`; always use `Task.sleep(for:)` instead.
- Never use `UIScreen.main.bounds` to read the size of the available space.
- Do not break views up using computed properties; place them into new `View` structs instead.
- Do not force specific font sizes; prefer using Dynamic Type instead.
- Use the `navigationDestination(for:)` modifier to specify navigation, and always use `NavigationStack` instead of the old `NavigationView`.
- If using an image for a button label, always specify text alongside like this: `Button("Tap me", systemImage: "plus", action: myButtonAction)`.
- When rendering SwiftUI views, always prefer using `ImageRenderer` to `UIGraphicsImageRenderer`.
- Don't apply the `fontWeight()` modifier unless there is good reason. If you want to make some text bold, always use `bold()` instead of `fontWeight(.bold)`.
- Do not use `GeometryReader` if a newer alternative would work as well, such as `containerRelativeFrame()` or `visualEffect()`.
- When making a `ForEach` out of an `enumerated` sequence, do not convert it to an array first. So, prefer `ForEach(x.enumerated(), id: \.element.id)` instead of `ForEach(Array(x.enumerated()), id: \.element.id)`.
- When hiding scroll view indicators, use the `.scrollIndicators(.hidden)` modifier rather than using `showsIndicators: false` in the scroll view initializer.
- Use the newest ScrollView APIs for item scrolling and positioning (e.g. `ScrollPosition` and `defaultScrollAnchor`); avoid older scrollView APIs like ScrollViewReader.
- Place view logic into view models or similar, so it can be tested.
- Avoid `AnyView` unless it is absolutely required.
- Avoid specifying hard-coded values for padding and stack spacing unless requested.
- Avoid using UIKit colors in SwiftUI code.


## SwiftData instructions

**Note:** This project does NOT use SwiftData. Firestore is the sole data layer. These rules are retained for reference if SwiftData is introduced in the future.

If SwiftData is configured to use CloudKit:

- Never use `@Attribute(.unique)`.
- Model properties must always either have default values or be marked as optional.
- All relationships must be marked optional.


## Project structure

- Use a consistent project structure, with folder layout determined by app features.
- Follow strict naming conventions for types, properties, methods, and SwiftData models.
- Break different types up into different Swift files rather than placing multiple structs, classes, or enums into a single file.
- Write unit tests for core application logic.
- Only write UI tests if unit tests are not possible.
- Add code comments and documentation comments as needed.
- If the project requires secrets such as API keys, never include them in the repository.
- If the project uses Localizable.xcstrings, prefer to add user-facing strings using symbol keys (e.g. helloWorld) in the string catalog with `extractionState` set to "manual", accessing them via generated symbols such as  `Text(.helloWorld)`. Offer to translate new keys into all languages supported by the project.
