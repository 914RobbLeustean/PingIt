# Phase 1: Safety & Discovery — Design Spec

**Date:** 2026-04-14
**Author:** Robert Leustean + Claude
**Status:** Approved
**Scope:** 19 items (16 spec features + 2 additions: ping expiration cleanup, ping clustering + 1 infrastructure task: Cloud Functions setup)

---

## Context

Phase 0 MVP is complete (14/14 features). The app supports registration, login, map display, ping creation, chat, and profile management. All services have protocol abstractions with mock implementations and ~40 ViewModel unit tests.

Phase 1 makes the app **App Store-ready** by adding content moderation, user safety features, engagement mechanics, push notifications, and GDPR compliance. The admin review workflow uses Firebase Console directly (no custom web dashboard).

**Timeline:** Must be complete before July 1, 2026 thesis deadline.

**Constraints:**
- Firebase project is live with data, but no Cloud Functions deployed yet
- Must test on physical iPhone (Netskope blocks simulator networking)
- Apple Developer account available; APNs setup needs guided configuration

---

## Implementation Strategy

### Sprint Ordering: Dependency-Based

Features are grouped by **dependency chains**, not spec categories. This minimizes context-switching between iOS and backend work.

| Sprint | Theme | Features | Type |
|--------|-------|----------|------|
| 1 | Foundation Safety | 7 features | iOS-only |
| 2 | Engagement + Map Polish | 5 features | iOS-only |
| 3 | Cloud Functions + Notifications | 5 features | Full-stack |
| 4 | Moderation Pipeline | 2 features | Backend-only |

### Priority: App Store Readiness First

Safety/compliance features ship before engagement features. This ensures the app can pass App Store review gates at the earliest possible point.

---

## Sprint 1: Foundation Safety (iOS-Only)

### 1.1 Email Verification

**What:** After registration, users must verify their email before creating pings or sending chat messages. Unverified users can browse the map and view pings.

**Behavior:**
- Verification email sent automatically after registration via `FirebaseAuth.User.sendEmailVerification()`
- Map screen shows persistent banner: "Verify your email to create pings" with "Resend" button
- Create Ping button disabled (grayed out) for unverified users
- Chat input shows "Verify your email to chat" placeholder, send disabled
- On app foreground / manual refresh: `user.reload()` refreshes verification status
- Settings screen shows verification status with resend option

**Implementation:**
- `AuthServicing` gains: `sendEmailVerification()`, `reloadUser()`
- `AuthService.isEmailVerified: Bool` computed from `FirebaseAuth.User.isEmailVerified`
- Verification gate in `CreatePingViewModel.createPing()` and `ChatViewModel.sendMessage()`
- New `EmailVerificationBannerView` component
- Gate logic lives in ViewModels (not Views) — clean MVVM

**Files:**
- Modify: `AuthServicing.swift`, `AuthService.swift`, `MockAuthService.swift`
- Modify: `CreatePingViewModel.swift`, `ChatViewModel.swift`
- Create: `Features/Map/Views/EmailVerificationBannerView.swift`
- Modify: `MapView.swift` (add banner)
- Modify: `SettingsPlaceholderView.swift` (add verification status)

---

### 1.2 Text Content Moderation

**What:** Client-side keyword filter scans ping text and chat messages before submission. Blocks content matching a profanity/hate speech word list.

**Behavior:**
- On submit: text checked against bundled word list
- If flagged: submission blocked, error shown: "This message violates community guidelines"
- No preview filtering (don't filter as user types)
- Case-insensitive matching via `localizedStandardContains()`

**Implementation:**
- New `ContentModerationService` conforming to `ContentModeratingServicing` protocol
- Word list bundled as `Resources/moderation_wordlist.txt`
- Method: `func check(_ text: String) -> ContentModerationResult` (`.allowed` or `.blocked(reason:)`)
- Injected into `CreatePingViewModel` and `ChatViewModel`
- Server-side validation planned for Sprint 3 (client can be bypassed)

**Files:**
- Create: `Core/Protocols/ContentModeratingServicing.swift`
- Create: `Core/Services/ContentModerationService.swift`
- Create: `Resources/moderation_wordlist.txt`
- Create: `PingItTests/Mocks/MockContentModerationService.swift`
- Modify: `CreatePingViewModel.swift`, `ChatViewModel.swift`
- Modify: `PingItApp.swift` (environment injection)

---

### 1.3 User Blocking

**What:** Users can block other users. **Bidirectional** — neither user sees the other's content (pings, messages, profile info).

**Behavior:**
- Block from: PingDetailView (context menu), ChatView (message long-press), ProfileView
- Confirmation: "Block @username? You won't see their pings or messages."
- Immediate local effect (content filtered out)
- Bidirectional: if A blocks B, neither sees the other

**Implementation:**
- New `BlockService` conforming to `BlockServicing` protocol
- Firestore `blocks` collection: `{ blockId, blockerId, blockedUserId, createdAt }`
- Two documents per block action (A→B and B→A) for fast bidirectional querying
- `blockedUserIds: Set<String>` loaded on app launch, kept in memory on `BlockService`
- Methods: `blockUser(_:)`, `unblockUser(_:)`, `fetchBlockedUsers()`, `isBlocked(_:) -> Bool`
- Denormalized `blockedUsers[]` array on user document for Firestore security rules
- `MapViewModel` filters pings where `creatorId` is in blocked set
- `ChatViewModel` filters messages where `senderId` is in blocked set
- `PingDetailView` hides detail if creator is blocked

**Files:**
- Create: `Core/Models/Block.swift`
- Create: `Core/Protocols/BlockServicing.swift`
- Create: `Core/Services/BlockService.swift`
- Create: `PingItTests/Mocks/MockBlockService.swift`
- Modify: `MapViewModel.swift`, `ChatViewModel.swift`, `PingDetailViewModel.swift`
- Modify: `PingDetailView.swift`, `ChatView.swift` (context menus)
- Modify: `PingItApp.swift` (environment injection)

---

### 1.4 Blocked Users Management

**What:** Settings screen listing all blocked users with unblock ability.

**Behavior:**
- Settings → "Blocked Users" → `BlockedUsersView`
- List: username, profile picture, "Unblock" button per row
- Unblock confirmation: "Unblock @username? You'll see their content again."
- Empty state: "You haven't blocked anyone"

**Implementation:**
- `BlockedUsersViewModel` fetches blocked users via `BlockService`, loads `User` profiles
- Unblock removes from list with animation

**Files:**
- Create: `Features/Settings/ViewModels/BlockedUsersViewModel.swift`
- Create: `Features/Settings/Views/BlockedUsersView.swift`
- Modify: `SettingsPlaceholderView.swift` (add navigation link)

---

### 1.5 User Report System

**What:** Users can report a ping or chat message. Creates a `reports` document in Firestore for admin review via Firebase Console.

**Behavior:**
- Context menu on ping annotations and chat messages includes "Report"
- Report sheet: reason picker (Spam / Harassment / Inappropriate Content / Other) + optional text
- Submit → confirmation: "Thanks for reporting. We'll review this within 72 hours."
- After reporting, offer: "Would you also like to block this user?"
- Cannot report own content

**Implementation:**
- New `Report` model matching Firestore `reports` schema
- New `ReportService` conforming to `ReportServicing` protocol
- Method: `submitReport(targetType:targetId:reason:details:)`
- `ReportViewModel` handles form state + block offer flow
- `ReportView` as `.sheet` presented from context menus

**Files:**
- Create: `Core/Models/Report.swift`
- Create: `Core/Protocols/ReportServicing.swift`
- Create: `Core/Services/ReportService.swift`
- Create: `Features/Report/ViewModels/ReportViewModel.swift`
- Create: `Features/Report/Views/ReportView.swift`
- Create: `PingItTests/Mocks/MockReportService.swift`
- Modify: `PingAnnotationView.swift`, `MessageBubbleView.swift` (context menus)

---

### 1.6 Spam Detection (Client-Side Rate Limiting)

**What:** Prevents rapid-fire ping creation and message spamming. Shows cooldown UI when limits hit.

**Behavior:**
- Ping creation: max 5/hour, 10/day
- Chat messages: max 6 per 10 seconds
- When limited: button disabled, shows countdown: "You can create another ping in X minutes"
- Timestamps stored in UserDefaults
- Server-side enforcement in Sprint 3

**Debug bypass:**
```swift
#if DEBUG
return .allowed
#endif
```

**Implementation:**
- New `RateLimitService` conforming to `RateLimitServicing` protocol
- Methods: `canCreatePing() -> RateLimitResult`, `canSendMessage() -> RateLimitResult`
- `RateLimitResult`: `.allowed` or `.limited(retryAfter: TimeInterval)`
- Stores `[Date]` arrays in UserDefaults, pruned on check
- Integrates into `CreatePingViewModel` and `ChatViewModel`

**Files:**
- Create: `Core/Protocols/RateLimitServicing.swift`
- Create: `Core/Services/RateLimitService.swift`
- Create: `PingItTests/Mocks/MockRateLimitService.swift`
- Modify: `CreatePingViewModel.swift`, `ChatViewModel.swift`

---

### 1.7 Client-Side Expired Ping Filtering

**What:** MapViewModel filters out pings where `expiresAt < Date.now` before displaying on map. Quick win until the Cloud Function cron (Sprint 3) cleans up Firestore.

**Implementation:**
- One-line filter in MapViewModel's ping listener callback
- Uses existing `Date+Extensions` for time comparison

**Files:**
- Modify: `MapViewModel.swift`

---

## Sprint 2: Engagement + Map Polish (iOS-Only)

### 2.1 Boost Ping

**What:** Any user can boost any active ping once. Boosts increase visibility and feed into the Hot Pings algorithm.

**Behavior:**
- PingDetailView shows boost button (flame icon) with current count
- Tap → animates (fills in, count increments), writes to Firestore
- Already boosted → button shown as filled/active
- Cannot boost own pings
- No un-boost (permanent for ping's lifetime)

**Implementation:**
- **Separate `boosts` collection** (not array on ping document) — prevents double-boost, scales properly
- Firestore: `boosts/{boostId}`: `{ pingId, userId, createdAt }`
- `Ping` model gains: `boostCount: Int` (denormalized for display)
- `PingServicing` gains: `boostPing(_:)`, `hasUserBoostedPing(_:userId:) -> Bool`
- Atomic batch write: create boost doc + increment `pings/{pingId}.boostCount`
- `PingDetailViewModel` manages boost state

**Files:**
- Create: `Core/Models/Boost.swift`
- Modify: `Core/Models/Ping.swift` (add `boostCount`)
- Modify: `PingServicing.swift`, `PingService.swift`, `MockPingService.swift`
- Modify: `PingDetailViewModel.swift`, `PingDetailView.swift`

---

### 2.2 Hot Pings Algorithm

**What:** Ranks pings by engagement. Formula: `hotScore = boostCount * 2 + participantCount + hoursRemaining * 0.5`

**Behavior:**
- Hot pings (top 10% or hotScore > threshold) get visual treatment on map: larger annotation, glow/color shift
- Computed client-side (too volatile to store)
- Feeds into cluster priority (see 2.3)

**Implementation:**
- `Ping` model gains computed property: `var hotScore: Double`
- `MapViewModel` sorts pings by hotScore for display priority
- `PingAnnotationView` receives `isHot: Bool` for visual differentiation
- Threshold: a ping is "hot" if its hotScore >= 5.0 AND it's in the top 10 active pings by score. Both conditions must be true (prevents low-score pings from being "hot" when few pings exist).

**Files:**
- Modify: `Core/Models/Ping.swift` (add `hotScore`, `participantCount` if missing)
- Modify: `MapViewModel.swift` (hot ping calculation)
- Modify: `PingAnnotationView.swift` (hot visual treatment)

---

### 2.3 Ping Clustering

**What:** Groups nearby pings into clusters at low zoom levels. Zooming in reveals individual pins.

**Behavior:**
- Zoomed out: circular cluster markers with ping count
- Cluster color reflects hottest ping inside
- Tap cluster → map zooms to show individual pins
- Zoomed in: individual PingAnnotationView markers
- Smooth MapKit-managed transitions

**Implementation:**
- SwiftUI `Map` with `MapContentBuilder` (iOS 17+ API)
- Annotations get `.clusteringIdentifier("ping")`
- New `PingClusterAnnotationView` for cluster appearance
- MapKit handles clustering logic automatically
- Cluster view shows count badge + hot indicator if contains hot ping

**Files:**
- Create: `Features/Map/Views/PingClusterAnnotationView.swift`
- Modify: `MapView.swift` (clustering configuration)
- Modify: `PingAnnotationView.swift` (add clustering identifier)

---

### 2.4 Privacy Settings (Toggle Only — Enforcement in Phase 2)

**What:** Toggle for "Private Profile" mode. In Phase 1: UI + data storage only. In Phase 2: enforced when follow system and user profiles exist (hides profile picture, shows pseudonym to non-followers).

**Behavior:**
- Settings → "Privacy" → "Private Profile" toggle
- Toggle saved to Firestore on user document
- No enforcement in Phase 1 (no follower system yet)

**Implementation:**
- `User` model gains: `isPrivateProfile: Bool` (default `false`)
- Settings screen expanded with privacy section

**Files:**
- Modify: `Core/Models/User.swift`
- Modify: `SettingsPlaceholderView.swift` (or new `PrivacySettingsView.swift`)

---

### 2.5 Notification Preferences (Toggle Only — Delivery in Sprint 3)

**What:** Toggles for push notification categories. UI exists now, delivery logic reads these in Sprint 3.

**Behavior:**
- Settings → "Notifications" → toggles for "Nearby Pings" and "Hot Pings"
- Default: both on
- Saved to Firestore on user document

**Implementation:**
- `User` model gains: `notifyNearbyPings: Bool`, `notifyHotPings: Bool` (defaults `true`)
- Settings screen expanded with notification section

**Files:**
- Modify: `Core/Models/User.swift`
- Modify: `SettingsPlaceholderView.swift`

---

## Sprint 3: Cloud Functions + Notifications (Full-Stack)

### 3.1 Cloud Functions Setup

**What:** Initialize Firebase Cloud Functions (TypeScript), deploy first function.

**Deliverables:**
- `firebase init functions` with TypeScript
- `functions/` directory with `package.json`, `tsconfig.json`, `src/index.ts`
- Environment variables: Vision API key, admin emails
- First successful deployment to verify pipeline

---

### 3.2 Ping Expiration Cloud Function

**What:** Cron function runs every 5 minutes. Finds expired pings, updates status, deletes associated data.

**Implementation (TypeScript):**
```
expirePings (pubsub.schedule: every 5 minutes)
  → Query: pings where expiresAt <= now AND status == "active"
  → For each expired ping (batched, max 500 ops per batch):
    → Update ping.status = "expired"
    → Delete chat document
    → Delete all chatMessages for that chat
    → Delete all chatParticipants for that chat
```

**Note:** Client-side filtering (Sprint 1) already hides expired pings from users. This function is for Firestore data hygiene.

---

### 3.3 GDPR Account Deletion

**What:** User-initiated cascading delete of all user data via callable Cloud Function.

**iOS behavior:**
- Settings → "Delete Account" (red button, bottom of screen)
- Confirmation dialog with warning text
- Re-authentication required (password prompt)
- Loading → success → returns to Welcome screen

**Cloud Function (callable):**
```
deleteAccount
  → Verify caller == account owner
  → Delete: all pings by user (+ their chats/messages/participants)
  → Delete: all chat messages sent by user
  → Delete: all chatParticipant records for user
  → Delete: all boosts by user
  → Delete: all blocks by/against user
  → Delete: all reports by user
  → Delete: profile image from Storage
  → Delete: user document from Firestore
  → Delete: Firebase Auth account
```

**iOS implementation:**
- `AuthServicing` gains: `deleteAccount()`, `reauthenticate(password:)`
- Settings screen gains delete account section

**Files:**
- Create: `functions/src/deleteAccount.ts`
- Modify: `AuthServicing.swift`, `AuthService.swift`, `MockAuthService.swift`
- Modify: `SettingsPlaceholderView.swift`

---

### 3.4 Nearby Ping Notifications

**What:** Push notification when new ping created within 2km of a user.

**Prerequisites:**
- APNs key (`.p8`) from Apple Developer portal → configured in Firebase Console
- iOS: notification permission request, FCM token registration

**Cloud Function (Firestore trigger: pings onCreate):**
```
sendNearbyNotification
  → Read new ping location
  → Query users within 2km (geohash proximity)
  → Filter out: creator, blocked users, users with notifyNearbyPings=false
  → Send FCM: { title: "New ping nearby!", body: ping.text (truncated 50 chars), data: { pingId } }
```

**iOS implementation:**
- New `NotificationService` conforming to `NotificationServicing` protocol
- Registers FCM token on launch → stores in `users/{uid}.fcmToken`
- `UNUserNotificationCenter` delegate for foreground display + tap handling
- Notification tap → navigates to PingDetailView via deep link

**Files:**
- Create: `Core/Protocols/NotificationServicing.swift`
- Create: `Core/Services/NotificationService.swift`
- Create: `functions/src/sendNearbyNotification.ts`
- Modify: `PingItApp.swift` (notification setup, FCM token)
- Modify: `User.swift` (add `fcmToken` field)

---

### 3.5 Hot Ping Notifications

**What:** Push notification when a ping enters the top 10 by hotScore.

**Cloud Function (Firestore trigger: boosts onCreate OR chatParticipants onCreate):**
```
sendHotPingNotification
  → Recalculate hotScore for affected ping
  → Query all active pings, compute top 10
  → If this ping is newly in top 10:
    → Query users with notifyHotPings=true (exclude creator, blocked)
    → Send FCM: { title: "Trending ping!", body: ping.text, data: { pingId } }
```

**Files:**
- Create: `functions/src/sendHotPingNotification.ts`

---

## Sprint 4: Moderation Pipeline (Backend)

### 4.1 Automated Image Filtering

**What:** Cloud Function triggered on Storage upload. Calls Vision API SafeSearch. Auto-removes VERY_LIKELY inappropriate content.

**Current trigger paths:** Profile picture uploads (live now). Ping image uploads (Phase 2).

**Cloud Function (Storage trigger: objects.finalize):**
```
moderateImage
  → path: profile_pictures/** OR ping_images/**
  → Call Vision API SafeSearch
  → If adult/violence/racy == VERY_LIKELY:
    → Delete image from Storage
    → If ping image: update ping.status = "removed"
    → If profile pic: clear user.profileImageUrl
    → Create moderationActions audit document
  → If LIKELY:
    → Create report with status "pending_review"
```

**Files:**
- Create: `functions/src/moderateImage.ts`

---

### 4.2 Emergency Content Removal

**What:** Admin-callable function to immediately remove any content.

**Cloud Function (callable, admin-only):**
```
removeContent
  → Verify caller email in admin list (environment variable)
  → targetType "ping": set status "removed", delete chat
  → targetType "message": delete message document
  → targetType "user": suspend user (set suspensionStatus)
  → Create moderationActions audit document
```

**Admin workflow document:** Step-by-step guide for reviewing `reports` collection in Firebase Console and calling `removeContent` via Firebase CLI.

**Files:**
- Create: `functions/src/removeContent.ts`
- Create: `docs/ADMIN_MODERATION_RUNBOOK.md`

---

## New Services Summary

| Service | Protocol | Purpose |
|---------|----------|---------|
| `ContentModerationService` | `ContentModeratingServicing` | Client-side text filter |
| `BlockService` | `BlockServicing` | Block/unblock users |
| `ReportService` | `ReportServicing` | Submit content reports |
| `RateLimitService` | `RateLimitServicing` | Client-side rate limiting |
| `NotificationService` | `NotificationServicing` | FCM token + notification handling |

## New Models

| Model | Collection | Key Fields |
|-------|-----------|------------|
| `Block` | `blocks` | blockerId, blockedUserId, createdAt |
| `Report` | `reports` | reporterId, targetType, targetId, reason, status |
| `Boost` | `boosts` | pingId, userId, createdAt |

## Modified Models

| Model | New Fields |
|-------|-----------|
| `User` | `isPrivateProfile`, `notifyNearbyPings`, `notifyHotPings`, `fcmToken` |
| `Ping` | `boostCount`, computed `hotScore` |

## Cloud Functions Summary

| Function | Trigger | Sprint |
|----------|---------|--------|
| `expirePings` | Scheduled (every 5 min) | 3 |
| `deleteAccount` | Callable (auth required) | 3 |
| `sendNearbyNotification` | Firestore: pings onCreate | 3 |
| `sendHotPingNotification` | Firestore: boosts/participants onCreate | 3 |
| `moderateImage` | Storage: objects.finalize | 4 |
| `removeContent` | Callable (admin-only) | 4 |

---

## Verification Plan

### Sprint 1 Verification
- Create account → receive verification email → verify → can create pings
- Type profanity in ping/chat → blocked with error message
- Block a user → their pings/messages disappear from map/chat
- View blocked users in settings → unblock → content reappears
- Report a ping/message → confirm report document in Firestore Console
- Rapid-fire ping creation → rate limit error after 5th ping (release build only)
- Expired pings no longer visible on map

### Sprint 2 Verification
- Boost a ping → count increments, button shows boosted state
- Cannot boost own ping, cannot boost twice
- Hot pings show visual differentiation on map
- Zoom out → pings cluster. Zoom in → individual pins
- Privacy and notification toggles save to Firestore

### Sprint 3 Verification
- Deploy Cloud Functions → verify in Firebase Console
- Create ping with 1-minute expiration → wait → confirm deleted from Firestore
- Delete account → verify all user data removed from all collections + Storage + Auth
- Create ping → nearby user receives push notification
- Boost ping into top 10 → users receive hot ping notification

### Sprint 4 Verification
- Upload inappropriate profile picture → auto-removed within 30 seconds
- Call `removeContent` via Firebase CLI → content removed, audit trail created
- Admin runbook tested end-to-end

---

## Design Decisions Log

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Sprint ordering | Dependency-based, not thematic | Minimizes context switching; ships safety features first |
| Admin dashboard | Firebase Console (no custom UI) | Thesis scope — <500 users don't need custom admin UI |
| Blocking | Bidirectional | Stronger user protection; both users hidden from each other |
| Boost storage | Separate collection (not array on ping) | Scales properly, prevents double-boost via Firestore rules |
| Report flow | Offer block after report | Gives user control without forcing auto-block |
| Privacy settings | Toggle + storage only (Phase 1) | No follower system yet; enforcement ships with Phase 2 |
| Notification prefs | Toggle + storage only (Sprint 2) | Push notification delivery ships in Sprint 3 |
| Rate limiting debug | `#if DEBUG` bypass | Developer can test freely; release builds enforce limits |
| Preferences storage | Fields on `users` document | One read gets everything; separate collection adds complexity without benefit at this scale |
| Cloud Functions language | TypeScript | Type safety, better IDE support, standard for new Firebase projects |
| Hot score computation | Client-side only | Too volatile to store; changes on every boost/join |
| Map clustering | SwiftUI MapContentBuilder | Stays fully SwiftUI; no UIKit wrapper needed |
| Expired ping handling | Client filter now + Cloud Function cron later | Immediate UX fix + eventual Firestore data hygiene |
