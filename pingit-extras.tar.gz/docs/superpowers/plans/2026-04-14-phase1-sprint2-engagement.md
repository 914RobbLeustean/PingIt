# Phase 1 Sprint 2: Engagement + Map Polish — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add engagement features (boost, hot pings algorithm, ping clustering) and settings toggles (privacy, notifications) to make the map more compelling.

**Architecture:** All 5 features are iOS-only. Boost uses a separate Firestore `boosts` collection with denormalized count on ping documents. Hot pings algorithm is computed client-side. Clustering uses SwiftUI MapContentBuilder. Settings toggles store preferences on user documents.

**Tech Stack:** Swift 6.2, SwiftUI, MapKit, Firestore, Swift Testing

**Design Spec:** `docs/superpowers/specs/2026-04-14-phase1-safety-discovery-design.md` (Sprint 2 section)

**Prerequisite:** Sprint 1 complete (blocking, moderation, email verification, rate limiting all integrated)

---

## Task 1: Boost Model & PingService Extension

**Files:**
- Create: `PingIt/Core/Models/Boost.swift`
- Modify: `PingIt/Core/Models/Ping.swift`
- Modify: `PingIt/Core/Protocols/PingServicing.swift`
- Modify: `PingIt/Core/Services/PingService.swift`
- Modify: `PingItTests/Mocks/MockPingService.swift`

- [ ] **Step 1: Create Boost model**

```swift
import Foundation
import FirebaseFirestore

struct Boost: Codable, Identifiable, Sendable {
    @DocumentID var id: String?
    var pingId: String
    var userId: String
    @ServerTimestamp var createdAt: Date?
}
```

- [ ] **Step 2: Add boostCount and hotScore to Ping model**

Read `PingIt/Core/Models/Ping.swift`. Add field:

```swift
var boostCount: Int = 0
var participantCount: Int = 0
```

Add computed property (outside the enum, inside the struct):

```swift
var hotScore: Double {
    Double(boostCount) * 2.0 + Double(participantCount) + max(0, expiresAt.timeIntervalSinceNow / 3600.0) * 0.5
}

var isHot: Bool {
    hotScore >= 5.0
}
```

- [ ] **Step 3: Add boost methods to PingServicing**

Read `PingIt/Core/Protocols/PingServicing.swift`. Add:

```swift
func boostPing(pingId: String) async throws
func hasUserBoostedPing(pingId: String, userId: String) async throws -> Bool
```

- [ ] **Step 4: Implement boost in PingService**

Read `PingIt/Core/Services/PingService.swift`. Add:

```swift
func boostPing(pingId: String) async throws {
    guard let userId = Auth.auth().currentUser?.uid else {
        throw PingItError.notAuthenticated
    }

    let db = Firestore.firestore()
    let batch = db.batch()

    // Create boost document
    let boostRef = db.collection(Constants.Firestore.boostsCollection).document()
    let boost = Boost(pingId: pingId, userId: userId)
    try batch.setData(from: boost, forDocument: boostRef)

    // Increment denormalized count
    let pingRef = db.collection(Constants.Firestore.pingsCollection).document(pingId)
    batch.updateData(["boostCount": FieldValue.increment(Int64(1))], forDocument: pingRef)

    try await batch.commit()
}

func hasUserBoostedPing(pingId: String, userId: String) async throws -> Bool {
    let db = Firestore.firestore()
    let snapshot = try await db
        .collection(Constants.Firestore.boostsCollection)
        .whereField("pingId", isEqualTo: pingId)
        .whereField("userId", isEqualTo: userId)
        .limit(to: 1)
        .getDocuments()

    return !snapshot.documents.isEmpty
}
```

- [ ] **Step 5: Update MockPingService**

Read `PingItTests/Mocks/MockPingService.swift`. Add:

```swift
var boostPingCalled = false
var hasUserBoostedPingResult = false
var lastBoostedPingId: String?

func boostPing(pingId: String) async throws {
    boostPingCalled = true
    lastBoostedPingId = pingId
    if let error = errorToThrow { throw error }
}

func hasUserBoostedPing(pingId: String, userId: String) async throws -> Bool {
    if let error = errorToThrow { throw error }
    return hasUserBoostedPingResult
}
```

- [ ] **Step 6: Build to verify compilation**

Run: `xcodebuild build -scheme PingIt -destination 'generic/platform=iOS' -quiet`
Expected: BUILD SUCCEEDED

- [ ] **Step 7: Commit**

```bash
git add PingIt/Core/Models/Boost.swift PingIt/Core/Models/Ping.swift PingIt/Core/Protocols/PingServicing.swift PingIt/Core/Services/PingService.swift PingIt/Core/Utilities/Constants.swift PingItTests/Mocks/MockPingService.swift
git commit -m "feat: add Boost model, boostCount/hotScore on Ping, and boost methods"
```

---

## Task 2: Boost UI in PingDetailView

**Files:**
- Modify: `PingIt/Features/Ping/ViewModels/PingDetailViewModel.swift`
- Modify: `PingIt/Features/Ping/Views/PingDetailView.swift`
- Test: `PingItTests/ViewModelTests/PingDetailViewModelTests.swift`

- [ ] **Step 1: Write failing test for boost**

In `PingDetailViewModelTests.swift`:

```swift
@Test("Boost ping succeeds")
func boostPingSucceeds() async {
    let ping = Ping(
        creatorId: "other_user",
        text: "Test",
        location: .init(latitude: 46.77, longitude: 23.62),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(3600),
        status: .active,
        boostCount: 0
    )
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockPing = MockPingService()
    mockPing.hasUserBoostedPingResult = false
    let mockChat = MockChatService()
    let mockUser = MockUserService()

    let vm = PingDetailViewModel(ping: ping)
    vm.configure(authService: mockAuth, pingService: mockPing, chatService: mockChat, userService: mockUser)

    await vm.checkBoostStatus()
    #expect(vm.hasUserBoosted == false)

    await vm.boostPing()
    #expect(mockPing.boostPingCalled == true)
    #expect(vm.hasUserBoosted == true)
}

@Test("Cannot boost own ping")
func cannotBoostOwnPing() async {
    let ping = Ping(
        creatorId: "user1",
        text: "My ping",
        location: .init(latitude: 46.77, longitude: 23.62),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(3600),
        status: .active
    )
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockPing = MockPingService()
    let mockChat = MockChatService()
    let mockUser = MockUserService()

    let vm = PingDetailViewModel(ping: ping)
    vm.configure(authService: mockAuth, pingService: mockPing, chatService: mockChat, userService: mockUser)

    #expect(vm.canBoost == false)
}
```

- [ ] **Step 2: Add boost state to PingDetailViewModel**

Read `PingIt/Features/Ping/ViewModels/PingDetailViewModel.swift`. Add properties:

```swift
private(set) var hasUserBoosted = false
private(set) var isBoosting = false

var canBoost: Bool {
    !isCreator && !hasUserBoosted && !isBoosting
}
```

Add methods:

```swift
func checkBoostStatus() async {
    guard let pingService, let authService,
          let userId = authService.currentUser?.uid,
          let pingId = ping.id else { return }
    do {
        hasUserBoosted = try await pingService.hasUserBoostedPing(pingId: pingId, userId: userId)
    } catch {
        // Silently fail — default to not boosted
    }
}

func boostPing() async {
    guard let pingService, let pingId = ping.id, canBoost else { return }
    isBoosting = true
    defer { isBoosting = false }

    do {
        try await pingService.boostPing(pingId: pingId)
        hasUserBoosted = true
    } catch {
        errorMessage = error.localizedDescription
    }
}
```

- [ ] **Step 3: Run tests**

Run: `swift test --filter PingDetailViewModelTests`
Expected: All PASS

- [ ] **Step 4: Add boost button to PingDetailView**

Read `PingIt/Features/Ping/Views/PingDetailView.swift`. In `PingDetailActionSection` (or directly in PingDetailView), add a boost button:

```swift
if !viewModel.isCreator {
    Button(action: { Task { await viewModel.boostPing() } }) {
        Label(
            viewModel.hasUserBoosted ? "Boosted" : "Boost",
            systemImage: viewModel.hasUserBoosted ? "flame.fill" : "flame"
        )
    }
    .disabled(!viewModel.canBoost)
    .tint(viewModel.hasUserBoosted ? .orange : .primary)
}

Text("\(viewModel.ping.boostCount) boost\(viewModel.ping.boostCount == 1 ? "" : "s")")
    .font(.subheadline)
    .foregroundStyle(.secondary)
```

Add `.task` for boost check:

```swift
await viewModel.checkBoostStatus()
```

(Add this to the existing `.task` modifier alongside `loadCreator()`)

- [ ] **Step 5: Build and test on device**

Verify: tap boost → count increments, button shows "Boosted", can't boost own ping, can't boost twice.

- [ ] **Step 6: Commit**

```bash
git add PingIt/Features/Ping/ViewModels/PingDetailViewModel.swift PingIt/Features/Ping/Views/PingDetailView.swift PingItTests/ViewModelTests/PingDetailViewModelTests.swift
git commit -m "feat: add boost button to ping detail with double-boost prevention"
```

---

## Task 3: Hot Pings Visual Treatment on Map

**Files:**
- Modify: `PingIt/Features/Map/ViewModels/MapViewModel.swift`
- Modify: `PingIt/Features/Map/Views/PingAnnotationView.swift`
- Modify: `PingIt/Features/Map/Views/MapView.swift`

- [ ] **Step 1: Add hot ping detection to MapViewModel**

Read `PingIt/Features/Map/ViewModels/MapViewModel.swift`. Add a computed property:

```swift
var hotPingIds: Set<String> {
    let sorted = pings.sorted { $0.hotScore > $1.hotScore }
    let topTen = sorted.prefix(10)
    let hotOnes = topTen.filter { $0.hotScore >= 5.0 }
    return Set(hotOnes.compactMap(\.id))
}
```

- [ ] **Step 2: Update PingAnnotationView for hot treatment**

Read `PingIt/Features/Map/Views/PingAnnotationView.swift`. Add parameter:

```swift
let isHot: Bool
```

Update the view body to show hot treatment:

```swift
var body: some View {
    Button(action: handleTap) {
        VStack(spacing: 4) {
            Image(systemName: isHot ? "flame.circle.fill" : "mappin.circle.fill")
                .font(isHot ? .title : .title2)
                .foregroundStyle(.white)
                .background {
                    Circle()
                        .fill(isHot ? .red.gradient : .orange.gradient)
                        .frame(width: isHot ? 42 : 36, height: isHot ? 42 : 36)
                }
                .shadow(color: isHot ? .red.opacity(0.5) : .clear, radius: isHot ? 6 : 0)

            Text(ping.expiresAt.countdownDescription)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
    .buttonStyle(.plain)
    .accessibilityLabel("Ping: \(ping.text), \(ping.expiresAt.countdownDescription)\(isHot ? ", trending" : "")")
}
```

- [ ] **Step 3: Update MapView to pass isHot**

In `MapView.swift`, update the `ForEach` loop:

```swift
ForEach(viewModel.pings) { ping in
    Annotation(
        ping.text,
        coordinate: CLLocationCoordinate2D(
            latitude: ping.location.latitude,
            longitude: ping.location.longitude
        )
    ) {
        PingAnnotationView(
            ping: ping,
            isHot: viewModel.hotPingIds.contains(ping.id ?? "")
        ) {
            selectedPing = ping
        }
    }
}
```

- [ ] **Step 4: Build and test**

Verify hot pings show larger flame icon with glow.

- [ ] **Step 5: Commit**

```bash
git add PingIt/Features/Map/ViewModels/MapViewModel.swift PingIt/Features/Map/Views/PingAnnotationView.swift PingIt/Features/Map/Views/MapView.swift
git commit -m "feat: add hot ping visual treatment with flame icon and glow effect"
```

---

## Task 4: Ping Clustering

**Files:**
- Create: `PingIt/Features/Map/Views/PingClusterAnnotationView.swift`
- Modify: `PingIt/Features/Map/Views/MapView.swift`

- [ ] **Step 1: Create PingClusterAnnotationView**

```swift
import SwiftUI
import MapKit

struct PingClusterAnnotationView: View {
    let count: Int
    let containsHotPing: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(containsHotPing ? .red.gradient : .orange.gradient)
                .frame(width: 44, height: 44)
                .shadow(color: containsHotPing ? .red.opacity(0.4) : .orange.opacity(0.3), radius: 4)

            Text("\(count)")
                .font(.subheadline)
                .bold()
                .foregroundStyle(.white)
        }
        .accessibilityLabel("\(count) pings\(containsHotPing ? ", includes trending" : "")")
    }
}
```

- [ ] **Step 2: Add clustering to MapView**

Read `PingIt/Features/Map/Views/MapView.swift`. The SwiftUI `Map` with `MapContentBuilder` on iOS 17+ supports clustering. Update the annotation to use `clusterAnnotation`:

Replace the current `ForEach` annotation block with:

```swift
ForEach(viewModel.pings) { ping in
    Annotation(
        ping.text,
        coordinate: CLLocationCoordinate2D(
            latitude: ping.location.latitude,
            longitude: ping.location.longitude
        ),
        anchor: .bottom
    ) {
        PingAnnotationView(
            ping: ping,
            isHot: viewModel.hotPingIds.contains(ping.id ?? "")
        ) {
            selectedPing = ping
        }
    }
    .annotationTitles(.hidden)
    .tag(ping.id)
}
```

**Note:** SwiftUI's `Map` on iOS 26 may have a `ClusterAnnotation` content builder or `MapClusterAnnotation`. Check the iOS 26 SDK documentation during implementation. If `MapClusterAnnotation` is not available in the SwiftUI Map API, the alternative is:

Option A: Use `MKMapView` via `UIViewRepresentable` for full clustering control.
Option B: Implement manual client-side clustering by grouping nearby pings at low zoom levels.

Since the user chose SwiftUI MapContentBuilder, try the native approach first. If the API doesn't support clustering natively:
- Check if `.mapContent { }` supports `MapAnnotation` with a `clusteringIdentifier`
- If not, implement a manual clustering approach in `MapViewModel` that groups pings by proximity based on current map region span, and display cluster views for groups.

- [ ] **Step 3: Build and test**

Test on device:
1. Zoom out → pings should cluster (if API supports it) or show normally
2. Zoom in → individual pins visible
3. Tap cluster → zoom in to show individual pins

- [ ] **Step 4: Commit**

```bash
git add PingIt/Features/Map/Views/PingClusterAnnotationView.swift PingIt/Features/Map/Views/MapView.swift
git commit -m "feat: add ping clustering on map with hot ping indicators"
```

---

## Task 5: Privacy Settings & Notification Preferences Toggles

**Files:**
- Modify: `PingIt/Core/Models/User.swift`
- Modify: `PingIt/Features/Settings/Views/SettingsView.swift`

- [ ] **Step 1: Add preference fields to User model**

Read `PingIt/Core/Models/User.swift`. Add:

```swift
var isPrivateProfile: Bool = false
var notifyNearbyPings: Bool = true
var notifyHotPings: Bool = true
```

- [ ] **Step 2: Update all test helpers creating User instances**

Search the test files for `User(` initializers. Add the new fields with default values to any explicit initializers that need them. Since these fields have defaults, most should compile without changes — verify.

- [ ] **Step 3: Add settings sections to SettingsView**

Read `PingIt/Features/Settings/Views/SettingsView.swift`. Add `@Environment(UserService.self)` and `@Environment(AuthService.self)` if not already present. Add state for preferences:

```swift
@State private var isPrivateProfile = false
@State private var notifyNearbyPings = true
@State private var notifyHotPings = true
```

Add sections to the List:

```swift
Section("Notifications") {
    Toggle("Nearby Pings", isOn: $notifyNearbyPings)
    Toggle("Hot Pings", isOn: $notifyHotPings)
}
.onChange(of: notifyNearbyPings) { _, newValue in
    savePreference("notifyNearbyPings", value: newValue)
}
.onChange(of: notifyHotPings) { _, newValue in
    savePreference("notifyHotPings", value: newValue)
}

Section("Privacy") {
    Toggle("Private Profile", isOn: $isPrivateProfile)
}
.onChange(of: isPrivateProfile) { _, newValue in
    savePreference("isPrivateProfile", value: newValue)
}
```

Add helper method:

```swift
private func savePreference(_ key: String, value: Bool) {
    guard let userId = authService.currentUser?.uid else { return }
    Task {
        try? await userService.updateUser(id: userId, data: [key: value])
    }
}
```

Load preferences in `.task`:

```swift
.task {
    guard let userId = authService.currentUser?.uid else { return }
    if let user = try? await userService.fetchUser(id: userId) {
        isPrivateProfile = user.isPrivateProfile
        notifyNearbyPings = user.notifyNearbyPings
        notifyHotPings = user.notifyHotPings
    }
}
```

- [ ] **Step 4: Build and test on device**

Verify:
1. Settings shows Notifications and Privacy sections
2. Toggles save to Firestore (check in Firebase Console)
3. Values persist when leaving and returning to settings

- [ ] **Step 5: Commit**

```bash
git add PingIt/Core/Models/User.swift PingIt/Features/Settings/Views/SettingsView.swift
git commit -m "feat: add privacy settings and notification preference toggles"
```

---

## Task 6: Final Sprint 2 Integration

- [ ] **Step 1: Run full test suite**

Run: `swift test`
Expected: All PASS

- [ ] **Step 2: Manual testing on device**

Test complete Sprint 2:
1. Boost a ping → count increments → button fills → can't boost again
2. Create multiple pings with boosts → hot pings show flame icon on map
3. Zoom out → clusters appear → zoom in → individual pins
4. Settings → notification toggles → privacy toggle → values saved

- [ ] **Step 3: Update project documentation**

Update `project_status.md`, `ARCHITECTURE.md`, `CHANGELOG.md`.

- [ ] **Step 4: Commit**

```bash
git add project_status.md ARCHITECTURE.md CHANGELOG.md
git commit -m "docs: update project docs for Sprint 2 completion"
```
