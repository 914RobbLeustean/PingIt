# Phase 1 Sprint 4: Moderation Pipeline — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deploy Cloud Functions for automated image moderation (Vision API) and admin emergency content removal. Write the admin moderation runbook.

**Architecture:** Two Cloud Functions — one triggered by Firebase Storage uploads (image moderation), one callable by admin (content removal). No iOS changes needed.

**Tech Stack:** TypeScript, Firebase Cloud Functions v2, Google Cloud Vision API, Firebase Admin SDK

**Design Spec:** `docs/superpowers/specs/2026-04-14-phase1-safety-discovery-design.md` (Sprint 4 section)

**Prerequisite:** Sprint 3 complete (Cloud Functions infrastructure deployed)

---

## Task 1: Automated Image Filtering

**Files:**
- Create: `functions/src/moderateImage.ts`
- Modify: `functions/src/index.ts`

- [ ] **Step 1: Install Vision API dependency**

```bash
cd functions && npm install @google-cloud/vision && cd ..
```

- [ ] **Step 2: Set Vision API environment variable**

```bash
firebase functions:config:set vision.enabled="true"
```

Note: The Cloud Vision API uses Application Default Credentials when running on Cloud Functions. No separate API key needed — the service account has access automatically. You may need to enable the Vision API in the Google Cloud Console for your project.

- [ ] **Step 3: Create moderateImage function**

Create `functions/src/moderateImage.ts`:

```typescript
import { onObjectFinalized } from "firebase-functions/v2/storage";
import { getFirestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import vision from "@google-cloud/vision";

const client = new vision.ImageAnnotatorClient();

export const moderateImage = onObjectFinalized(async (event) => {
  const filePath = event.data.name;
  if (!filePath) return;

  // Only moderate profile pictures and ping images
  const isProfilePic = filePath.startsWith("profile_pictures/");
  const isPingImage = filePath.startsWith("ping_images/");

  if (!isProfilePic && !isPingImage) return;

  const db = getFirestore();
  const storage = getStorage();
  const bucket = storage.bucket(event.data.bucket);
  const file = bucket.file(filePath);

  try {
    // Get the public URL for Vision API
    const [url] = await file.getSignedUrl({
      action: "read",
      expires: Date.now() + 5 * 60 * 1000, // 5 minutes
    });

    // Call Vision API SafeSearch
    const [result] = await client.safeSearchDetection(url);
    const safeSearch = result.safeSearchAnnotation;

    if (!safeSearch) {
      console.log(`No SafeSearch result for ${filePath}`);
      return;
    }

    console.log(`SafeSearch for ${filePath}:`, {
      adult: safeSearch.adult,
      violence: safeSearch.violence,
      racy: safeSearch.racy,
    });

    const isVeryLikely = (level: string | null | undefined): boolean =>
      level === "VERY_LIKELY";

    const isLikely = (level: string | null | undefined): boolean =>
      level === "LIKELY";

    const shouldAutoRemove =
      isVeryLikely(safeSearch.adult) ||
      isVeryLikely(safeSearch.violence) ||
      isVeryLikely(safeSearch.racy);

    const shouldFlagForReview =
      isLikely(safeSearch.adult) ||
      isLikely(safeSearch.violence) ||
      isLikely(safeSearch.racy);

    if (shouldAutoRemove) {
      console.log(`Auto-removing ${filePath} — flagged as inappropriate.`);

      // Delete the file
      await file.delete();

      if (isProfilePic) {
        // Extract userId from path: profile_pictures/{userId}/filename
        const userId = filePath.split("/")[1];
        if (userId) {
          await db.collection("users").doc(userId).update({
            profileImageUrl: null,
          });
        }
      }

      if (isPingImage) {
        // Extract pingId from path: ping_images/{pingId}/filename
        const pingId = filePath.split("/")[1];
        if (pingId) {
          await db.collection("pings").doc(pingId).update({
            status: "removed",
          });
        }
      }

      // Create audit trail
      await db.collection("moderationActions").add({
        targetType: isProfilePic ? "profile_image" : "ping_image",
        targetPath: filePath,
        action: "auto_removed",
        reason: `SafeSearch: adult=${safeSearch.adult}, violence=${safeSearch.violence}, racy=${safeSearch.racy}`,
        moderatorId: "system",
        timestamp: new Date(),
      });
    } else if (shouldFlagForReview) {
      console.log(`Flagging ${filePath} for manual review.`);

      // Create a report for manual review
      await db.collection("reports").add({
        reporterId: "system",
        targetType: isProfilePic ? "profile_image" : "ping_image",
        targetId: filePath,
        targetOwnerId: filePath.split("/")[1] || "unknown",
        reason: "Automated moderation flag",
        details: `SafeSearch: adult=${safeSearch.adult}, violence=${safeSearch.violence}, racy=${safeSearch.racy}`,
        status: "pending",
        createdAt: new Date(),
      });
    }
  } catch (error) {
    console.error(`Error moderating image ${filePath}:`, error);
  }
});
```

- [ ] **Step 4: Export from index.ts**

Add to `functions/src/index.ts`:

```typescript
export { moderateImage } from "./moderateImage";
```

- [ ] **Step 5: Enable Vision API in Google Cloud Console**

Go to: https://console.cloud.google.com/apis/library/vision.googleapis.com
Enable the API for your Firebase project.

- [ ] **Step 6: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:moderateImage
```

- [ ] **Step 7: Test with profile picture upload**

1. Upload a normal profile picture → no action taken
2. Upload a test inappropriate image → verify:
   - Image deleted from Storage
   - User's `profileImageUrl` set to null
   - `moderationActions` document created

**Note:** Finding appropriate test images for SafeSearch is tricky. You can test with stock images known to trigger SafeSearch, or modify the threshold temporarily to `POSSIBLE` for testing, then revert.

- [ ] **Step 8: Commit**

```bash
git add functions/src/moderateImage.ts functions/src/index.ts functions/package.json functions/package-lock.json
git commit -m "feat: add automated image moderation with Vision API SafeSearch"
```

---

## Task 2: Emergency Content Removal

**Files:**
- Create: `functions/src/removeContent.ts`
- Modify: `functions/src/index.ts`

- [ ] **Step 1: Set admin emails environment variable**

```bash
firebase functions:config:set admin.emails="leustean.robertgeorge@gmail.com"
```

- [ ] **Step 2: Create removeContent function**

Create `functions/src/removeContent.ts`:

```typescript
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { defineString } from "firebase-functions/params";

const adminEmails = defineString("ADMIN_EMAILS", {
  default: "",
  description: "Comma-separated list of admin email addresses",
});

export const removeContent = onCall(async (request) => {
  const uid = request.auth?.uid;
  if (!uid) {
    throw new HttpsError("unauthenticated", "Must be authenticated.");
  }

  const db = getFirestore();

  // Verify caller is admin
  const callerDoc = await db.collection("users").doc(uid).get();
  const callerEmail = callerDoc.data()?.email;

  const allowedEmails = adminEmails
    .value()
    .split(",")
    .map((e: string) => e.trim());

  if (!callerEmail || !allowedEmails.includes(callerEmail)) {
    throw new HttpsError("permission-denied", "Admin access required.");
  }

  const { targetType, targetId, reason } = request.data;

  if (!targetType || !targetId) {
    throw new HttpsError(
      "invalid-argument",
      "targetType and targetId are required."
    );
  }

  try {
    switch (targetType) {
      case "ping": {
        const pingRef = db.collection("pings").doc(targetId);
        const pingDoc = await pingRef.get();
        if (!pingDoc.exists) {
          throw new HttpsError("not-found", "Ping not found.");
        }

        const pingData = pingDoc.data()!;

        // Update ping status
        await pingRef.update({ status: "removed" });

        // Delete associated chat if exists
        if (pingData.chatId) {
          const messages = await db
            .collection("chatMessages")
            .where("chatId", "==", pingData.chatId)
            .get();
          for (const msg of messages.docs) {
            await msg.ref.delete();
          }

          const participants = await db
            .collection("chatParticipants")
            .where("chatId", "==", pingData.chatId)
            .get();
          for (const part of participants.docs) {
            await part.ref.delete();
          }

          await db.collection("chats").doc(pingData.chatId).delete();
        }
        break;
      }

      case "message": {
        await db.collection("chatMessages").doc(targetId).delete();
        break;
      }

      case "user": {
        await db.collection("users").doc(targetId).update({
          suspensionStatus: "suspended",
          suspensionExpiresAt: new Date(
            Date.now() + 24 * 60 * 60 * 1000
          ), // 24hr default
        });
        break;
      }

      default:
        throw new HttpsError(
          "invalid-argument",
          `Unknown targetType: ${targetType}`
        );
    }

    // Create audit trail
    await db.collection("moderationActions").add({
      moderatorId: uid,
      targetType,
      targetId,
      action: "emergency_removal",
      reason: reason || "No reason provided",
      timestamp: new Date(),
    });

    return { success: true, targetType, targetId };
  } catch (error) {
    if (error instanceof HttpsError) throw error;
    console.error("Content removal failed:", error);
    throw new HttpsError("internal", "Failed to remove content.");
  }
});
```

- [ ] **Step 3: Export from index.ts**

```typescript
export { removeContent } from "./removeContent";
```

- [ ] **Step 4: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:removeContent
```

- [ ] **Step 5: Test via Firebase CLI**

You can test callable functions via the Firebase Functions shell or a simple HTTP call:

```bash
# Using firebase functions shell
firebase functions:shell
> removeContent({ targetType: "ping", targetId: "test_ping_id", reason: "test" }, { auth: { uid: "your_admin_uid" } })
```

Or create a test ping, then call removeContent to verify it's removed.

- [ ] **Step 6: Commit**

```bash
git add functions/src/removeContent.ts functions/src/index.ts
git commit -m "feat: add admin emergency content removal Cloud Function"
```

---

## Task 3: Admin Moderation Runbook

**Files:**
- Create: `docs/ADMIN_MODERATION_RUNBOOK.md`

- [ ] **Step 1: Write the runbook**

Create `docs/ADMIN_MODERATION_RUNBOOK.md`:

```markdown
# Admin Moderation Runbook

## Overview

Content moderation for PingIt uses a combination of automated systems and manual review via Firebase Console. This document covers the manual review workflow.

## Automated Moderation

These run without admin intervention:

1. **Image moderation** (`moderateImage` Cloud Function): Scans all uploaded images via Vision API SafeSearch. Auto-removes VERY_LIKELY inappropriate content. Flags LIKELY content for manual review.

2. **Text moderation** (client-side): Blocks profanity/hate speech before submission. Word list at `PingIt/Resources/moderation_wordlist.txt`.

3. **Rate limiting** (client-side + planned server-side): Prevents spam (5 pings/hour, 6 messages/10 seconds).

## Manual Review Workflow

### Step 1: Check Pending Reports

Go to Firebase Console → Firestore → `reports` collection.

Filter: `status == "pending"`, sort by `createdAt` descending.

Each report contains:
- `reporterId`: Who reported it
- `targetType`: "ping" or "message"
- `targetId`: Document ID of the reported content
- `targetOwnerId`: User who created the reported content
- `reason`: Spam / Harassment / Inappropriate Content / Other
- `details`: Optional additional context

### Step 2: Review the Content

Based on `targetType`:
- **Ping**: Go to `pings` collection → find document by `targetId` → read `text` field
- **Message**: Go to `chatMessages` collection → find by `targetId` → read `text` field

### Step 3: Take Action

**Option A: Dismiss the report**
- Update the report document: `status` → "dismissed", add `reviewedAt` timestamp

**Option B: Remove the content**
- Use the Firebase CLI to call the `removeContent` function:

```bash
# Remove a ping
firebase functions:shell
> removeContent({ targetType: "ping", targetId: "PING_DOC_ID", reason: "Violated community guidelines" })

# Remove a message
> removeContent({ targetType: "message", targetId: "MESSAGE_DOC_ID", reason: "Harassment" })

# Suspend a user (24hr)
> removeContent({ targetType: "user", targetId: "USER_DOC_ID", reason: "Repeated violations" })
```

- Update the report: `status` → "reviewed", add `reviewedAt`

### Step 4: Verify

- Check `moderationActions` collection for the audit trail
- If content was removed, verify in the respective collection

## SLA Targets

| Priority | Response Time | Criteria |
|----------|--------------|----------|
| Critical | <2 hours | Illegal content, safety threats |
| High | <24 hours | Harassment, explicit content |
| Standard | <72 hours | Spam, minor violations |

## Moderation Audit Trail

All actions are logged in the `moderationActions` collection:
- `moderatorId`: Admin who took action (or "system" for automated)
- `targetType`: What was moderated
- `targetId`: Document/file path
- `action`: "auto_removed", "emergency_removal", etc.
- `reason`: Human-readable explanation
- `timestamp`: When the action was taken

## Updating the Word List

The text moderation word list is bundled in the iOS app at `PingIt/Resources/moderation_wordlist.txt`. To update:

1. Edit the file (one word per line)
2. Build and release a new version
3. Future improvement: Move to Firebase Remote Config for real-time updates without app release
```

- [ ] **Step 2: Commit**

```bash
git add docs/ADMIN_MODERATION_RUNBOOK.md
```

Note: The `docs/` directory may be gitignored. If so, either:
- Remove `docs/` from `.gitignore` (recommended — runbooks should be in version control)
- Or keep it local-only

```bash
git commit -m "docs: add admin moderation runbook for Firebase Console workflow"
```

---

## Task 4: Final Sprint 4 Integration

- [ ] **Step 1: Verify all Cloud Functions deployed**

```bash
firebase functions:list
```

Expected: expirePings, deleteAccount, sendNearbyNotification, sendHotPingNotificationOnBoost, sendHotPingNotificationOnJoin, moderateImage, removeContent

- [ ] **Step 2: Run iOS test suite**

Run: `swift test`
Expected: All PASS

- [ ] **Step 3: Update project documentation**

Update `project_status.md`:
- Check off all Phase 1 features
- Update "Current Phase" to "Phase 1 complete"
- Set "Up Next" to Phase 2

Update `ARCHITECTURE.md`:
- Add Cloud Functions to architecture diagram
- Document all 7 deployed functions

Update `CHANGELOG.md` with Sprint 4 entry.

- [ ] **Step 4: Commit**

```bash
git add project_status.md ARCHITECTURE.md CHANGELOG.md
git commit -m "docs: Phase 1 complete — all 16 features + 2 additions implemented"
```
