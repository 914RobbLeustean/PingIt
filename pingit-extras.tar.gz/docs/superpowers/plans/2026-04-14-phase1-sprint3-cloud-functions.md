# Phase 1 Sprint 3: Cloud Functions + Notifications — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deploy Cloud Functions for ping expiration, GDPR account deletion, and push notifications (nearby + hot pings). This is the first backend work in the project.

**Architecture:** TypeScript Cloud Functions deployed to Firebase. iOS side gets a `NotificationService` for FCM token management and notification handling. Account deletion is callable from iOS via Firebase Functions SDK.

**Tech Stack:** TypeScript, Firebase Cloud Functions v2, Firebase Admin SDK, Firebase Cloud Messaging, APNs, Swift 6.2, SwiftUI

**Design Spec:** `docs/superpowers/specs/2026-04-14-phase1-safety-discovery-design.md` (Sprint 3 section)

**Prerequisite:** Sprint 1 + Sprint 2 complete

---

## Task 1: Cloud Functions Setup

**Files:**
- Create: `functions/package.json`
- Create: `functions/tsconfig.json`
- Create: `functions/src/index.ts`
- Modify: `firebase.json` (if it exists, or create)

- [ ] **Step 1: Initialize Cloud Functions**

Run from the project root:

```bash
cd /Users/robert.leustean/PingIt
firebase init functions
```

Select:
- Language: TypeScript
- ESLint: Yes
- Install dependencies: Yes

This creates the `functions/` directory with boilerplate.

- [ ] **Step 2: Verify the generated structure**

```
functions/
├── src/
│   └── index.ts
├── package.json
├── tsconfig.json
├── .eslintrc.js
└── node_modules/
```

- [ ] **Step 3: Create a test function**

In `functions/src/index.ts`:

```typescript
import { onRequest } from "firebase-functions/v2/https";

export const healthCheck = onRequest((req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});
```

- [ ] **Step 4: Deploy and test**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:healthCheck
```

Verify the deployed URL returns `{ "status": "ok" }`.

- [ ] **Step 5: Add functions/ to .gitignore exclusions if needed**

Check `.gitignore` — ensure `functions/node_modules/` is ignored but `functions/src/` is not.

- [ ] **Step 6: Commit**

```bash
git add functions/ firebase.json .firebaserc
git commit -m "feat: initialize Cloud Functions with TypeScript and health check"
```

---

## Task 2: Ping Expiration Cloud Function

**Files:**
- Create: `functions/src/expirePings.ts`
- Modify: `functions/src/index.ts`

- [ ] **Step 1: Create expirePings function**

Create `functions/src/expirePings.ts`:

```typescript
import { onSchedule } from "firebase-functions/v2/scheduler";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { initializeApp } from "firebase-admin/app";

// Initialize only once across all functions
if (!globalThis._firebaseInitialized) {
  initializeApp();
  globalThis._firebaseInitialized = true;
}

export const expirePings = onSchedule("every 5 minutes", async () => {
  const db = getFirestore();
  const now = new Date();

  // Query active pings that have expired
  const expiredPingsSnapshot = await db
    .collection("pings")
    .where("status", "==", "active")
    .where("expiresAt", "<=", now)
    .get();

  if (expiredPingsSnapshot.empty) {
    console.log("No expired pings found.");
    return;
  }

  console.log(`Found ${expiredPingsSnapshot.size} expired pings.`);

  // Process in batches of 500 (Firestore limit)
  const batchSize = 500;
  let operationCount = 0;
  let batch = db.batch();

  for (const pingDoc of expiredPingsSnapshot.docs) {
    const pingData = pingDoc.data();

    // Update ping status
    batch.update(pingDoc.ref, { status: "expired" });
    operationCount++;

    // Delete associated chat if exists
    if (pingData.chatId) {
      const chatRef = db.collection("chats").doc(pingData.chatId);
      batch.delete(chatRef);
      operationCount++;

      // Delete chat messages
      const messagesSnapshot = await db
        .collection("chatMessages")
        .where("chatId", "==", pingData.chatId)
        .get();

      for (const msgDoc of messagesSnapshot.docs) {
        batch.delete(msgDoc.ref);
        operationCount++;

        if (operationCount >= batchSize) {
          await batch.commit();
          batch = db.batch();
          operationCount = 0;
        }
      }

      // Delete chat participants
      const participantsSnapshot = await db
        .collection("chatParticipants")
        .where("chatId", "==", pingData.chatId)
        .get();

      for (const partDoc of participantsSnapshot.docs) {
        batch.delete(partDoc.ref);
        operationCount++;

        if (operationCount >= batchSize) {
          await batch.commit();
          batch = db.batch();
          operationCount = 0;
        }
      }
    }

    if (operationCount >= batchSize) {
      await batch.commit();
      batch = db.batch();
      operationCount = 0;
    }
  }

  // Commit remaining operations
  if (operationCount > 0) {
    await batch.commit();
  }

  console.log(`Expired ${expiredPingsSnapshot.size} pings successfully.`);
});
```

- [ ] **Step 2: Export from index.ts**

Update `functions/src/index.ts`:

```typescript
export { expirePings } from "./expirePings";
```

Remove the healthCheck if no longer needed (or keep for monitoring).

- [ ] **Step 3: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:expirePings
```

- [ ] **Step 4: Test with a short-expiration ping**

Create a ping in the app with the shortest expiration. Wait for the cron to run. Verify in Firebase Console that:
- Ping status changed to "expired"
- Chat document deleted
- Chat messages deleted
- Chat participants deleted

- [ ] **Step 5: Commit**

```bash
git add functions/src/expirePings.ts functions/src/index.ts
git commit -m "feat: add expirePings Cloud Function (5-minute cron)"
```

---

## Task 3: GDPR Account Deletion

**Files:**
- Create: `functions/src/deleteAccount.ts`
- Modify: `functions/src/index.ts`
- Modify: `PingIt/Core/Protocols/AuthServicing.swift`
- Modify: `PingIt/Core/Services/AuthService.swift`
- Modify: `PingItTests/Mocks/MockAuthService.swift`
- Modify: `PingIt/Features/Settings/Views/SettingsView.swift`

- [ ] **Step 1: Create deleteAccount Cloud Function**

Create `functions/src/deleteAccount.ts`:

```typescript
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import { getStorage } from "firebase-admin/storage";

export const deleteAccount = onCall(async (request) => {
  const uid = request.auth?.uid;
  if (!uid) {
    throw new HttpsError("unauthenticated", "Must be authenticated.");
  }

  const db = getFirestore();
  const auth = getAuth();
  const storage = getStorage();

  try {
    // 1. Delete all pings created by user (and their chats/messages)
    const userPings = await db
      .collection("pings")
      .where("creatorId", "==", uid)
      .get();

    for (const pingDoc of userPings.docs) {
      const pingData = pingDoc.data();
      if (pingData.chatId) {
        // Delete chat messages
        const messages = await db
          .collection("chatMessages")
          .where("chatId", "==", pingData.chatId)
          .get();
        for (const msg of messages.docs) {
          await msg.ref.delete();
        }
        // Delete chat participants
        const participants = await db
          .collection("chatParticipants")
          .where("chatId", "==", pingData.chatId)
          .get();
        for (const part of participants.docs) {
          await part.ref.delete();
        }
        // Delete chat
        await db.collection("chats").doc(pingData.chatId).delete();
      }
      await pingDoc.ref.delete();
    }

    // 2. Delete all chat messages sent by user (in other people's chats)
    const userMessages = await db
      .collection("chatMessages")
      .where("senderId", "==", uid)
      .get();
    for (const msg of userMessages.docs) {
      await msg.ref.delete();
    }

    // 3. Delete all chat participant records
    const userParticipations = await db
      .collection("chatParticipants")
      .where("userId", "==", uid)
      .get();
    for (const part of userParticipations.docs) {
      await part.ref.delete();
    }

    // 4. Delete all boosts by user
    const userBoosts = await db
      .collection("boosts")
      .where("userId", "==", uid)
      .get();
    for (const boost of userBoosts.docs) {
      await boost.ref.delete();
    }

    // 5. Delete all blocks by/against user
    const blocksAsBlocker = await db
      .collection("blocks")
      .where("blockerId", "==", uid)
      .get();
    for (const block of blocksAsBlocker.docs) {
      await block.ref.delete();
    }

    const blocksAsBlocked = await db
      .collection("blocks")
      .where("blockedUserId", "==", uid)
      .get();
    for (const block of blocksAsBlocked.docs) {
      await block.ref.delete();
    }

    // 6. Delete all reports by user
    const userReports = await db
      .collection("reports")
      .where("reporterId", "==", uid)
      .get();
    for (const report of userReports.docs) {
      await report.ref.delete();
    }

    // 7. Delete profile image from Storage
    try {
      const bucket = storage.bucket();
      await bucket.deleteFiles({ prefix: `profile_pictures/${uid}/` });
    } catch {
      // Storage file may not exist — ignore
    }

    // 8. Delete user document from Firestore
    await db.collection("users").doc(uid).delete();

    // 9. Delete Firebase Auth account
    await auth.deleteUser(uid);

    return { success: true };
  } catch (error) {
    console.error("Account deletion failed:", error);
    throw new HttpsError("internal", "Failed to delete account.");
  }
});
```

- [ ] **Step 2: Export from index.ts**

Add to `functions/src/index.ts`:

```typescript
export { deleteAccount } from "./deleteAccount";
```

- [ ] **Step 3: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:deleteAccount
```

- [ ] **Step 4: Add deleteAccount to AuthServicing protocol**

Read `PingIt/Core/Protocols/AuthServicing.swift`. Add:

```swift
func reauthenticate(password: String) async throws
func deleteAccount() async throws
```

- [ ] **Step 5: Implement in AuthService**

Read `PingIt/Core/Services/AuthService.swift`. Add import:

```swift
import FirebaseFunctions
```

Add methods:

```swift
func reauthenticate(password: String) async throws {
    guard let user = Auth.auth().currentUser, let email = user.email else {
        throw PingItError.notAuthenticated
    }
    let credential = EmailAuthProvider.credential(withEmail: email, password: password)
    do {
        try await user.reauthenticate(with: credential)
    } catch {
        throw PingItError.from(authError: error)
    }
}

func deleteAccount() async throws {
    guard Auth.auth().currentUser != nil else {
        throw PingItError.notAuthenticated
    }

    do {
        let functions = Functions.functions()
        let _ = try await functions.httpsCallable("deleteAccount").call()
        // The Cloud Function deletes the Auth account server-side,
        // but we also sign out locally
        try? Auth.auth().signOut()
    } catch {
        throw PingItError.accountDeletionFailed(underlying: error)
    }
}
```

Add error case to `PingItError.swift`:

```swift
case accountDeletionFailed(underlying: Error)
```

With description:

```swift
case .accountDeletionFailed:
    return "Failed to delete your account. Please try again."
```

- [ ] **Step 6: Update MockAuthService**

Add:

```swift
var reauthenticateCalled = false
var deleteAccountCalled = false

func reauthenticate(password: String) async throws {
    reauthenticateCalled = true
    if let error = errorToThrow { throw error }
}

func deleteAccount() async throws {
    deleteAccountCalled = true
    if let error = errorToThrow { throw error }
}
```

- [ ] **Step 7: Add delete account UI to SettingsView**

Read `PingIt/Features/Settings/Views/SettingsView.swift`. Add state:

```swift
@State private var showDeleteConfirmation = false
@State private var showPasswordPrompt = false
@State private var deletePassword = ""
@State private var isDeletingAccount = false
```

Add section at the bottom of the List:

```swift
Section {
    Button("Delete Account", role: .destructive) {
        showDeleteConfirmation = true
    }
    .disabled(isDeletingAccount)
}
.alert("Delete your account?", isPresented: $showDeleteConfirmation) {
    Button("Delete", role: .destructive) {
        showPasswordPrompt = true
    }
    Button("Cancel", role: .cancel) {}
} message: {
    Text("This will permanently delete your account and all your data. This cannot be undone.")
}
.alert("Confirm your password", isPresented: $showPasswordPrompt) {
    SecureField("Password", text: $deletePassword)
    Button("Confirm Delete", role: .destructive) {
        handleDeleteAccount()
    }
    Button("Cancel", role: .cancel) {
        deletePassword = ""
    }
}
```

Add handler:

```swift
private func handleDeleteAccount() {
    let password = deletePassword
    deletePassword = ""
    isDeletingAccount = true

    Task {
        do {
            try await authService.reauthenticate(password: password)
            try await authService.deleteAccount()
        } catch {
            errorMessage = error.localizedDescription
            isDeletingAccount = false
        }
    }
}
```

- [ ] **Step 8: Add FirebaseFunctions SPM dependency**

In Xcode, add `FirebaseFunctions` to the package dependencies if not already present.

- [ ] **Step 9: Build and test**

Test on device: Settings → Delete Account → confirm → password → account deleted → returns to welcome screen. Verify in Firebase Console that all user data is gone.

- [ ] **Step 10: Commit**

```bash
git add functions/src/deleteAccount.ts functions/src/index.ts PingIt/Core/Protocols/AuthServicing.swift PingIt/Core/Services/AuthService.swift PingIt/Core/Utilities/PingItError.swift PingItTests/Mocks/MockAuthService.swift PingIt/Features/Settings/Views/SettingsView.swift
git commit -m "feat: add GDPR account deletion with Cloud Function and re-auth flow"
```

---

## Task 4: Push Notifications Setup (APNs + FCM)

**Files:**
- Create: `PingIt/Core/Protocols/NotificationServicing.swift`
- Create: `PingIt/Core/Services/NotificationService.swift`
- Modify: `PingIt/Core/Models/User.swift`
- Modify: `PingIt/App/PingItApp.swift`

- [ ] **Step 1: APNs key configuration**

This is a manual step the developer must do:

1. Go to [Apple Developer Portal](https://developer.apple.com/account/resources/authkeys/list)
2. Create a new key → enable "Apple Push Notifications service (APNs)"
3. Download the `.p8` file
4. Go to Firebase Console → Project Settings → Cloud Messaging
5. Upload the `.p8` file under "APNs Authentication Key"
6. Enter the Key ID and Team ID

- [ ] **Step 2: Enable Push Notifications capability in Xcode**

In Xcode → target → Signing & Capabilities → add "Push Notifications" and "Background Modes" (check "Remote notifications").

- [ ] **Step 3: Add fcmToken to User model**

Read `PingIt/Core/Models/User.swift`. Add:

```swift
var fcmToken: String?
```

- [ ] **Step 4: Create NotificationServicing protocol**

```swift
import Foundation

protocol NotificationServicing {
    func requestPermission() async -> Bool
    func registerFCMToken() async
}
```

- [ ] **Step 5: Create NotificationService**

```swift
import Foundation
import FirebaseAuth
import FirebaseFirestore
import FirebaseMessaging
import UserNotifications

@Observable
final class NotificationService: NSObject, NotificationServicing {
    private let db = Firestore.firestore()

    func requestPermission() async -> Bool {
        let center = UNUserNotificationCenter.current()
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .badge, .sound])
            if granted {
                await MainActor.run {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
            return granted
        } catch {
            return false
        }
    }

    func registerFCMToken() async {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        guard let token = Messaging.messaging().fcmToken else { return }

        try? await db
            .collection(Constants.Firestore.usersCollection)
            .document(userId)
            .updateData(["fcmToken": token])
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension NotificationService: UNUserNotificationCenterDelegate {
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        // Show notification even when app is in foreground
        [.banner, .sound, .badge]
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse
    ) async {
        let userInfo = response.notification.request.content.userInfo
        // Handle notification tap — extract pingId for navigation
        if let pingId = userInfo["pingId"] as? String {
            // Post notification for navigation handling
            NotificationCenter.default.post(
                name: .init("PingItOpenPing"),
                object: nil,
                userInfo: ["pingId": pingId]
            )
        }
    }
}

// MARK: - MessagingDelegate
extension NotificationService: MessagingDelegate {
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        guard let fcmToken else { return }
        Task { await registerFCMToken() }
    }
}
```

- [ ] **Step 6: Set up in PingItApp**

Read `PingIt/App/PingItApp.swift`. Add:

```swift
@State private var notificationService = NotificationService()
```

In `WindowGroup`, add `.environment(notificationService)`.

Add an `.onAppear` or `.task` to request permissions and register token:

```swift
.task {
    UNUserNotificationCenter.current().delegate = notificationService
    Messaging.messaging().delegate = notificationService
    let granted = await notificationService.requestPermission()
    if granted {
        await notificationService.registerFCMToken()
    }
}
```

Add `import FirebaseMessaging` to PingItApp.

- [ ] **Step 7: Build and test on device**

Verify:
1. App asks for notification permission on first launch
2. FCM token saved to user document in Firestore (check Console)
3. Foreground notifications display as banners

- [ ] **Step 8: Commit**

```bash
git add PingIt/Core/Protocols/NotificationServicing.swift PingIt/Core/Services/NotificationService.swift PingIt/Core/Models/User.swift PingIt/App/PingItApp.swift
git commit -m "feat: add NotificationService with APNs + FCM token registration"
```

---

## Task 5: Nearby Ping Notification Cloud Function

**Files:**
- Create: `functions/src/sendNearbyNotification.ts`
- Modify: `functions/src/index.ts`

- [ ] **Step 1: Install geofire-common dependency**

```bash
cd functions && npm install geofire-common && cd ..
```

- [ ] **Step 2: Create sendNearbyNotification function**

Create `functions/src/sendNearbyNotification.ts`:

```typescript
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { getFirestore } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";

const NEARBY_RADIUS_KM = 2;

export const sendNearbyNotification = onDocumentCreated(
  "pings/{pingId}",
  async (event) => {
    const pingData = event.data?.data();
    if (!pingData) return;

    const db = getFirestore();
    const messaging = getMessaging();

    const creatorId = pingData.creatorId;
    const pingText = (pingData.text as string).substring(0, 50);
    const pingLocation = pingData.location;

    if (!pingLocation) {
      console.log("Ping has no location, skipping notification.");
      return;
    }

    // Query all users with FCM tokens
    // Note: For scale, use geohash-based queries. For thesis scope (<500 users),
    // querying all users and filtering by distance is acceptable.
    const usersSnapshot = await db
      .collection("users")
      .where("fcmToken", "!=", null)
      .get();

    const tokens: string[] = [];

    for (const userDoc of usersSnapshot.docs) {
      const userId = userDoc.id;
      const userData = userDoc.data();

      // Skip the creator
      if (userId === creatorId) continue;

      // Skip users who disabled nearby notifications
      if (userData.notifyNearbyPings === false) continue;

      // Skip blocked users (check if creator blocked this user or vice versa)
      const blockedUsers = userData.blockedUsers || [];
      if (blockedUsers.includes(creatorId)) continue;

      // Check distance (simple Haversine for thesis scope)
      // For production, use geohash queries
      if (userData.lastKnownLocation) {
        const distance = haversineDistance(
          pingLocation.latitude,
          pingLocation.longitude,
          userData.lastKnownLocation.latitude,
          userData.lastKnownLocation.longitude
        );
        if (distance > NEARBY_RADIUS_KM) continue;
      }

      if (userData.fcmToken) {
        tokens.push(userData.fcmToken);
      }
    }

    if (tokens.length === 0) {
      console.log("No users to notify.");
      return;
    }

    // Send notifications in batches of 500 (FCM limit)
    const batchSize = 500;
    for (let i = 0; i < tokens.length; i += batchSize) {
      const batch = tokens.slice(i, i + batchSize);
      await messaging.sendEachForMulticast({
        tokens: batch,
        notification: {
          title: "New ping nearby!",
          body: pingText,
        },
        data: {
          pingId: event.params.pingId,
          type: "nearby_ping",
        },
        apns: {
          payload: {
            aps: {
              sound: "default",
              badge: 1,
            },
          },
        },
      });
    }

    console.log(`Sent nearby notifications to ${tokens.length} users.`);
  }
);

function haversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
```

**Note:** The distance check uses `lastKnownLocation` on the user document. This field doesn't exist yet. For thesis scope, an alternative approach is to skip the distance check and notify all users in Cluj (since the app is city-scoped, all pings are within the city boundary). Add a TODO comment to implement proper geohash-based querying for production.

- [ ] **Step 3: Export from index.ts**

Add to `functions/src/index.ts`:

```typescript
export { sendNearbyNotification } from "./sendNearbyNotification";
```

- [ ] **Step 4: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions:sendNearbyNotification
```

- [ ] **Step 5: Test with two devices**

1. Device A: logged in as User A
2. Device B: logged in as User B
3. Device A creates a ping
4. Device B should receive a push notification
5. Tap notification → app opens (navigation to ping detail is a stretch goal — verify the notification at minimum)

- [ ] **Step 6: Commit**

```bash
git add functions/src/sendNearbyNotification.ts functions/src/index.ts functions/package.json functions/package-lock.json
git commit -m "feat: add nearby ping push notification Cloud Function"
```

---

## Task 6: Hot Ping Notification Cloud Function

**Files:**
- Create: `functions/src/sendHotPingNotification.ts`
- Modify: `functions/src/index.ts`

- [ ] **Step 1: Create sendHotPingNotification function**

Create `functions/src/sendHotPingNotification.ts`:

```typescript
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { getFirestore } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";

const HOT_SCORE_THRESHOLD = 5.0;
const TOP_N = 10;

function calculateHotScore(
  boostCount: number,
  participantCount: number,
  expiresAt: Date
): number {
  const hoursRemaining = Math.max(
    0,
    (expiresAt.getTime() - Date.now()) / (1000 * 60 * 60)
  );
  return boostCount * 2 + participantCount + hoursRemaining * 0.5;
}

export const sendHotPingNotificationOnBoost = onDocumentCreated(
  "boosts/{boostId}",
  async (event) => {
    await checkAndNotifyHotPing(event.data?.data()?.pingId);
  }
);

export const sendHotPingNotificationOnJoin = onDocumentCreated(
  "chatParticipants/{participantId}",
  async (event) => {
    const participantData = event.data?.data();
    if (!participantData?.chatId) return;

    const db = getFirestore();
    // Find the ping associated with this chat
    const pingsSnapshot = await db
      .collection("pings")
      .where("chatId", "==", participantData.chatId)
      .limit(1)
      .get();

    if (pingsSnapshot.empty) return;
    await checkAndNotifyHotPing(pingsSnapshot.docs[0].id);
  }
);

async function checkAndNotifyHotPing(pingId: string | undefined): Promise<void> {
  if (!pingId) return;

  const db = getFirestore();
  const messaging = getMessaging();

  // Get the ping
  const pingDoc = await db.collection("pings").doc(pingId).get();
  if (!pingDoc.exists) return;

  const pingData = pingDoc.data()!;
  if (pingData.status !== "active") return;

  const pingScore = calculateHotScore(
    pingData.boostCount || 0,
    pingData.participantCount || 0,
    pingData.expiresAt.toDate()
  );

  // Must meet minimum threshold
  if (pingScore < HOT_SCORE_THRESHOLD) return;

  // Check if it's in the top N
  const allActivePings = await db
    .collection("pings")
    .where("status", "==", "active")
    .get();

  const scores = allActivePings.docs.map((doc) => {
    const data = doc.data();
    return {
      id: doc.id,
      score: calculateHotScore(
        data.boostCount || 0,
        data.participantCount || 0,
        data.expiresAt.toDate()
      ),
    };
  });

  scores.sort((a, b) => b.score - a.score);
  const topN = scores.slice(0, TOP_N);
  const isInTopN = topN.some((p) => p.id === pingId);

  if (!isInTopN) return;

  // Check if we already sent a hot notification for this ping
  // (Use a field on the ping document to prevent duplicates)
  if (pingData.hotNotificationSent) return;

  // Mark as notified
  await db.collection("pings").doc(pingId).update({ hotNotificationSent: true });

  // Get users to notify
  const usersSnapshot = await db
    .collection("users")
    .where("fcmToken", "!=", null)
    .get();

  const tokens: string[] = [];
  const creatorId = pingData.creatorId;

  for (const userDoc of usersSnapshot.docs) {
    const userId = userDoc.id;
    const userData = userDoc.data();

    if (userId === creatorId) continue;
    if (userData.notifyHotPings === false) continue;

    const blockedUsers = userData.blockedUsers || [];
    if (blockedUsers.includes(creatorId)) continue;

    if (userData.fcmToken) {
      tokens.push(userData.fcmToken);
    }
  }

  if (tokens.length === 0) return;

  const pingText = (pingData.text as string).substring(0, 50);

  const batchSize = 500;
  for (let i = 0; i < tokens.length; i += batchSize) {
    const batch = tokens.slice(i, i + batchSize);
    await messaging.sendEachForMulticast({
      tokens: batch,
      notification: {
        title: "Trending ping!",
        body: pingText,
      },
      data: {
        pingId: pingId,
        type: "hot_ping",
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
          },
        },
      },
    });
  }

  console.log(`Sent hot ping notification for ${pingId} to ${tokens.length} users.`);
}
```

- [ ] **Step 2: Export from index.ts**

```typescript
export {
  sendHotPingNotificationOnBoost,
  sendHotPingNotificationOnJoin,
} from "./sendHotPingNotification";
```

- [ ] **Step 3: Build and deploy**

```bash
cd functions && npm run build && cd ..
firebase deploy --only functions
```

- [ ] **Step 4: Test**

Boost a ping multiple times from different accounts until it reaches hotScore >= 5.0. Verify hot ping notification is received.

- [ ] **Step 5: Commit**

```bash
git add functions/src/sendHotPingNotification.ts functions/src/index.ts
git commit -m "feat: add hot ping notification Cloud Functions (boost + join triggers)"
```

---

## Task 7: Final Sprint 3 Integration

- [ ] **Step 1: Verify all Cloud Functions deployed**

```bash
firebase functions:list
```

Expected: expirePings, deleteAccount, sendNearbyNotification, sendHotPingNotificationOnBoost, sendHotPingNotificationOnJoin

- [ ] **Step 2: Run iOS test suite**

Run: `swift test`
Expected: All PASS

- [ ] **Step 3: End-to-end testing**

1. Ping expiration: create ping → wait for cron → verify deleted in Console
2. Account deletion: Settings → Delete Account → verify all data removed
3. Nearby notification: create ping on device A → device B receives notification
4. Hot ping notification: boost ping to hot threshold → notification received

- [ ] **Step 4: Update project documentation**

Update `project_status.md`, `ARCHITECTURE.md`, `CHANGELOG.md`.

- [ ] **Step 5: Commit**

```bash
git add project_status.md ARCHITECTURE.md CHANGELOG.md
git commit -m "docs: update project docs for Sprint 3 completion"
```
