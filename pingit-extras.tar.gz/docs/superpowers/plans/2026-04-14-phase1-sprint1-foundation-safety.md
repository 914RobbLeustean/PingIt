# Phase 1 Sprint 1: Foundation Safety — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add client-side safety features (email verification, text moderation, blocking, reporting, spam detection, expired ping filtering) to make the app App Store-ready without any Cloud Functions.

**Architecture:** All 7 features are iOS-only, following the existing MVVM pattern with protocol-based services, `@Observable` ViewModels, and environment injection. New services (`ContentModerationService`, `BlockService`, `ReportService`, `RateLimitService`) each get a protocol, concrete implementation, and mock. ViewModels receive services via `configure()` pattern.

**Tech Stack:** Swift 6.2, SwiftUI, Firebase Auth, Firestore, Swift Testing

**Design Spec:** `docs/superpowers/specs/2026-04-14-phase1-safety-discovery-design.md`

**Key Conventions (from CLAUDE.md):**
- Target iOS 26.0+
- `@Observable` classes (never `ObservableObject`)
- Protocol existentials (`any ServiceProtocol`) for all service injection
- `configure()` pattern with `isConfigured` guard for ViewModel setup
- `private(set)` for read-only state
- `localizedStandardContains()` for user-input text filtering
- Swift Testing (`@Suite`, `@Test`, `#expect`) not XCTest
- `#if DEBUG` for debug-only code paths

---

## File Structure

### New Files (Sprint 1)

| File | Responsibility |
|------|---------------|
| `Core/Protocols/ContentModeratingServicing.swift` | Text moderation protocol |
| `Core/Services/ContentModerationService.swift` | Client-side keyword filter |
| `Core/Protocols/BlockServicing.swift` | Block/unblock protocol |
| `Core/Services/BlockService.swift` | Firestore block CRUD + in-memory cache |
| `Core/Protocols/ReportServicing.swift` | Report submission protocol |
| `Core/Services/ReportService.swift` | Firestore report writes |
| `Core/Protocols/RateLimitServicing.swift` | Rate limit checking protocol |
| `Core/Services/RateLimitService.swift` | UserDefaults-based rate tracking |
| `Core/Models/Block.swift` | Block Firestore model |
| `Core/Models/Report.swift` | Report Firestore model |
| `Resources/moderation_wordlist.txt` | Profanity/hate speech word list |
| `Features/Map/Views/EmailVerificationBannerView.swift` | Verification prompt banner |
| `Features/Settings/ViewModels/BlockedUsersViewModel.swift` | Blocked users list VM |
| `Features/Settings/Views/BlockedUsersView.swift` | Blocked users management screen |
| `Features/Report/ViewModels/ReportViewModel.swift` | Report form state |
| `Features/Report/Views/ReportView.swift` | Report submission sheet |
| `PingItTests/Mocks/MockContentModerationService.swift` | Mock for text filter |
| `PingItTests/Mocks/MockBlockService.swift` | Mock for blocking |
| `PingItTests/Mocks/MockReportService.swift` | Mock for reporting |
| `PingItTests/Mocks/MockRateLimitService.swift` | Mock for rate limiting |
| `PingItTests/ViewModelTests/BlockedUsersViewModelTests.swift` | Blocked users VM tests |
| `PingItTests/ViewModelTests/ReportViewModelTests.swift` | Report VM tests |

### Modified Files (Sprint 1)

| File | Changes |
|------|---------|
| `Core/Protocols/AuthServicing.swift` | Add `isEmailVerified`, `sendEmailVerification()`, `reloadUser()` |
| `Core/Services/AuthService.swift` | Implement email verification methods |
| `Core/Utilities/PingItError.swift` | Add blocking, reporting, moderation error cases |
| `Core/Utilities/Constants.swift` | Add `Firestore.blocksCollection`, `reportsCollection` |
| `Core/Models/User.swift` | No changes needed (already has `blockedUsers[]`) |
| `App/PingItApp.swift` | Inject new services |
| `Features/Map/ViewModels/MapViewModel.swift` | Add expired ping filter + blocked user filter |
| `Features/Map/Views/MapView.swift` | Add email verification banner |
| `Features/Chat/ViewModels/ChatViewModel.swift` | Add content moderation, rate limiting, email verification gate, blocking filter |
| `Features/Ping/ViewModels/CreatePingViewModel.swift` | Add content moderation, rate limiting, email verification gate |
| `Features/Ping/Views/PingDetailView.swift` | Add context menu (report, block) |
| `Features/Chat/Views/MessageBubbleView.swift` | Add context menu (report, block) |
| `Features/Settings/Views/SettingsView.swift` | Add blocked users navigation link |
| `PingItTests/Mocks/MockAuthService.swift` | Add email verification mock properties |
| `PingItTests/ViewModelTests/CreatePingViewModelTests.swift` | Add moderation/rate limit/verification tests |
| `PingItTests/ViewModelTests/ChatViewModelTests.swift` | Add moderation/rate limit/verification tests |
| `PingItTests/ViewModelTests/MapViewModelTests.swift` | Add expired ping filter + blocking tests |

---

## Task 1: Client-Side Expired Ping Filtering

**Files:**
- Modify: `PingIt/Features/Map/ViewModels/MapViewModel.swift`
- Test: `PingItTests/ViewModelTests/MapViewModelTests.swift`

- [ ] **Step 1: Write failing test for expired ping filtering**

Read `PingItTests/ViewModelTests/MapViewModelTests.swift` first to see existing test structure, then add:

```swift
@Test("Expired pings are filtered out from map display")
func expiredPingsFiltered() async {
    let mockPingService = MockPingService()
    let mockLocationService = MockLocationService()
    let vm = MapViewModel()
    vm.configure(pingService: mockPingService, locationService: mockLocationService)

    vm.startObserving()

    let activePing = Ping(
        creatorId: "user1",
        text: "Active event",
        location: .init(latitude: 46.77, longitude: 23.62),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(3600), // 1 hour from now
        status: .active
    )
    let expiredPing = Ping(
        creatorId: "user2",
        text: "Expired event",
        location: .init(latitude: 46.78, longitude: 23.63),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(-3600), // 1 hour ago
        status: .active // Status still "active" but time has passed
    )

    mockPingService.simulateUpdate(pings: [activePing, expiredPing])

    // Allow MainActor dispatch
    try? await Task.sleep(for: .milliseconds(50))

    #expect(vm.pings.count == 1)
    #expect(vm.pings.first?.text == "Active event")
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `swift test --filter MapViewModelTests/expiredPingsFiltered`
Expected: FAIL — both pings will be in the array (no filtering yet).

- [ ] **Step 3: Add expired ping filtering to MapViewModel**

In `MapViewModel.swift`, modify the `startObserving()` method. Change the success case from:
```swift
self.pings = pings
```
to:
```swift
self.pings = pings.filter { $0.expiresAt > Date.now }
```

This is a one-line change inside the existing `Task { @MainActor [self] in` block.

- [ ] **Step 4: Run test to verify it passes**

Run: `swift test --filter MapViewModelTests/expiredPingsFiltered`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add PingIt/Features/Map/ViewModels/MapViewModel.swift PingItTests/ViewModelTests/MapViewModelTests.swift
git commit -m "feat: filter expired pings from map display client-side"
```

---

## Task 2: Email Verification — Protocol & Service

**Files:**
- Modify: `PingIt/Core/Protocols/AuthServicing.swift`
- Modify: `PingIt/Core/Services/AuthService.swift`
- Modify: `PingItTests/Mocks/MockAuthService.swift`

- [ ] **Step 1: Add email verification requirements to AuthServicing protocol**

Read `PingIt/Core/Protocols/AuthServicing.swift`, then add three new requirements:

```swift
protocol AuthServicing {
    var currentUser: (any AuthUserRepresentable)? { get }
    var isLoading: Bool { get }
    var isEmailVerified: Bool { get }
    func signUp(email: String, password: String, username: String) async throws
    func signIn(email: String, password: String) async throws
    func signOut() throws
    func sendPasswordReset(email: String) async throws
    func sendEmailVerification() async throws
    func reloadUser() async throws
}
```

- [ ] **Step 2: Add `isEmailVerified` to AuthUserRepresentable**

Read `PingIt/Core/Protocols/AuthUserRepresentable.swift`, then add:

```swift
protocol AuthUserRepresentable {
    var uid: String { get }
    var isEmailVerified: Bool { get }
}
```

- [ ] **Step 3: Update FirebaseUser conformance**

Read `PingIt/Core/Protocols/FirebaseUser+AuthUserRepresentable.swift`. Firebase's `User` already has `isEmailVerified`, so the conformance should work automatically. Verify it compiles.

- [ ] **Step 4: Implement in AuthService**

Read `PingIt/Core/Services/AuthService.swift`, then add:

```swift
var isEmailVerified: Bool {
    guard let firebaseUser = Auth.auth().currentUser else { return false }
    return firebaseUser.isEmailVerified
}

func sendEmailVerification() async throws {
    guard let user = Auth.auth().currentUser else {
        throw PingItError.notAuthenticated
    }
    do {
        try await user.sendEmailVerification()
    } catch {
        throw PingItError.emailVerificationFailed(underlying: error)
    }
}

func reloadUser() async throws {
    guard let user = Auth.auth().currentUser else {
        throw PingItError.notAuthenticated
    }
    do {
        try await user.reload()
        // Update the observable currentUser reference after reload
        self.currentUser = Auth.auth().currentUser
    } catch {
        throw PingItError.networkError(underlying: error)
    }
}
```

Also update `signUp` to send verification email after account creation. After the Firestore write, add:

```swift
try? await result.user.sendEmailVerification()
```

- [ ] **Step 5: Add error case to PingItError**

Read `PingIt/Core/Utilities/PingItError.swift`, then add a new case:

```swift
case emailVerificationFailed(underlying: Error)
```

And in the `errorDescription` computed property:

```swift
case .emailVerificationFailed:
    return "Failed to send verification email. Please try again."
```

- [ ] **Step 6: Update MockAuthService**

Read `PingItTests/Mocks/MockAuthService.swift`, then add:

```swift
var isEmailVerified = false
var sendEmailVerificationCalled = false
var reloadUserCalled = false

func sendEmailVerification() async throws {
    sendEmailVerificationCalled = true
    if let error = errorToThrow { throw error }
}

func reloadUser() async throws {
    reloadUserCalled = true
    if let error = errorToThrow { throw error }
}
```

- [ ] **Step 7: Update MockAuthUser**

Read `PingItTests/Mocks/MockAuthUser.swift`. Add `isEmailVerified` property:

```swift
struct MockAuthUser: AuthUserRepresentable {
    var uid: String
    var isEmailVerified: Bool = false
}
```

- [ ] **Step 8: Build to verify compilation**

Run: `xcodebuild build -scheme PingIt -destination 'generic/platform=iOS' -quiet`
Expected: BUILD SUCCEEDED

- [ ] **Step 9: Commit**

```bash
git add PingIt/Core/Protocols/AuthServicing.swift PingIt/Core/Protocols/AuthUserRepresentable.swift PingIt/Core/Protocols/FirebaseUser+AuthUserRepresentable.swift PingIt/Core/Services/AuthService.swift PingIt/Core/Utilities/PingItError.swift PingItTests/Mocks/MockAuthService.swift PingItTests/Mocks/MockAuthUser.swift
git commit -m "feat: add email verification to AuthService protocol and implementation"
```

---

## Task 3: Email Verification — ViewModel Gates

**Files:**
- Modify: `PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift`
- Modify: `PingIt/Features/Chat/ViewModels/ChatViewModel.swift`
- Test: `PingItTests/ViewModelTests/CreatePingViewModelTests.swift`
- Test: `PingItTests/ViewModelTests/ChatViewModelTests.swift`

- [ ] **Step 1: Write failing test for unverified user creating ping**

In `CreatePingViewModelTests.swift`, add:

```swift
@Test("Unverified email prevents ping creation")
func unverifiedEmailCannotCreatePing() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: false)
    let mockPing = MockPingService()
    let mockChat = MockChatService()
    let mockLocation = MockLocationService()
    mockLocation.boundaryResult = true

    let vm = CreatePingViewModel()
    vm.configure(authService: mockAuth, pingService: mockPing, chatService: mockChat, locationService: mockLocation)
    vm.text = "Test ping"
    vm.selectedLocation = Constants.Cluj.center

    await vm.createPing()

    #expect(vm.didCreatePing == false)
    #expect(vm.errorMessage != nil)
    #expect(mockPing.createPingWithChatCalled == false)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `swift test --filter CreatePingViewModelTests/unverifiedEmailCannotCreatePing`
Expected: FAIL — ping creation succeeds because no verification check exists.

- [ ] **Step 3: Add email verification gate to CreatePingViewModel**

In `CreatePingViewModel.swift`, in the `createPing()` method, after the `guard let currentUser` line, add:

```swift
guard authService.isEmailVerified else {
    throw PingItError.emailNotVerified
}
```

Add the new error case to `PingItError.swift`:

```swift
case emailNotVerified
```

With description:

```swift
case .emailNotVerified:
    return "Please verify your email before creating pings."
```

- [ ] **Step 4: Run test to verify it passes**

Run: `swift test --filter CreatePingViewModelTests/unverifiedEmailCannotCreatePing`
Expected: PASS

- [ ] **Step 5: Write failing test for unverified user sending message**

In `ChatViewModelTests.swift`, add:

```swift
@Test("Unverified email prevents sending messages")
func unverifiedEmailCannotSendMessage() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: false)
    let mockChat = MockChatService()

    let vm = ChatViewModel(chatId: "chat1", pingId: "ping1")
    vm.configure(authService: mockAuth, chatService: mockChat)
    vm.messageText = "Hello"

    await vm.sendMessage()

    #expect(vm.errorMessage != nil)
    #expect(mockChat.sendMessageCalled == false)
}
```

- [ ] **Step 6: Add email verification gate to ChatViewModel**

In `ChatViewModel.swift`, in `sendMessage()`, after the `guard let chatService, let currentUserId, canSend` line, add:

```swift
guard authService?.isEmailVerified == true else {
    errorMessage = PingItError.emailNotVerified.localizedDescription
    return
}
```

- [ ] **Step 7: Run all tests**

Run: `swift test --filter "CreatePingViewModelTests|ChatViewModelTests"`
Expected: All tests PASS

- [ ] **Step 8: Update existing test factories**

Read through existing `CreatePingViewModelTests.swift` and `ChatViewModelTests.swift`. Any test that expects successful ping creation or message sending needs its `MockAuthUser` to have `isEmailVerified: true`. Update all `makeVM()` or similar factory methods so the mock auth user is verified by default:

```swift
mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
```

- [ ] **Step 9: Run full test suite to verify no regressions**

Run: `swift test`
Expected: All tests PASS

- [ ] **Step 10: Commit**

```bash
git add PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift PingIt/Features/Chat/ViewModels/ChatViewModel.swift PingIt/Core/Utilities/PingItError.swift PingItTests/ViewModelTests/CreatePingViewModelTests.swift PingItTests/ViewModelTests/ChatViewModelTests.swift
git commit -m "feat: gate ping creation and chat messaging behind email verification"
```

---

## Task 4: Email Verification — Banner View

**Files:**
- Create: `PingIt/Features/Map/Views/EmailVerificationBannerView.swift`
- Modify: `PingIt/Features/Map/Views/MapView.swift`

- [ ] **Step 1: Create EmailVerificationBannerView**

```swift
import SwiftUI

struct EmailVerificationBannerView: View {
    let onResend: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        HStack {
            Image(systemName: "envelope.badge")
                .foregroundStyle(.orange)

            Text("Verify your email to create pings")
                .font(.subheadline)

            Spacer()

            Button("Resend", action: onResend)
                .font(.subheadline)
                .bold()

            Button("Dismiss", systemImage: "xmark", action: onDismiss)
                .labelStyle(.iconOnly)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.ultraThinMaterial)
        .clipShape(.rect(cornerRadius: 12))
        .padding(.horizontal)
    }
}
```

- [ ] **Step 2: Add banner to MapView**

Read `PingIt/Features/Map/Views/MapView.swift`. Add state for banner visibility and resend handling. Add these `@State` properties:

```swift
@State private var showVerificationBanner = true
@State private var isResendingVerification = false
```

In the `ZStack` body, after the error/loading overlay and before the closing brace, add:

```swift
if !authService.isEmailVerified && showVerificationBanner {
    VStack {
        EmailVerificationBannerView(
            onResend: handleResendVerification,
            onDismiss: { showVerificationBanner = false }
        )
        Spacer()
    }
    .padding(.top)
}
```

Add the `@Environment` for authService if not already present:

```swift
@Environment(AuthService.self) private var authService
```

Add the handler method:

```swift
private func handleResendVerification() {
    Task {
        isResendingVerification = true
        defer { isResendingVerification = false }
        try? await authService.sendEmailVerification()
    }
}
```

- [ ] **Step 3: Build and test on device**

Build the app and verify:
1. New user → banner appears at top of map
2. "Resend" sends verification email
3. "Dismiss" hides the banner
4. Create Ping button shows error if unverified

- [ ] **Step 4: Commit**

```bash
git add PingIt/Features/Map/Views/EmailVerificationBannerView.swift PingIt/Features/Map/Views/MapView.swift
git commit -m "feat: add email verification banner to map view"
```

---

## Task 5: Content Moderation Service

**Files:**
- Create: `PingIt/Core/Protocols/ContentModeratingServicing.swift`
- Create: `PingIt/Core/Services/ContentModerationService.swift`
- Create: `PingIt/Resources/moderation_wordlist.txt`
- Create: `PingItTests/Mocks/MockContentModerationService.swift`

- [ ] **Step 1: Create ContentModeratingServicing protocol**

```swift
import Foundation

enum ContentModerationResult: Sendable {
    case allowed
    case blocked(reason: String)
}

protocol ContentModeratingServicing {
    func check(_ text: String) -> ContentModerationResult
}
```

- [ ] **Step 2: Create the word list resource file**

Create `PingIt/Resources/moderation_wordlist.txt` with one word per line. Start with a minimal list (expand later):

```
fuck
shit
asshole
bitch
nigger
nigga
faggot
retard
cunt
whore
```

**Important:** Add this file to the Xcode project target so it's included in the app bundle. The file must be added to the PingIt target's "Copy Bundle Resources" build phase.

- [ ] **Step 3: Create ContentModerationService**

```swift
import Foundation

@Observable
final class ContentModerationService: ContentModeratingServicing {
    private let blockedWords: [String]

    init() {
        guard let url = Bundle.main.url(forResource: "moderation_wordlist", withExtension: "txt"),
              let contents = try? String(contentsOf: url, encoding: .utf8) else {
            blockedWords = []
            return
        }
        blockedWords = contents
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    func check(_ text: String) -> ContentModerationResult {
        for word in blockedWords {
            if text.localizedStandardContains(word) {
                return .blocked(reason: "This message violates community guidelines.")
            }
        }
        return .allowed
    }
}
```

- [ ] **Step 4: Create MockContentModerationService**

```swift
import Observation
@testable import PingIt

@Observable
@MainActor
final class MockContentModerationService: ContentModeratingServicing {
    var resultToReturn: ContentModerationResult = .allowed
    var checkCalled = false
    var lastCheckedText: String?

    func check(_ text: String) -> ContentModerationResult {
        checkCalled = true
        lastCheckedText = text
        return resultToReturn
    }
}
```

- [ ] **Step 5: Build to verify compilation**

Run: `xcodebuild build -scheme PingIt -destination 'generic/platform=iOS' -quiet`
Expected: BUILD SUCCEEDED

- [ ] **Step 6: Commit**

```bash
git add PingIt/Core/Protocols/ContentModeratingServicing.swift PingIt/Core/Services/ContentModerationService.swift PingIt/Resources/moderation_wordlist.txt PingItTests/Mocks/MockContentModerationService.swift
git commit -m "feat: add ContentModerationService with client-side keyword filter"
```

---

## Task 6: Integrate Content Moderation into ViewModels

**Files:**
- Modify: `PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift`
- Modify: `PingIt/Features/Chat/ViewModels/ChatViewModel.swift`
- Test: `PingItTests/ViewModelTests/CreatePingViewModelTests.swift`
- Test: `PingItTests/ViewModelTests/ChatViewModelTests.swift`

- [ ] **Step 1: Write failing test for moderated ping creation**

In `CreatePingViewModelTests.swift`:

```swift
@Test("Moderated text prevents ping creation")
func moderatedTextBlocksPingCreation() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockPing = MockPingService()
    let mockChat = MockChatService()
    let mockLocation = MockLocationService()
    mockLocation.boundaryResult = true
    let mockModeration = MockContentModerationService()
    mockModeration.resultToReturn = .blocked(reason: "Violates community guidelines.")

    let vm = CreatePingViewModel()
    vm.configure(
        authService: mockAuth,
        pingService: mockPing,
        chatService: mockChat,
        locationService: mockLocation,
        contentModerationService: mockModeration
    )
    vm.text = "Bad content"
    vm.selectedLocation = Constants.Cluj.center

    await vm.createPing()

    #expect(vm.didCreatePing == false)
    #expect(vm.errorMessage != nil)
    #expect(mockModeration.checkCalled == true)
    #expect(mockPing.createPingWithChatCalled == false)
}
```

- [ ] **Step 2: Add content moderation to CreatePingViewModel.configure()**

Add a new parameter and property to `CreatePingViewModel`:

```swift
private var contentModerationService: (any ContentModeratingServicing)?
```

Update `configure()`:

```swift
func configure(
    authService: any AuthServicing,
    pingService: any PingServicing,
    chatService: any ChatServicing,
    locationService: any LocationServicing,
    contentModerationService: any ContentModeratingServicing
) {
    guard !isConfigured else { return }
    self.authService = authService
    self.pingService = pingService
    self.chatService = chatService
    self.locationService = locationService
    self.contentModerationService = contentModerationService
    isConfigured = true
}
```

In `createPing()`, after the text length validation and before the location check, add:

```swift
if let moderationService = contentModerationService {
    let result = moderationService.check(trimmed)
    if case .blocked(let reason) = result {
        throw PingItError.contentModerated(reason: reason)
    }
}
```

Add new error case to `PingItError.swift`:

```swift
case contentModerated(reason: String)
```

With description:

```swift
case .contentModerated(let reason):
    return reason
```

- [ ] **Step 3: Run test to verify it passes**

Run: `swift test --filter CreatePingViewModelTests/moderatedTextBlocksPingCreation`
Expected: PASS

- [ ] **Step 4: Write failing test for moderated chat message**

In `ChatViewModelTests.swift`:

```swift
@Test("Moderated text prevents sending message")
func moderatedTextBlocksMessageSending() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockChat = MockChatService()
    let mockModeration = MockContentModerationService()
    mockModeration.resultToReturn = .blocked(reason: "Violates community guidelines.")

    let vm = ChatViewModel(chatId: "chat1", pingId: "ping1")
    vm.configure(authService: mockAuth, chatService: mockChat, contentModerationService: mockModeration)
    vm.messageText = "Bad word"

    await vm.sendMessage()

    #expect(vm.errorMessage != nil)
    #expect(mockModeration.checkCalled == true)
    #expect(mockChat.sendMessageCalled == false)
}
```

- [ ] **Step 5: Add content moderation to ChatViewModel**

Add property:

```swift
private var contentModerationService: (any ContentModeratingServicing)?
```

Update `configure()`:

```swift
func configure(
    authService: any AuthServicing,
    chatService: any ChatServicing,
    contentModerationService: any ContentModeratingServicing? = nil
) {
    guard !isConfigured else { return }
    self.authService = authService
    self.chatService = chatService
    self.contentModerationService = contentModerationService
    isConfigured = true
}
```

In `sendMessage()`, after the `let trimmed` line and before the `isSending = true` line, add:

```swift
if let moderationService = contentModerationService {
    let result = moderationService.check(trimmed)
    if case .blocked(let reason) = result {
        errorMessage = reason
        return
    }
}
```

- [ ] **Step 6: Update existing tests that call configure()**

All existing tests calling `vm.configure(authService:chatService:)` or `vm.configure(authService:pingService:chatService:locationService:)` need to pass the new parameter. For tests that don't care about moderation, pass a mock that returns `.allowed` (default behavior of `MockContentModerationService`).

Update `CreatePingViewModelTests.swift` helper/factory to include `contentModerationService: MockContentModerationService()`.

Update `ChatViewModelTests.swift` calls to include `contentModerationService: MockContentModerationService()`.

- [ ] **Step 7: Update Views that call configure()**

Read and update these views to pass `ContentModerationService` from environment:

1. `CreatePingView.swift` — add `@Environment(ContentModerationService.self)` and pass to `viewModel.configure()`
2. `ChatView.swift` — add `@Environment(ContentModerationService.self)` and pass to `viewModel.configure()`

- [ ] **Step 8: Inject ContentModerationService in PingItApp**

In `PingItApp.swift`, add:

```swift
@State private var contentModerationService = ContentModerationService()
```

And in the `WindowGroup`:

```swift
.environment(contentModerationService)
```

- [ ] **Step 9: Run full test suite**

Run: `swift test`
Expected: All tests PASS

- [ ] **Step 10: Commit**

```bash
git add PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift PingIt/Features/Chat/ViewModels/ChatViewModel.swift PingIt/Core/Utilities/PingItError.swift PingIt/App/PingItApp.swift PingIt/Features/Ping/Views/CreatePingView.swift PingIt/Features/Chat/Views/ChatView.swift PingItTests/ViewModelTests/CreatePingViewModelTests.swift PingItTests/ViewModelTests/ChatViewModelTests.swift
git commit -m "feat: integrate content moderation into ping creation and chat messaging"
```

---

## Task 7: Block Model & BlockService Protocol

**Files:**
- Create: `PingIt/Core/Models/Block.swift`
- Create: `PingIt/Core/Protocols/BlockServicing.swift`
- Modify: `PingIt/Core/Utilities/Constants.swift`

- [ ] **Step 1: Create Block model**

```swift
import Foundation
import FirebaseFirestore

struct Block: Codable, Identifiable, Sendable {
    @DocumentID var id: String?
    var blockerId: String
    var blockedUserId: String
    @ServerTimestamp var createdAt: Date?
}
```

- [ ] **Step 2: Create BlockServicing protocol**

```swift
import Foundation

protocol BlockServicing {
    var blockedUserIds: Set<String> { get }
    func blockUser(_ userId: String) async throws
    func unblockUser(_ userId: String) async throws
    func fetchBlockedUsers() async throws -> [Block]
    func isBlocked(_ userId: String) -> Bool
    func loadBlockedUsers() async throws
}
```

- [ ] **Step 3: Add Firestore collection constant**

In `Constants.swift`, inside the `Firestore` enum, add:

```swift
static let blocksCollection = "blocks"
static let reportsCollection = "reports"
static let boostsCollection = "boosts"
```

- [ ] **Step 4: Add blocking error cases to PingItError**

In `PingItError.swift`, add:

```swift
case blockFailed(underlying: Error)
case unblockFailed(underlying: Error)
case cannotBlockSelf
case reportFailed(underlying: Error)
case reportAlreadySubmitted
```

With descriptions:

```swift
case .blockFailed:
    return "Failed to block user. Please try again."
case .unblockFailed:
    return "Failed to unblock user. Please try again."
case .cannotBlockSelf:
    return "You cannot block yourself."
case .reportFailed:
    return "Failed to submit report. Please try again."
case .reportAlreadySubmitted:
    return "You have already reported this content."
```

- [ ] **Step 5: Commit**

```bash
git add PingIt/Core/Models/Block.swift PingIt/Core/Protocols/BlockServicing.swift PingIt/Core/Utilities/Constants.swift PingIt/Core/Utilities/PingItError.swift
git commit -m "feat: add Block model, BlockServicing protocol, and Firestore constants"
```

---

## Task 8: BlockService Implementation

**Files:**
- Create: `PingIt/Core/Services/BlockService.swift`
- Create: `PingItTests/Mocks/MockBlockService.swift`

- [ ] **Step 1: Create BlockService**

```swift
import Foundation
import FirebaseAuth
import FirebaseFirestore

@Observable
final class BlockService: BlockServicing {
    private(set) var blockedUserIds: Set<String> = []
    private let db = Firestore.firestore()

    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }

    func loadBlockedUsers() async throws {
        guard let currentUserId else { return }

        // Fetch blocks where current user is the blocker
        let asBlocker = try await db
            .collection(Constants.Firestore.blocksCollection)
            .whereField("blockerId", isEqualTo: currentUserId)
            .getDocuments()

        // Fetch blocks where current user is the blocked (bidirectional)
        let asBlocked = try await db
            .collection(Constants.Firestore.blocksCollection)
            .whereField("blockedUserId", isEqualTo: currentUserId)
            .getDocuments()

        var ids = Set<String>()
        for doc in asBlocker.documents {
            if let block = try? doc.data(as: Block.self) {
                ids.insert(block.blockedUserId)
            }
        }
        for doc in asBlocked.documents {
            if let block = try? doc.data(as: Block.self) {
                ids.insert(block.blockerId)
            }
        }
        blockedUserIds = ids
    }

    func blockUser(_ userId: String) async throws {
        guard let currentUserId else { throw PingItError.notAuthenticated }
        guard userId != currentUserId else { throw PingItError.cannotBlockSelf }

        do {
            let block = Block(blockerId: currentUserId, blockedUserId: userId)
            try db.collection(Constants.Firestore.blocksCollection)
                .addDocument(from: block)

            // Update local cache immediately
            blockedUserIds.insert(userId)

            // Update denormalized array on user document
            try await db.collection(Constants.Firestore.usersCollection)
                .document(currentUserId)
                .updateData([
                    "blockedUsers": FieldValue.arrayUnion([userId])
                ])
        } catch let error as PingItError {
            throw error
        } catch {
            throw PingItError.blockFailed(underlying: error)
        }
    }

    func unblockUser(_ userId: String) async throws {
        guard let currentUserId else { throw PingItError.notAuthenticated }

        do {
            // Find and delete the block document
            let snapshot = try await db
                .collection(Constants.Firestore.blocksCollection)
                .whereField("blockerId", isEqualTo: currentUserId)
                .whereField("blockedUserId", isEqualTo: userId)
                .getDocuments()

            for doc in snapshot.documents {
                try await doc.reference.delete()
            }

            // Update local cache
            blockedUserIds.remove(userId)

            // Update denormalized array
            try await db.collection(Constants.Firestore.usersCollection)
                .document(currentUserId)
                .updateData([
                    "blockedUsers": FieldValue.arrayRemove([userId])
                ])
        } catch let error as PingItError {
            throw error
        } catch {
            throw PingItError.unblockFailed(underlying: error)
        }
    }

    func fetchBlockedUsers() async throws -> [Block] {
        guard let currentUserId else { return [] }

        let snapshot = try await db
            .collection(Constants.Firestore.blocksCollection)
            .whereField("blockerId", isEqualTo: currentUserId)
            .getDocuments()

        return snapshot.documents.compactMap { try? $0.data(as: Block.self) }
    }

    func isBlocked(_ userId: String) -> Bool {
        blockedUserIds.contains(userId)
    }
}
```

- [ ] **Step 2: Create MockBlockService**

```swift
import Observation
@testable import PingIt

@Observable
@MainActor
final class MockBlockService: BlockServicing {
    var blockedUserIds: Set<String> = []
    var errorToThrow: Error?
    var blockUserCalled = false
    var unblockUserCalled = false
    var fetchBlockedUsersCalled = false
    var loadBlockedUsersCalled = false
    var blocksToReturn: [Block] = []
    var lastBlockedUserId: String?
    var lastUnblockedUserId: String?

    func blockUser(_ userId: String) async throws {
        blockUserCalled = true
        lastBlockedUserId = userId
        if let error = errorToThrow { throw error }
        blockedUserIds.insert(userId)
    }

    func unblockUser(_ userId: String) async throws {
        unblockUserCalled = true
        lastUnblockedUserId = userId
        if let error = errorToThrow { throw error }
        blockedUserIds.remove(userId)
    }

    func fetchBlockedUsers() async throws -> [Block] {
        fetchBlockedUsersCalled = true
        if let error = errorToThrow { throw error }
        return blocksToReturn
    }

    func isBlocked(_ userId: String) -> Bool {
        blockedUserIds.contains(userId)
    }

    func loadBlockedUsers() async throws {
        loadBlockedUsersCalled = true
        if let error = errorToThrow { throw error }
    }
}
```

- [ ] **Step 3: Commit**

```bash
git add PingIt/Core/Services/BlockService.swift PingItTests/Mocks/MockBlockService.swift
git commit -m "feat: implement BlockService with bidirectional blocking and mock"
```

---

## Task 9: Integrate Blocking into MapViewModel and ChatViewModel

**Files:**
- Modify: `PingIt/Features/Map/ViewModels/MapViewModel.swift`
- Modify: `PingIt/Features/Chat/ViewModels/ChatViewModel.swift`
- Test: `PingItTests/ViewModelTests/MapViewModelTests.swift`
- Test: `PingItTests/ViewModelTests/ChatViewModelTests.swift`

- [ ] **Step 1: Write failing test for blocked user pings filtered from map**

In `MapViewModelTests.swift`:

```swift
@Test("Blocked user pings are filtered from map")
func blockedUserPingsFiltered() async {
    let mockPingService = MockPingService()
    let mockLocationService = MockLocationService()
    let mockBlockService = MockBlockService()
    mockBlockService.blockedUserIds = ["blocked_user"]

    let vm = MapViewModel()
    vm.configure(pingService: mockPingService, locationService: mockLocationService, blockService: mockBlockService)
    vm.startObserving()

    let normalPing = Ping(
        creatorId: "user1",
        text: "Visible ping",
        location: .init(latitude: 46.77, longitude: 23.62),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(3600),
        status: .active
    )
    let blockedPing = Ping(
        creatorId: "blocked_user",
        text: "Blocked user ping",
        location: .init(latitude: 46.78, longitude: 23.63),
        geohash: "",
        expiresAt: Date.now.addingTimeInterval(3600),
        status: .active
    )

    mockPingService.simulateUpdate(pings: [normalPing, blockedPing])
    try? await Task.sleep(for: .milliseconds(50))

    #expect(vm.pings.count == 1)
    #expect(vm.pings.first?.text == "Visible ping")
}
```

- [ ] **Step 2: Add BlockService to MapViewModel**

Add property:

```swift
private var blockService: (any BlockServicing)?
```

Update `configure()`:

```swift
func configure(
    pingService: any PingServicing,
    locationService: any LocationServicing,
    blockService: (any BlockServicing)? = nil
) {
    guard !isConfigured else { return }
    self.pingService = pingService
    self.locationService = locationService
    self.blockService = blockService
    isConfigured = true
}
```

Update the filtering in `startObserving()`. Change the success case to:

```swift
case .success(let pings):
    self.pings = pings.filter { ping in
        ping.expiresAt > Date.now
        && !(self.blockService?.isBlocked(ping.creatorId) ?? false)
    }
```

- [ ] **Step 3: Run MapViewModel tests**

Run: `swift test --filter MapViewModelTests`
Expected: All PASS

- [ ] **Step 4: Write failing test for blocked user messages filtered from chat**

In `ChatViewModelTests.swift`:

```swift
@Test("Blocked user messages are filtered from chat")
func blockedUserMessagesFiltered() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockChat = MockChatService()
    let mockBlockService = MockBlockService()
    mockBlockService.blockedUserIds = ["blocked_user"]

    let vm = ChatViewModel(chatId: "chat1", pingId: "ping1")
    vm.configure(authService: mockAuth, chatService: mockChat, contentModerationService: MockContentModerationService(), blockService: mockBlockService)
    vm.startObserving()

    let normalMessage = ChatMessage(chatId: "chat1", senderId: "user2", text: "Hi")
    let blockedMessage = ChatMessage(chatId: "chat1", senderId: "blocked_user", text: "You cant see me")

    mockChat.simulateUpdate(messages: [normalMessage, blockedMessage])
    try? await Task.sleep(for: .milliseconds(50))

    #expect(vm.messages.count == 1)
    #expect(vm.messages.first?.text == "Hi")
}
```

- [ ] **Step 5: Add BlockService to ChatViewModel**

Add property:

```swift
private var blockService: (any BlockServicing)?
```

Update `configure()`:

```swift
func configure(
    authService: any AuthServicing,
    chatService: any ChatServicing,
    contentModerationService: (any ContentModeratingServicing)? = nil,
    blockService: (any BlockServicing)? = nil
) {
    guard !isConfigured else { return }
    self.authService = authService
    self.chatService = chatService
    self.contentModerationService = contentModerationService
    self.blockService = blockService
    isConfigured = true
}
```

Update `startObserving()` success case:

```swift
case .success(let messages):
    self.messages = messages.filter { message in
        !(self.blockService?.isBlocked(message.senderId) ?? false)
    }
```

- [ ] **Step 6: Update Views to pass BlockService**

Update `MapView.swift` and `ChatView.swift` to get `BlockService` from environment and pass to `configure()`.

Update `PingItApp.swift` to inject `BlockService`:

```swift
@State private var blockService = BlockService()
```

```swift
.environment(blockService)
```

Also add a `.task` in `RootView` or `MainTabView` to call `blockService.loadBlockedUsers()` on app launch.

- [ ] **Step 7: Update existing tests**

Update all existing `MapViewModel` and `ChatViewModel` tests to pass `blockService: MockBlockService()` in `configure()` calls where the parameter didn't exist before.

- [ ] **Step 8: Run full test suite**

Run: `swift test`
Expected: All tests PASS

- [ ] **Step 9: Commit**

```bash
git add PingIt/Features/Map/ViewModels/MapViewModel.swift PingIt/Features/Chat/ViewModels/ChatViewModel.swift PingIt/Features/Map/Views/MapView.swift PingIt/Features/Chat/Views/ChatView.swift PingIt/App/PingItApp.swift PingItTests/ViewModelTests/MapViewModelTests.swift PingItTests/ViewModelTests/ChatViewModelTests.swift
git commit -m "feat: filter blocked user pings from map and messages from chat"
```

---

## Task 10: Blocked Users Management View

**Files:**
- Create: `PingIt/Features/Settings/ViewModels/BlockedUsersViewModel.swift`
- Create: `PingIt/Features/Settings/Views/BlockedUsersView.swift`
- Create: `PingItTests/ViewModelTests/BlockedUsersViewModelTests.swift`
- Modify: `PingIt/Features/Settings/Views/SettingsView.swift`

- [ ] **Step 1: Write failing test for BlockedUsersViewModel**

```swift
import Testing
@testable import PingIt

@Suite("BlockedUsersViewModel Tests")
@MainActor
struct BlockedUsersViewModelTests {
    @Test("Loads blocked users with profiles")
    func loadsBlockedUsers() async {
        let mockBlockService = MockBlockService()
        mockBlockService.blocksToReturn = [
            Block(blockerId: "me", blockedUserId: "user1"),
            Block(blockerId: "me", blockedUserId: "user2")
        ]

        let mockUserService = MockUserService()

        let vm = BlockedUsersViewModel()
        vm.configure(blockService: mockBlockService, userService: mockUserService)

        await vm.loadBlockedUsers()

        #expect(vm.blockedUsers.count == 2)
        #expect(mockBlockService.fetchBlockedUsersCalled == true)
    }

    @Test("Unblock removes user from list")
    func unblockRemovesUser() async {
        let mockBlockService = MockBlockService()
        mockBlockService.blocksToReturn = [
            Block(blockerId: "me", blockedUserId: "user1")
        ]
        let mockUserService = MockUserService()

        let vm = BlockedUsersViewModel()
        vm.configure(blockService: mockBlockService, userService: mockUserService)
        await vm.loadBlockedUsers()

        await vm.unblockUser(userId: "user1")

        #expect(mockBlockService.unblockUserCalled == true)
        #expect(mockBlockService.lastUnblockedUserId == "user1")
    }
}
```

- [ ] **Step 2: Create BlockedUsersViewModel**

```swift
import Foundation

@Observable
final class BlockedUsersViewModel {
    private var blockService: (any BlockServicing)?
    private var userService: (any UserServicing)?
    private var isConfigured = false

    private(set) var blockedUsers: [(block: Block, user: User?)] = []
    private(set) var isLoading = false
    private(set) var errorMessage: String?

    func configure(blockService: any BlockServicing, userService: any UserServicing) {
        guard !isConfigured else { return }
        self.blockService = blockService
        self.userService = userService
        isConfigured = true
    }

    func loadBlockedUsers() async {
        guard let blockService, let userService else { return }
        isLoading = true
        defer { isLoading = false }

        do {
            let blocks = try await blockService.fetchBlockedUsers()
            var results: [(block: Block, user: User?)] = []
            for block in blocks {
                let user = try? await userService.fetchUser(id: block.blockedUserId)
                results.append((block: block, user: user))
            }
            blockedUsers = results
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func unblockUser(userId: String) async {
        guard let blockService else { return }

        do {
            try await blockService.unblockUser(userId)
            blockedUsers.removeAll { $0.block.blockedUserId == userId }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
```

- [ ] **Step 3: Run tests**

Run: `swift test --filter BlockedUsersViewModelTests`
Expected: PASS

- [ ] **Step 4: Create BlockedUsersView**

```swift
import SwiftUI

struct BlockedUsersView: View {
    @Environment(BlockService.self) private var blockService
    @Environment(UserService.self) private var userService
    @State private var viewModel = BlockedUsersViewModel()
    @State private var showUnblockConfirmation = false
    @State private var userToUnblock: String?

    var body: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
            } else if viewModel.blockedUsers.isEmpty {
                ContentUnavailableView(
                    "No Blocked Users",
                    systemImage: "person.crop.circle.badge.xmark",
                    description: Text("You haven't blocked anyone.")
                )
            } else {
                List {
                    ForEach(viewModel.blockedUsers, id: \.block.blockedUserId) { entry in
                        HStack {
                            if let url = entry.user?.profileImageUrl, let imageUrl = URL(string: url) {
                                AsyncImage(url: imageUrl) { image in
                                    image.resizable().scaledToFill()
                                } placeholder: {
                                    Image(systemName: "person.circle.fill")
                                        .foregroundStyle(.secondary)
                                }
                                .frame(width: 40, height: 40)
                                .clipShape(.circle)
                            } else {
                                Image(systemName: "person.circle.fill")
                                    .font(.title)
                                    .foregroundStyle(.secondary)
                            }

                            Text(entry.user?.username ?? "Unknown User")
                                .font(.body)

                            Spacer()

                            Button("Unblock", role: .destructive) {
                                userToUnblock = entry.block.blockedUserId
                                showUnblockConfirmation = true
                            }
                            .font(.subheadline)
                        }
                    }
                }
            }
        }
        .navigationTitle("Blocked Users")
        .alert("Unblock user?", isPresented: $showUnblockConfirmation) {
            Button("Unblock", role: .destructive) {
                if let userId = userToUnblock {
                    Task { await viewModel.unblockUser(userId: userId) }
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("You'll see their pings and messages again.")
        }
        .task {
            viewModel.configure(blockService: blockService, userService: userService)
            await viewModel.loadBlockedUsers()
        }
    }
}
```

- [ ] **Step 5: Add navigation link in SettingsView**

Read `PingIt/Features/Settings/Views/SettingsView.swift` (note: the actual filename may be `SettingsPlaceholderView.swift` — check and use whichever exists). Add a new section:

In the `List`, add after the "Account" section:

```swift
Section("Privacy & Safety") {
    NavigationLink("Blocked Users", destination: BlockedUsersView())
}
```

- [ ] **Step 6: Build and test on device**

Verify:
1. Settings → Blocked Users → shows empty state
2. Navigation works correctly

- [ ] **Step 7: Commit**

```bash
git add PingIt/Features/Settings/ViewModels/BlockedUsersViewModel.swift PingIt/Features/Settings/Views/BlockedUsersView.swift PingIt/Features/Settings/Views/SettingsView.swift PingItTests/ViewModelTests/BlockedUsersViewModelTests.swift
git commit -m "feat: add blocked users management screen in settings"
```

---

## Task 11: Block/Report Context Menus on PingDetailView and MessageBubbleView

**Files:**
- Modify: `PingIt/Features/Ping/Views/PingDetailView.swift`
- Modify: `PingIt/Features/Chat/Views/MessageBubbleView.swift`

- [ ] **Step 1: Add block action to PingDetailView**

Read `PingIt/Features/Ping/Views/PingDetailView.swift`. Add environment dependencies:

```swift
@Environment(BlockService.self) private var blockService
```

Add state:

```swift
@State private var showBlockConfirmation = false
```

In the view body, add a toolbar item or a section in the scroll view for non-creators:

```swift
if !viewModel.isCreator {
    Section {
        Button("Block User", systemImage: "hand.raised", role: .destructive) {
            showBlockConfirmation = true
        }
    }
}
```

Add the alert:

```swift
.alert("Block this user?", isPresented: $showBlockConfirmation) {
    Button("Block", role: .destructive) {
        Task {
            try? await blockService.blockUser(viewModel.ping.creatorId)
            dismiss()
        }
    }
    Button("Cancel", role: .cancel) {}
} message: {
    Text("You won't see their pings or messages.")
}
```

- [ ] **Step 2: Add context menu to MessageBubbleView**

Read `PingIt/Features/Chat/Views/MessageBubbleView.swift`. Add parameters for actions:

```swift
let onReport: () -> Void
let onBlock: () -> Void
let isOwnMessage: Bool
```

Add context menu to the message bubble:

```swift
.contextMenu {
    if !isOwnMessage {
        Button("Report Message", systemImage: "exclamationmark.bubble") {
            onReport()
        }
        Button("Block User", systemImage: "hand.raised", role: .destructive) {
            onBlock()
        }
    }
}
```

Update `ChatView.swift` to pass the new parameters when creating `MessageBubbleView`.

- [ ] **Step 3: Build and test**

Verify context menus appear on long-press.

- [ ] **Step 4: Commit**

```bash
git add PingIt/Features/Ping/Views/PingDetailView.swift PingIt/Features/Chat/Views/MessageBubbleView.swift PingIt/Features/Chat/Views/ChatView.swift
git commit -m "feat: add block and report context menus to ping detail and chat messages"
```

---

## Task 12: Report Model & ReportService

**Files:**
- Create: `PingIt/Core/Models/Report.swift`
- Create: `PingIt/Core/Protocols/ReportServicing.swift`
- Create: `PingIt/Core/Services/ReportService.swift`
- Create: `PingItTests/Mocks/MockReportService.swift`

- [ ] **Step 1: Create Report model**

```swift
import Foundation
import FirebaseFirestore

struct Report: Codable, Identifiable, Sendable {
    @DocumentID var id: String?
    var reporterId: String
    var targetType: ReportTargetType
    var targetId: String
    var targetOwnerId: String
    var reason: ReportReason
    var details: String?
    var status: ReportStatus
    @ServerTimestamp var createdAt: Date?

    enum ReportTargetType: String, Codable, Sendable {
        case ping
        case message
    }

    enum ReportReason: String, Codable, Sendable, CaseIterable {
        case spam = "Spam"
        case harassment = "Harassment"
        case inappropriateContent = "Inappropriate Content"
        case other = "Other"
    }

    enum ReportStatus: String, Codable, Sendable {
        case pending
        case reviewed
        case dismissed
    }
}
```

- [ ] **Step 2: Create ReportServicing protocol**

```swift
import Foundation

protocol ReportServicing {
    func submitReport(
        targetType: Report.ReportTargetType,
        targetId: String,
        targetOwnerId: String,
        reason: Report.ReportReason,
        details: String?
    ) async throws
}
```

- [ ] **Step 3: Create ReportService**

```swift
import Foundation
import FirebaseAuth
import FirebaseFirestore

@Observable
final class ReportService: ReportServicing {
    private let db = Firestore.firestore()

    func submitReport(
        targetType: Report.ReportTargetType,
        targetId: String,
        targetOwnerId: String,
        reason: Report.ReportReason,
        details: String?
    ) async throws {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            throw PingItError.notAuthenticated
        }

        let report = Report(
            reporterId: currentUserId,
            targetType: targetType,
            targetId: targetId,
            targetOwnerId: targetOwnerId,
            reason: reason,
            details: details,
            status: .pending
        )

        do {
            try db.collection(Constants.Firestore.reportsCollection)
                .addDocument(from: report)
        } catch {
            throw PingItError.reportFailed(underlying: error)
        }
    }
}
```

- [ ] **Step 4: Create MockReportService**

```swift
import Observation
@testable import PingIt

@Observable
@MainActor
final class MockReportService: ReportServicing {
    var errorToThrow: Error?
    var submitReportCalled = false
    var lastTargetType: Report.ReportTargetType?
    var lastTargetId: String?
    var lastReason: Report.ReportReason?

    func submitReport(
        targetType: Report.ReportTargetType,
        targetId: String,
        targetOwnerId: String,
        reason: Report.ReportReason,
        details: String?
    ) async throws {
        submitReportCalled = true
        lastTargetType = targetType
        lastTargetId = targetId
        lastReason = reason
        if let error = errorToThrow { throw error }
    }
}
```

- [ ] **Step 5: Inject in PingItApp**

```swift
@State private var reportService = ReportService()
```

```swift
.environment(reportService)
```

- [ ] **Step 6: Commit**

```bash
git add PingIt/Core/Models/Report.swift PingIt/Core/Protocols/ReportServicing.swift PingIt/Core/Services/ReportService.swift PingItTests/Mocks/MockReportService.swift PingIt/App/PingItApp.swift
git commit -m "feat: add Report model, ReportService, and mock"
```

---

## Task 13: Report View & ViewModel

**Files:**
- Create: `PingIt/Features/Report/ViewModels/ReportViewModel.swift`
- Create: `PingIt/Features/Report/Views/ReportView.swift`
- Create: `PingItTests/ViewModelTests/ReportViewModelTests.swift`

- [ ] **Step 1: Write failing test for report submission**

```swift
import Testing
@testable import PingIt

@Suite("ReportViewModel Tests")
@MainActor
struct ReportViewModelTests {
    @Test("Successful report submission")
    func submitReportSucceeds() async {
        let mockReport = MockReportService()
        let vm = ReportViewModel(
            targetType: .ping,
            targetId: "ping1",
            targetOwnerId: "user2"
        )
        vm.configure(reportService: mockReport)
        vm.selectedReason = .spam

        await vm.submitReport()

        #expect(vm.didSubmitReport == true)
        #expect(mockReport.submitReportCalled == true)
        #expect(mockReport.lastReason == .spam)
    }

    @Test("Report requires reason selection")
    func reportRequiresReason() async {
        let mockReport = MockReportService()
        let vm = ReportViewModel(
            targetType: .ping,
            targetId: "ping1",
            targetOwnerId: "user2"
        )
        vm.configure(reportService: mockReport)
        // selectedReason is nil by default

        await vm.submitReport()

        #expect(vm.didSubmitReport == false)
        #expect(vm.errorMessage != nil)
    }

    @Test("Offers block after report")
    func offersBlockAfterReport() async {
        let mockReport = MockReportService()
        let vm = ReportViewModel(
            targetType: .ping,
            targetId: "ping1",
            targetOwnerId: "user2"
        )
        vm.configure(reportService: mockReport)
        vm.selectedReason = .harassment

        await vm.submitReport()

        #expect(vm.showBlockOffer == true)
    }
}
```

- [ ] **Step 2: Create ReportViewModel**

```swift
import Foundation

@Observable
final class ReportViewModel {
    private var reportService: (any ReportServicing)?
    private var isConfigured = false

    let targetType: Report.ReportTargetType
    let targetId: String
    let targetOwnerId: String

    var selectedReason: Report.ReportReason?
    var additionalDetails = ""
    private(set) var isSubmitting = false
    private(set) var didSubmitReport = false
    private(set) var showBlockOffer = false
    private(set) var errorMessage: String?

    init(targetType: Report.ReportTargetType, targetId: String, targetOwnerId: String) {
        self.targetType = targetType
        self.targetId = targetId
        self.targetOwnerId = targetOwnerId
    }

    func configure(reportService: any ReportServicing) {
        guard !isConfigured else { return }
        self.reportService = reportService
        isConfigured = true
    }

    func submitReport() async {
        guard let reportService else { return }

        guard let reason = selectedReason else {
            errorMessage = "Please select a reason for your report."
            return
        }

        isSubmitting = true
        defer { isSubmitting = false }

        do {
            let details = additionalDetails.trimmingCharacters(in: .whitespacesAndNewlines)
            try await reportService.submitReport(
                targetType: targetType,
                targetId: targetId,
                targetOwnerId: targetOwnerId,
                reason: reason,
                details: details.isEmpty ? nil : details
            )
            didSubmitReport = true
            showBlockOffer = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
```

- [ ] **Step 3: Run tests**

Run: `swift test --filter ReportViewModelTests`
Expected: All PASS

- [ ] **Step 4: Create ReportView**

```swift
import SwiftUI

struct ReportView: View {
    @Environment(ReportService.self) private var reportService
    @Environment(BlockService.self) private var blockService
    @Environment(\.dismiss) private var dismiss
    @State private var viewModel: ReportViewModel

    init(targetType: Report.ReportTargetType, targetId: String, targetOwnerId: String) {
        self._viewModel = State(initialValue: ReportViewModel(
            targetType: targetType,
            targetId: targetId,
            targetOwnerId: targetOwnerId
        ))
    }

    var body: some View {
        NavigationStack {
            Form {
                if viewModel.didSubmitReport {
                    submittedSection
                } else {
                    reasonSection
                    detailsSection
                    submitSection
                }
            }
            .navigationTitle("Report")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel", action: { dismiss() })
                }
            }
            .task {
                viewModel.configure(reportService: reportService)
            }
        }
    }

    // MARK: - Sections

    private var reasonSection: some View {
        Section("What's the issue?") {
            ForEach(Report.ReportReason.allCases, id: \.self) { reason in
                Button {
                    viewModel.selectedReason = reason
                } label: {
                    HStack {
                        Text(reason.rawValue)
                            .foregroundStyle(.primary)
                        Spacer()
                        if viewModel.selectedReason == reason {
                            Image(systemName: "checkmark")
                                .foregroundStyle(.blue)
                        }
                    }
                }
            }
        }
    }

    private var detailsSection: some View {
        Section("Additional details (optional)") {
            TextField("Tell us more...", text: $viewModel.additionalDetails, axis: .vertical)
                .lineLimit(3...6)
        }
    }

    private var submitSection: some View {
        Section {
            Button("Submit Report", action: handleSubmit)
                .disabled(viewModel.selectedReason == nil || viewModel.isSubmitting)

            if let error = viewModel.errorMessage {
                Label(error, systemImage: "exclamationmark.triangle")
                    .foregroundStyle(.red)
                    .font(.caption)
            }
        }
    }

    private var submittedSection: some View {
        Section {
            VStack(spacing: 12) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.largeTitle)
                    .foregroundStyle(.green)

                Text("Thanks for reporting")
                    .font(.headline)

                Text("We'll review this within 72 hours.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical)
        }

        if viewModel.showBlockOffer {
            Section {
                Button("Block this user", systemImage: "hand.raised", role: .destructive) {
                    Task {
                        try? await blockService.blockUser(viewModel.targetOwnerId)
                        dismiss()
                    }
                }

                Button("No thanks") {
                    dismiss()
                }
            }
        }
    }

    // MARK: - Actions

    @MainActor
    private func handleSubmit() {
        Task { await viewModel.submitReport() }
    }
}
```

- [ ] **Step 5: Wire report action in PingDetailView**

Add state and sheet presentation for reporting in `PingDetailView`:

```swift
@State private var showReportSheet = false
```

Add report button alongside block button for non-creators:

```swift
Button("Report Ping", systemImage: "exclamationmark.bubble") {
    showReportSheet = true
}
```

Add sheet:

```swift
.sheet(isPresented: $showReportSheet) {
    if let pingId = viewModel.ping.id {
        ReportView(
            targetType: .ping,
            targetId: pingId,
            targetOwnerId: viewModel.ping.creatorId
        )
    }
}
```

- [ ] **Step 6: Wire report action in ChatView via MessageBubbleView**

In `ChatView`, when creating `MessageBubbleView`, pass report/block closures that present the report sheet.

- [ ] **Step 7: Build and test on device**

Verify full report flow: long-press message → Report → select reason → submit → confirmation → optional block offer.

- [ ] **Step 8: Commit**

```bash
git add PingIt/Features/Report/ViewModels/ReportViewModel.swift PingIt/Features/Report/Views/ReportView.swift PingIt/Features/Ping/Views/PingDetailView.swift PingIt/Features/Chat/Views/ChatView.swift PingItTests/ViewModelTests/ReportViewModelTests.swift
git commit -m "feat: add report system with reason picker, submission, and block offer"
```

---

## Task 14: Rate Limiting Service

**Files:**
- Create: `PingIt/Core/Protocols/RateLimitServicing.swift`
- Create: `PingIt/Core/Services/RateLimitService.swift`
- Create: `PingItTests/Mocks/MockRateLimitService.swift`

- [ ] **Step 1: Create RateLimitServicing protocol**

```swift
import Foundation

enum RateLimitResult: Sendable {
    case allowed
    case limited(retryAfter: TimeInterval)
}

protocol RateLimitServicing {
    func canCreatePing() -> RateLimitResult
    func canSendMessage() -> RateLimitResult
    func recordPingCreation()
    func recordMessageSent()
}
```

- [ ] **Step 2: Create RateLimitService**

```swift
import Foundation

@Observable
final class RateLimitService: RateLimitServicing {
    private enum Keys {
        static let pingTimestamps = "com.pingit.rateLimit.pingTimestamps"
        static let messageTimestamps = "com.pingit.rateLimit.messageTimestamps"
    }

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    func canCreatePing() -> RateLimitResult {
        #if DEBUG
        return .allowed
        #else
        let now = Date.now
        let timestamps = loadTimestamps(for: Keys.pingTimestamps)

        // Check hourly limit
        let oneHourAgo = now.addingTimeInterval(-3600)
        let pingsInLastHour = timestamps.filter { $0 > oneHourAgo }
        if pingsInLastHour.count >= Constants.RateLimit.maxPingsPerHour {
            let oldestInWindow = pingsInLastHour.min() ?? now
            let retryAfter = oldestInWindow.timeIntervalSince(oneHourAgo)
            return .limited(retryAfter: retryAfter)
        }

        // Check daily limit
        let oneDayAgo = now.addingTimeInterval(-86400)
        let pingsInLastDay = timestamps.filter { $0 > oneDayAgo }
        if pingsInLastDay.count >= Constants.RateLimit.maxPingsPerDay {
            let oldestInWindow = pingsInLastDay.min() ?? now
            let retryAfter = oldestInWindow.timeIntervalSince(oneDayAgo)
            return .limited(retryAfter: retryAfter)
        }

        return .allowed
        #endif
    }

    func canSendMessage() -> RateLimitResult {
        #if DEBUG
        return .allowed
        #else
        let now = Date.now
        let timestamps = loadTimestamps(for: Keys.messageTimestamps)

        let tenSecondsAgo = now.addingTimeInterval(-10)
        let messagesInWindow = timestamps.filter { $0 > tenSecondsAgo }
        if messagesInWindow.count >= Constants.RateLimit.maxMessagesPerTenSeconds {
            let oldestInWindow = messagesInWindow.min() ?? now
            let retryAfter = oldestInWindow.timeIntervalSince(tenSecondsAgo)
            return .limited(retryAfter: retryAfter)
        }

        return .allowed
        #endif
    }

    func recordPingCreation() {
        var timestamps = loadTimestamps(for: Keys.pingTimestamps)
        timestamps.append(Date.now)
        // Prune old entries (older than 24 hours)
        let oneDayAgo = Date.now.addingTimeInterval(-86400)
        timestamps = timestamps.filter { $0 > oneDayAgo }
        saveTimestamps(timestamps, for: Keys.pingTimestamps)
    }

    func recordMessageSent() {
        var timestamps = loadTimestamps(for: Keys.messageTimestamps)
        timestamps.append(Date.now)
        // Prune old entries (older than 10 seconds)
        let tenSecondsAgo = Date.now.addingTimeInterval(-10)
        timestamps = timestamps.filter { $0 > tenSecondsAgo }
        saveTimestamps(timestamps, for: Keys.messageTimestamps)
    }

    // MARK: - Storage

    private func loadTimestamps(for key: String) -> [Date] {
        guard let data = defaults.data(forKey: key),
              let timestamps = try? JSONDecoder().decode([Date].self, from: data) else {
            return []
        }
        return timestamps
    }

    private func saveTimestamps(_ timestamps: [Date], for key: String) {
        if let data = try? JSONEncoder().encode(timestamps) {
            defaults.set(data, forKey: key)
        }
    }
}
```

- [ ] **Step 3: Create MockRateLimitService**

```swift
import Observation
@testable import PingIt

@Observable
@MainActor
final class MockRateLimitService: RateLimitServicing {
    var pingResult: RateLimitResult = .allowed
    var messageResult: RateLimitResult = .allowed
    var recordPingCreationCalled = false
    var recordMessageSentCalled = false

    func canCreatePing() -> RateLimitResult {
        pingResult
    }

    func canSendMessage() -> RateLimitResult {
        messageResult
    }

    func recordPingCreation() {
        recordPingCreationCalled = true
    }

    func recordMessageSent() {
        recordMessageSentCalled = true
    }
}
```

- [ ] **Step 4: Inject in PingItApp**

```swift
@State private var rateLimitService = RateLimitService()
```

```swift
.environment(rateLimitService)
```

- [ ] **Step 5: Commit**

```bash
git add PingIt/Core/Protocols/RateLimitServicing.swift PingIt/Core/Services/RateLimitService.swift PingItTests/Mocks/MockRateLimitService.swift PingIt/App/PingItApp.swift
git commit -m "feat: add RateLimitService with UserDefaults-based tracking and DEBUG bypass"
```

---

## Task 15: Integrate Rate Limiting into ViewModels

**Files:**
- Modify: `PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift`
- Modify: `PingIt/Features/Chat/ViewModels/ChatViewModel.swift`
- Test: `PingItTests/ViewModelTests/CreatePingViewModelTests.swift`
- Test: `PingItTests/ViewModelTests/ChatViewModelTests.swift`

- [ ] **Step 1: Write failing test for rate-limited ping creation**

In `CreatePingViewModelTests.swift`:

```swift
@Test("Rate limited user cannot create ping")
func rateLimitedCannotCreatePing() async {
    let mockAuth = MockAuthService()
    mockAuth.currentUser = MockAuthUser(uid: "user1", isEmailVerified: true)
    let mockPing = MockPingService()
    let mockChat = MockChatService()
    let mockLocation = MockLocationService()
    mockLocation.boundaryResult = true
    let mockModeration = MockContentModerationService()
    let mockRateLimit = MockRateLimitService()
    mockRateLimit.pingResult = .limited(retryAfter: 300)

    let vm = CreatePingViewModel()
    vm.configure(
        authService: mockAuth,
        pingService: mockPing,
        chatService: mockChat,
        locationService: mockLocation,
        contentModerationService: mockModeration,
        rateLimitService: mockRateLimit
    )
    vm.text = "Test"
    vm.selectedLocation = Constants.Cluj.center

    await vm.createPing()

    #expect(vm.didCreatePing == false)
    #expect(vm.errorMessage != nil)
    #expect(mockPing.createPingWithChatCalled == false)
}
```

- [ ] **Step 2: Add rate limiting to CreatePingViewModel**

Add property:

```swift
private var rateLimitService: (any RateLimitServicing)?
```

Update `configure()` to accept `rateLimitService: any RateLimitServicing`:

```swift
func configure(
    authService: any AuthServicing,
    pingService: any PingServicing,
    chatService: any ChatServicing,
    locationService: any LocationServicing,
    contentModerationService: any ContentModeratingServicing,
    rateLimitService: any RateLimitServicing
) {
    guard !isConfigured else { return }
    self.authService = authService
    self.pingService = pingService
    self.chatService = chatService
    self.locationService = locationService
    self.contentModerationService = contentModerationService
    self.rateLimitService = rateLimitService
    isConfigured = true
}
```

In `createPing()`, after the email verification check and before text validation, add:

```swift
if let rateLimitService {
    let result = rateLimitService.canCreatePing()
    if case .limited(let retryAfter) = result {
        let minutes = Int(ceil(retryAfter / 60))
        throw PingItError.rateLimited(retryAfterMinutes: minutes)
    }
}
```

After successful ping creation (after `didCreatePing = true`), add:

```swift
rateLimitService?.recordPingCreation()
```

Add error case to `PingItError.swift`:

```swift
case rateLimited(retryAfterMinutes: Int)
```

With description:

```swift
case .rateLimited(let minutes):
    return "You're creating pings too quickly. Try again in \(minutes) minute\(minutes == 1 ? "" : "s")."
```

- [ ] **Step 3: Add rate limiting to ChatViewModel**

Add property and update configure similarly. In `sendMessage()`, after the content moderation check, add:

```swift
if let rateLimitService {
    let result = rateLimitService.canSendMessage()
    if case .limited = result {
        errorMessage = "You're sending messages too quickly. Please wait a moment."
        return
    }
}
```

After successful send (after `messageText = ""`), add:

```swift
rateLimitService?.recordMessageSent()
```

- [ ] **Step 4: Update all existing tests and view configure() calls**

Add `rateLimitService: MockRateLimitService()` to all existing test factories and view configure calls.

- [ ] **Step 5: Update Views that call configure()**

Update `CreatePingView.swift` and `ChatView.swift` to get `RateLimitService` from environment and pass to configure.

- [ ] **Step 6: Run full test suite**

Run: `swift test`
Expected: All PASS

- [ ] **Step 7: Commit**

```bash
git add PingIt/Features/Ping/ViewModels/CreatePingViewModel.swift PingIt/Features/Chat/ViewModels/ChatViewModel.swift PingIt/Core/Utilities/PingItError.swift PingIt/Features/Ping/Views/CreatePingView.swift PingIt/Features/Chat/Views/ChatView.swift PingItTests/ViewModelTests/CreatePingViewModelTests.swift PingItTests/ViewModelTests/ChatViewModelTests.swift
git commit -m "feat: integrate rate limiting into ping creation and chat messaging"
```

---

## Task 16: Final Sprint 1 Integration Test

- [ ] **Step 1: Run full test suite**

Run: `swift test`
Expected: All tests PASS

- [ ] **Step 2: Build app for device**

Run: `xcodebuild build -scheme PingIt -destination 'generic/platform=iOS' -quiet`
Expected: BUILD SUCCEEDED

- [ ] **Step 3: Manual testing on device**

Test the complete Sprint 1 feature set:

1. **Email verification:** New user → banner shown → resend works → create ping blocked → verify email → banner gone → can create ping
2. **Content moderation:** Create ping with profanity → blocked with error
3. **Blocking:** View ping → block creator → their pings disappear from map → settings → blocked users → unblock → pings reappear
4. **Reporting:** Long-press ping → report → select reason → submit → confirmation → block offer
5. **Rate limiting:** (In release build only) Create 5 pings rapidly → rate limit error
6. **Expired pings:** Create ping with short expiration → after expiry, gone from map

- [ ] **Step 4: Update project documentation**

Update `project_status.md`:
- Check off: Email Verification, Text Content Moderation, User Report System, User Blocking, Blocked Users Management, Spam Detection
- Update "In Progress" to show Sprint 2 features
- Update "Current Phase" to "Phase 1 — Sprint 1 complete"

Update `ARCHITECTURE.md`:
- Add new services to Services Overview table
- Update folder structure with new files
- Add Report and Block data flows

Update `CHANGELOG.md` with Sprint 1 entry.

- [ ] **Step 5: Commit documentation**

```bash
git add project_status.md ARCHITECTURE.md CHANGELOG.md
git commit -m "docs: update project status and architecture for Sprint 1 completion"
```
