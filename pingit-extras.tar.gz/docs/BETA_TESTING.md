# Beta Testing Guide

## Prerequisites

### Apple Developer Program Enrollment
- **Status:** Not enrolled
- **Cost:** $99/year (personal account)
- **Approval time:** 2-5 business days after payment
- **Enroll at:** [developer.apple.com/programs/enroll](https://developer.apple.com/programs/enroll)
- **Note:** Corporate developer account (FanDuel) is restricted. Must use personal Apple Developer account.

### After Enrollment

1. **APNs Auth Key**
   - Apple Developer Console > Keys > Create Key > Enable "Apple Push Notifications service (APNs)"
   - Download the `.p8` file (only downloadable once)
   - Upload to Firebase Console > Project Settings > Cloud Messaging > APNs Authentication Key
   - Record the Key ID and Team ID

2. **Xcode Signing Configuration**
   - Xcode > Signing & Capabilities > Team: select personal developer account
   - Bundle ID: `com.robbLeustean.PingIt` (must match App Store Connect)
   - Enable capabilities: Push Notifications, Background Modes (Remote notifications)
   - Ensure "Automatically manage signing" is checked

3. **App Store Connect Setup**
   - Create new app in [App Store Connect](https://appstoreconnect.apple.com)
   - Platform: iOS
   - Bundle ID: select from registered App IDs
   - Primary language: English (U.K.)

---

## TestFlight Setup

### Archive and Upload

1. In Xcode: Product > Archive (requires physical device or "Any iOS Device" destination)
2. In the Organizer window: Distribute App > TestFlight & App Store > Upload
3. Or via command line:
   ```bash
   xcodebuild archive \
     -scheme PingIt \
     -archivePath build/PingIt.xcarchive \
     -destination 'generic/platform=iOS'

   xcodebuild -exportArchive \
     -archivePath build/PingIt.xcarchive \
     -exportOptionsPlist ExportOptions.plist \
     -exportPath build/export
   ```

### ExportOptions.plist

Create `ExportOptions.plist` in the project root after enrollment:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>app-store-connect</string>
    <key>destination</key>
    <string>upload</string>
    <key>teamID</key>
    <string>YOUR_TEAM_ID</string>
    <key>signingStyle</key>
    <string>automatic</string>
    <key>uploadSymbols</key>
    <true/>
</dict>
</plist>
```

### Internal Testing

- Add yourself as an internal tester (automatic — App Store Connect users with Developer/Admin role)
- Builds are available to internal testers immediately after processing (~15 min)

### External Testing

- Create an external testing group: "Cluj Beta Testers"
- Add up to 10 Cluj-Napoca students (per project spec) via email
- External builds require Beta App Review (first submission only, ~24-48 hours)
- **Requires:** Privacy Policy URL (bundled in-app; provide App Store Connect URL pointing to hosted version or app deep link)

---

## Tester Onboarding

### Invite Message Template
> You're invited to beta test PingIt, a real-time social map for students in Cluj-Napoca!
>
> 1. Open TestFlight on your iPhone (download from App Store if needed)
> 2. Accept the invitation email or tap the TestFlight link
> 3. Install PingIt and create an account
> 4. Make sure Location Services are enabled for PingIt
>
> Please report any issues via TestFlight's built-in feedback (screenshot + shake) or the feedback form linked below.

### Feedback Collection
- **Primary:** TestFlight built-in feedback (screenshot annotations, crash reports)
- **Secondary:** Google Form for structured feedback (usability, feature requests, bugs)
- Google Form fields: tester name, device model, iOS version, feature tested, rating (1-5), description, screenshot upload

---

## Beta Testing Checklist

### Before First Upload
- [ ] Apple Developer Program enrollment approved
- [ ] APNs Auth Key uploaded to Firebase Console
- [ ] Xcode signing configured with personal team
- [ ] App Store Connect app record created
- [ ] Privacy Policy URL configured in App Store Connect
- [ ] ExportOptions.plist created with correct Team ID
- [ ] Crashlytics dSYM upload build phase added

### Before External Testing
- [ ] Internal testing completed (self-test all flows)
- [ ] Beta App Review submitted
- [ ] Tester invite emails prepared
- [ ] Feedback form created and linked
- [ ] Test plan shared with testers (key flows to exercise)

### Key Flows for Testers
1. Registration + email verification + onboarding
2. Create a ping with custom duration
3. View pings on map, tap for details
4. Join a chat, send messages
5. Boost a ping
6. Block/report a user
7. Update profile (photo, username)
8. Delete account (GDPR)
9. Check Terms of Service and Privacy Policy

---

## Timeline

| Step | Estimated Duration | Depends On |
|------|-------------------|------------|
| Developer enrollment | 2-5 business days | Payment |
| Xcode signing + APNs setup | 1 hour | Enrollment |
| First archive + upload | 30 minutes | Signing |
| Internal testing | 1-2 days | Upload |
| Beta App Review | 24-48 hours | Internal testing |
| External beta (10 testers) | 1-2 weeks | Review approval |
| Feedback collection + fixes | Ongoing | External beta |

**Thesis deadline:** July 1, 2026. Start enrollment ASAP to allow sufficient beta testing time.
