# Security & Compliance Reference

## GDPR Requirements (Phase 1)
- **Account Deletion**: User-initiated, cascading delete (pings, messages, profile) via Cloud Function
- **Data Export**: `exportUserData` callable returns JSON of all user data (profile, pings, messages, boosts, blocks, reports, chat participations). Triggered from Settings → Privacy & Safety → "Export My Data". Saved as `PingIt-data-export.json` via share sheet.
- **Consent**: Explicit opt-in for location tracking, push notifications
- **Privacy Policy**: Bundled in-app via `privacy.html` (WKWebView). Covers GDPR data collection table, Firebase services disclosure (Auth, Firestore, Storage, Analytics, Crashlytics, Vision API), data retention, user rights, contact info. Accessible from RegisterView and SettingsView.

## Data Retention
- Pings: Until expiration (max 48hr) - automatic via cron
- Chat messages: Until ping expires or ping removal - cascading cleanup via Cloud Functions
- User profiles: Until account deletion or 2 years inactive
- Reports: 90 days after resolution
- Moderation logs: 1 year (audit trail)

## Content Moderation

### Vision API Thresholds
- **Auto-remove**: Adult/Violence/Racy content = VERY_LIKELY
- **Manual review**: LIKELY threshold, 3+ user reports
- **Optimistic publishing**: Content visible immediately, moderated async (10-30sec)

### Text Moderation
- Client-side keyword filter (profanity, hate speech) using `localizedStandardContains()`
- Show error "Violates community guidelines" if match found
- Server-side validation still enforced (client can be bypassed)

### Report Handling
- User selects: Spam / Harassment / Inappropriate / Other
- iOS submits through the `submitReport` callable; direct client writes to `reports` are denied
- Creates deterministic `reports/{reporterId}_{targetId}` document with status "pending"
- Duplicate reports for the same target return `already-exists` and are shown as "You have already reported this content."
- Admin dashboard: dismiss, remove content, warn/suspend/ban user
- SLA: Critical <2hr, High <24hr, Standard <72hr

## User Safety

### Blocking
- Blocker cannot see blocked user's pings/messages
- Blocked user cannot see blocker's profile
- Bidirectional filtering (neither side sees the other's content)
- Stored in `blocks` collection with `blockerId` and `blockedUserId` fields
- Only the blocker can create/delete their block documents (enforced by security rules)
- Cloud Functions query `blocks` bidirectionally for notification filtering

### Suspensions
- Warning → 24hr → 7-day → Permanent ban
- Stored in `users.suspensionStatus` + `suspensionExpiresAt`
- **Client-side enforcement**: `RootView` fetches user profile on auth, gates access behind `SuspendedAccountView` for suspended/banned users. Temporary suspensions auto-expire when `suspensionExpiresAt` is in the past. Permanent suspensions have no expiry.
- **Server-side**: Firestore rules and user-facing callables reject suspended/banned users where users can write or mutate engagement state. `removeContent` Cloud Function writes suspension fields when admin targets a user (24hr default). No automatic suspension from image moderation yet — `moderateImage` only removes content.

### Server-Owned Writes
- Ping deletion uses `deletePing`; the client sends only `pingId`. The backend verifies creator ownership and cleans related chat, messages, participants, and boosts.
- Boosts use `boostPing`; the backend validates active ping state, suspension state, non-creator status, and bidirectional blocks before creating `boosts/{pingId}_{uid}` and incrementing `boostCount`.
- Chat join/leave uses `joinChat` and `leaveChat`; the backend owns `chatParticipants`, `chats.participantCount`, and `pings.participantCount`.
- Reports use `submitReport`; the backend owns report document IDs and duplicate prevention.
- Username availability uses `usernames/{normalizedUsername}` reservations, so clients never list `users` publicly.

## Data Security
- Firestore encrypts at rest (AES-256), in transit (TLS 1.2+)
- Location stored only in pings (not user tracking), exact lat/lng required for map
- No end-to-end encryption in v1 (chat messages visible to admins)
- API keys: Vision API server-side only (Cloud Functions), Firebase API key can be in app

## Authentication
- Password: Min 8 chars, Firebase Auth enforces
- Email verification required before first ping (Phase 1)
- Session tokens: 1hr expiration, auto-refresh, stored in Keychain
- No social login in v1 (Apple/Google out of scope)

## API Security
- All callable functions check `context.auth` (throw if null)
- Input validation: ping text max 280 chars, location within Cluj bounds, expiration 1-48hr
- Server-authoritative validation: ownership, suspension/banned state, active ping state, duplicate boosts/reports, and bidirectional blocks
- Rate limiting is currently client-side; server-side spam rate limiting is still a launch-hardening item

## Incident Response
- **Critical** (data breach, illegal content): <2hr response, notify users, report to authorities
- **High** (account takeover, spam): <24hr, suspend accounts, delete content
- **Medium** (harassment, false positives): <72hr

## Pre-Launch Checklist
- [x] Account deletion + data export functional
- [ ] Privacy policy published in-app
- [ ] Consent screens for location/notifications
- [ ] Firestore security rules tested
- [ ] Cloud Functions authentication enforced
- [x] Direct client counter/destructive writes denied by Firestore rules
- [ ] Rate limiting working
- [ ] Content moderation pipeline tested
