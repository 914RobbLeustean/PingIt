# PingIt — Full Project Audit

**Date:** 2026-05-02
**Author:** Robert Leustean + Claude
**Target Launch:** July 1, 2026 (Cluj-Napoca, Romania)
**Thesis Submission:** July 1, 2026

---

## Executive Summary

Phase 0 (MVP) and Phase 1 (Safety & Discovery) are complete — 30/40 planned features implemented. The app has a working end-to-end flow: register → map → create ping → chat → boost → block → report → delete account. Server-side infrastructure includes 8 Cloud Functions, Firestore security rules, Vision API image moderation, and push notification triggers. Phase 2 (Polish & Launch) has 10 features remaining, plus significant tech debt and gaps identified below.

**Timeline risk: 60 days to thesis submission.** Phase 2 is mostly UI polish and infrastructure (analytics, crash reporting, onboarding). The biggest unknowns are App Store review timeline and getting push notifications testable.

## Post-Audit Update — 2026-05-06

Several security findings in this point-in-time audit have been remediated after the audit date:

- **Pings update/delete too permissive:** Remediated. Client updates and deletes are now denied; `deletePing` owns creator deletion and cascade cleanup.
- **Client-owned boost counters:** Remediated. `boostPing` validates auth, suspension, active ping state, creator mismatch, and bidirectional blocks before writing deterministic boost docs and incrementing `boostCount`.
- **Client-owned chat participant counters:** Remediated. `joinChat` and `leaveChat` own deterministic participant documents and participant counters.
- **Report duplicate query/list access:** Remediated. `submitReport` uses deterministic report IDs and returns `already-exists` for duplicate UI feedback. Client report writes and reads are denied.
- **Public user listing for username checks:** Remediated for new/renamed users. Username availability uses `usernames/{normalizedUsername}` reservations. Existing users still need a one-time backfill migration.
- **`moderationActions` unprotected:** Remediated. Rules explicitly deny client access.
- **Suspension enforcement:** Improved. App gate exists, Firestore rules check suspension for allowed client writes, and callables reject suspended/banned users for engagement mutations.

The tables below are retained as the original 2026-05-02 audit snapshot. Check `project_status.md`, `docs/FIREBASE.md`, and `CHANGELOG.md` for current implementation state before using this audit as a task list.

---

## Codebase Statistics

| Metric | Count |
|--------|-------|
| Swift source files (app) | 79 |
| Swift test files | 23 |
| Total unit tests (`@Test`) | 153 |
| Test suites | 12 |
| Services | 10 (all with protocol abstractions) |
| Mock implementations | 11 |
| Firestore models | 8 (User, Ping, Chat, ChatMessage, ChatParticipant, Block, Boost, Report) |
| Cloud Functions (deployed) | 8 |
| Firestore composite indexes | 5 |
| Firestore security rule collections | 8 |

---

## What's Implemented and Working

### Phase 0: MVP (14/14 features) — COMPLETE

| # | Feature | Status | Verified |
|---|---------|--------|----------|
| 1 | User Registration | Done | Device tested |
| 2 | User Login | Done | Device tested |
| 3 | Basic Profile Management | Done | Device tested |
| 4 | Real-Time Map Display | Done | Device tested |
| 5 | Cluj-Napoca Boundary Detection | Done | Device tested |
| 6 | Location Permission Management | Done | Device tested |
| 7 | Create Text Ping | Done | Device tested |
| 8 | Set Ping Expiration | Done | Device tested |
| 9 | View Ping Details | Done | Device tested |
| 10 | Delete Own Ping | Done | Device tested |
| 11 | Live Ping Visualization | Done | Device tested |
| 12 | Join Ping Chat | Done | Device tested |
| 13 | Send Text Message | Done | Device tested |
| 14 | Real-Time Message Updates | Done | Device tested |

### Phase 1: Safety & Discovery (16/16 features) — COMPLETE (with caveats)

| # | Feature | Status | Verified | Notes |
|---|---------|--------|----------|-------|
| 15 | Automated Image Filtering | Done | E2E tested | Vision API SafeSearch via `moderateImage` Cloud Function. Scans `profile_pictures/` and `ping_images/`. Confirmed working with real upload. |
| 16 | Text Content Moderation | Done | Device tested | Client-side wordlist (10 words). `localizedStandardContains()` matching. |
| 17 | User Report System | Done | Device tested | Reason picker, duplicate prevention, content snapshots. |
| 18 | Content Review Queue | Partial | Not tested | Runbook written for Firebase Console manual review. **No admin web dashboard built** (spec called for React app on Firebase Hosting). Reports reviewable via Firestore Console only. |
| 19 | Emergency Content Removal | Done | Partially tested | `removeContent` Cloud Function deployed. Auth guard verified (unauthenticated call rejected). Full removal flow not E2E tested due to v2 callable limitations in functions shell. |
| 20 | Boost Ping | Done | Device tested | Double-boost prevention, denormalized count, race condition fix. |
| 21 | Hot Pings Algorithm | Done | Device tested | Formula refined through 3 iterations. Gate: boostCount >= 3, score >= 8.0. |
| 22 | Nearby Ping Notifications | Done | Not testable | Cloud Function deployed and fires on ping creation. **Cannot E2E test** — requires APNs key from personal Apple Developer account ($99/yr). |
| 23 | Hot Ping Notifications | Done | Not testable | Two Cloud Functions deployed (boost + join triggers). Same APNs blocker. |
| 24 | User Blocking | Done | Device tested | Real-time bidirectional, instant enforcement. |
| 25 | Account Deletion (GDPR) | Done | Device tested | Full cascade delete via Cloud Function. |
| 26 | Email Verification | Done | Device tested | Gates ping creation and chat. Auto-refresh banner. |
| 27 | Spam Detection | Done | Device tested | Client-side only. 5 pings/hr, 10/day, 6 msgs/10s. |
| 28 | Notification Preferences | Done | Device tested | Toggles with dual-write (UserDefaults + Firestore). |
| 29 | Privacy Settings | Partial | Device tested | Toggle saved to Firestore but **not enforced anywhere** — setting `isPrivateProfile = true` has no effect on visibility. |
| 30 | Blocked Users Management | Done | Device tested | View + unblock in settings. |

### Phase 2: Polish & Launch (0/10 features) — NOT STARTED

| # | Feature | Status | Complexity | Notes |
|---|---------|--------|------------|-------|
| 31 | Custom Ping Duration | Not started | Low | Add time picker option alongside 6h/24h/48h presets |
| 32 | Onboarding Flow | Not started | Medium | 3-screen tutorial (map, ping, chat) |
| 33 | Empty States | Not started | Low | No pings, no messages, no notifications — currently blank |
| 34 | Error States | Not started | Medium | Network errors, location denied, rate limit exceeded — currently unhandled |
| 35 | Performance Optimization | Not started | Medium | Image caching, chat pagination (currently loads all messages) |
| 36 | Firebase Analytics | Not started | Low | Track key events (ping_created, chat_joined, etc.) |
| 37 | Crash Reporting | Not started | Low | Firebase Crashlytics integration |
| 38 | App Icon & Splash Screen | Partial | Low | LaunchScreen.storyboard exists. AppIcon has empty placeholder (no actual image). |
| 39 | Privacy Policy & Terms | Not started | Medium | TermsOfServiceView is a "Coming Soon" placeholder. Needs actual legal text + WebView hosting. |
| 40 | Beta Testing | Not started | High | TestFlight requires Apple Developer account. Campus recruitment needed. |

---

## Cloud Functions Status

All deployed to `europe-west3` region.

| Function | Trigger | Status | Last Verified |
|----------|---------|--------|---------------|
| `healthCheck` | HTTP GET | Working | 2026-04-20 |
| `expirePings` | Scheduled (5min) | Working | 2026-04-20 |
| `deleteAccount` | Callable | Working | 2026-04-20 |
| `sendNearbyNotification` | Firestore onCreate (pings) | Deployed, untestable | APNs key needed |
| `sendHotPingNotificationOnBoost` | Firestore onCreate (boosts) | Deployed, untestable | APNs key needed |
| `sendHotPingNotificationOnJoin` | Firestore onCreate (chatParticipants) | Deployed, untestable | APNs key needed |
| `moderateImage` | Storage onObjectFinalized | Working | 2026-05-01 |
| `removeContent` | Callable | Deployed, partially tested | Auth guard verified |

### Cloud Functions Infrastructure Issues
- **Node.js 20 deprecated** (2026-04-30). Must upgrade to Node 22 before decommission on 2026-10-30.
- **`firebase-functions` package outdated**. Upgrade has breaking changes — needs dedicated PR.
- **`moderateImage`** uses `gs://` URI workaround because default compute service account lacks `iam.serviceAccounts.signBlob` permission.
- **Functions shell incompatible with v2 callables** — can't easily test `removeContent` or `deleteAccount` locally.

---

## Firestore Security Rules

**Deployed:** Yes, via `firestore.rules` in project root.

### Rules Coverage

| Collection | Read | Create | Update | Delete | Notes |
|------------|------|--------|--------|--------|-------|
| `users` | Auth required (list: public) | Owner only | Owner only | Denied | Public list for username availability |
| `pings` | Auth required | Creator match | Auth required | Creator only | Update too permissive (any auth user can update any ping) |
| `chats` | Auth required | Auth required | Auth required | Denied | |
| `chatMessages` | Auth required | Sender match | Denied | Denied | |
| `chatParticipants` | Auth required | User match | Auth required | Denied | |
| `boosts` | Auth required | User match | Denied | Denied | |
| `blocks` | Auth required | Blocker match | Denied | Blocker only | |
| `reports` | List: auth required | Reporter match | Denied | Denied | |

### Missing Rules

| Collection | Issue |
|------------|-------|
| `moderationActions` | **No rules defined** — Cloud Functions write via admin SDK (bypasses rules), but collection is accessible to anyone who guesses the path |
| `notifications` | **No rules defined** — planned collection from spec (Section 3.1) not yet used |
| `pings.update` | **Too permissive** — any authenticated user can update any ping's fields (should be restricted to creator or admin) |
| Suspension check | **Not enforced** — rules don't check `suspensionStatus` before allowing writes |

---

## Tech Debt (Prioritized)

### Critical (blocks launch or App Store)

| Item | Impact | Effort |
|------|--------|--------|
| **Apple Developer Program membership** | Blocks push notification testing, TestFlight, App Store submission | $99/yr + enrollment time |
| **Privacy policy + Terms of Service** | Required for App Store. Currently a "Coming Soon" placeholder. | Medium (legal text + WebView hosting) |
| **App icon missing** | AppIcon.appiconset has no actual image. Required for App Store. | Low (design + export) |

### High (affects quality or security)

| Item | Impact | Effort |
|------|--------|--------|
| **Suspension not enforced** | `removeContent` writes `suspensionStatus` but iOS app ignores it. No Firestore rule check. Suspended users can still use the app normally. | Medium |
| **Privacy settings not enforced** | `isPrivateProfile` toggle is stored but never checked — private profiles are still fully visible. | Medium |
| **Pings update rule too permissive** | Any authenticated user can update any ping's fields via Firestore. Should restrict to creator or specific fields. | Low |
| **No server-side rate limiting** | Rate limiting is client-side only (UserDefaults). Spec called for server-side enforcement via Cloud Functions. Can be bypassed. | Medium |
| **Geohash empty string** | `Ping.geohash` is always `""`. Nearby notification uses Haversine on `lastKnownLocation` instead of geohash queries. Works but won't scale. | Medium |
| **Content moderation wordlist tiny** | Only 10 words in `moderation_wordlist.txt`. Easily bypassed with misspellings. | Low (find comprehensive list) |
| **`moderationActions` collection unprotected** | No Firestore security rules. Readable by any user who queries it directly. | Low |
| **No admin web dashboard** | Spec (Feature #18) called for a React admin dashboard on Firebase Hosting. Currently: Firebase Console + runbook only. | High |

### Medium (should fix before public beta)

| Item | Impact | Effort |
|------|--------|--------|
| **No empty states** | Blank screens when no pings, no messages, no notifications. | Low |
| **No error states** | Network errors, location denied show no user-facing feedback. | Medium |
| **No chat pagination** | All messages loaded at once. Will degrade with long conversations. | Medium |
| **No image caching** | AsyncImage reloads on every view appearance. | Low |
| **No offline mode UI** | Firestore caches automatically but no visual indicator when offline. | Low |
| **No accessibility labels** | Only 2 accessibility annotations in entire codebase. Screen reader unusable. | Medium |
| **No localization** | Zero localized strings. All English hardcoded. | Medium (if targeting Romanian users) |
| **Notification tap navigation broken** | `PingItOpenPing` posted but never handled — tap doesn't navigate to ping. | Medium |
| **`lastKnownLocation` stale** | Only updated on first map load. Could be hours old. | Low |
| **ProfileViewModel not testable** | Calls Firebase Storage directly. Should use `ImageStorageServicing` protocol. | Low |

### Low (nice to have)

| Item | Impact | Effort |
|------|--------|--------|
| **No Firebase Analytics** | Can't measure adoption, retention, or feature usage. | Low |
| **No Crashlytics** | Can't detect or diagnose production crashes. | Low |
| **No onboarding flow** | New users land on map with no context. | Medium |
| **Custom ping duration** | Only 6h/24h/48h presets. | Low |
| **Password reset uses Firebase default page** | Works but doesn't enforce app's password rules. | Low |
| **Node.js 20 → 22 migration** | Deprecated runtime. Deadline: 2026-10-30. | Low |
| **`firebase-functions` package upgrade** | Outdated with breaking changes. | Medium |
| **GDPR data export** | Spec mentions it, not implemented. `deleteAccount` exists but no export. | Medium |

---

## Spec vs Reality — Gaps

Features the spec promised but aren't implemented:

| Spec Item | Section | Status |
|-----------|---------|--------|
| Admin web dashboard (React, Firebase Hosting) | Phase 1, Feature #18 | **Not built.** Replaced with Firebase Console + runbook. |
| Server-side rate limiting via Cloud Function `createPing` | Phase 0 Technical Deliverables | **Not built.** Client-side only. |
| GDPR data export | SECURITY.md | **Not built.** Only deletion exists. |
| Suspension escalation (warning → 24hr → 7-day → permanent) | SECURITY.md | **Write-only.** No client enforcement, no escalation logic. |
| `userPreferences` collection | Spec Section 3.1 | **Not used.** Preferences stored directly on `users` document. |
| `cities` collection | Spec Section 3.1 | **Not used.** Cluj boundary is client-side GeoJSON. |
| `pingMedia` collection | Spec Section 3.1 | **Not used.** No media attachments on pings (text-only). |
| `follows` collection | Spec Section 3.1 | **Not used.** Correctly deferred to v2. |
| `notifications` collection | Spec Section 3.1 | **Not used.** Push via FCM only, no in-app notification list. |
| Firestore security rules tested | SECURITY.md Pre-Launch Checklist | **Deployed but not unit-tested.** |
| Server-side validation of ping creation | Spec Phase 0 | **Not built.** All validation is client-side. |

---

## What Works Well

- **MVVM architecture is clean** — every ViewModel has a protocol-abstracted service layer, `configure()` pattern, and mock for testing.
- **153 unit tests** across 12 suites — solid coverage of ViewModel logic.
- **Real-time features work** — Firestore snapshot listeners for map, chat, blocks all update instantly.
- **Blocking is robust** — bidirectional, real-time, tested on device. Best-in-class for an MVP.
- **Image moderation pipeline works end-to-end** — upload → Vision API → SafeSearch scores → auto-remove or flag.
- **Clock sync via ServerTime** — all expiration/countdown logic is server-time corrected.
- **Auth flow is production-ready** — password strength, username uniqueness, email verification, forgot password.

---

## Pre-Launch Checklist

From `docs/SECURITY.md` + App Store requirements:

- [x] Account deletion functional (GDPR)
- [ ] GDPR data export functional
- [ ] Privacy policy published in-app
- [ ] Consent screens for location/notifications (location prompt exists, notification prompt exists, but no explicit "we collect this data" screen)
- [x] Firestore security rules deployed
- [ ] Firestore security rules tested (automated)
- [x] Cloud Functions authentication enforced
- [x] Rate limiting working (client-side)
- [ ] Rate limiting working (server-side)
- [x] Content moderation pipeline tested
- [ ] App icon designed and exported
- [ ] TestFlight beta distributed
- [ ] Apple Developer Program enrolled
- [ ] APNs key generated and uploaded to Firebase
- [ ] Push notifications E2E tested
- [ ] Crash reporting integrated
- [ ] Analytics integrated
- [ ] Accessibility audit passed
- [ ] Performance profiled (Instruments)

---

## Recommended Priority for Remaining 60 Days

### Weeks 1-2 (May 2-16): Blockers
1. Enroll in Apple Developer Program ($99)
2. Generate APNs key → upload to Firebase Console → test push notifications
3. Write privacy policy + terms of service (can use generators as starting point)
4. Design and export app icon (1024x1024)
5. Fix Firestore rule: restrict `pings` update to creator
6. Add `moderationActions` Firestore rule (deny client reads)

### Weeks 3-4 (May 16-30): Polish
7. Empty states for map, chat, notifications
8. Error states (network, location denied, rate limit)
9. Onboarding flow (3 screens)
10. Firebase Analytics integration
11. Crashlytics integration
12. Enforce `isPrivateProfile` (hide profile from non-chat participants)
13. Enforce suspension (check on app launch, block actions)
14. Chat message pagination (50 per load)

### Weeks 5-6 (May 30-Jun 13): Beta
15. Custom ping duration (time picker)
16. Accessibility labels on all interactive elements
17. TestFlight build → distribute to 10 Cluj students
18. Collect feedback, fix critical issues
19. Image caching for profile pictures

### Weeks 7-8 (Jun 13-27): Submission
20. App Store Connect metadata (screenshots, description, keywords)
21. Demo video for App Store reviewers
22. Final regression testing
23. Submit to App Store (allow 1-2 weeks for review)

### Deferred (post-thesis)
- Admin web dashboard
- Server-side rate limiting
- GDPR data export
- Suspension escalation logic
- Geohash-based queries (GeoFirestore)
- Node.js 22 migration
- Comprehensive moderation wordlist
- Localization (Romanian)

---

## Environment & Config

| Item | Value |
|------|-------|
| Firebase project | `pingit-dev` |
| Firestore region | `europe-west3` |
| Cloud Functions region | `europe-west3` |
| Storage bucket | `pingit-dev.firebasestorage.app` |
| Admin emails | `trvpapes@gmail.com` |
| iOS target | iOS 26.0+ |
| Swift version | 6.2+ |
| Xcode | Latest |
| Test device | Physical iPhone (Netskope blocks simulator networking) |
| Git branch (current) | `phase1/sprint4` |
| Git main branch | `main` |

---

_This document is a point-in-time snapshot. Verify against current codebase before making decisions._
