# Risk Register

## Technical Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **App Store Rejection** | Medium | High | Follow HIG strictly, TestFlight beta, demo video for reviewers |
| **Firestore Costs Spike** | Low | Medium | Monitor usage dashboard weekly, billing alert at $20/month |
| **Vision API Latency** | Medium | Low | Optimistic publishing (visible immediately), async moderation |
| **Offline Mode Bugs** | Medium | Medium | Test with airplane mode, queue messages for send on reconnect |
| **Location Permission Denied** | High | High | Clear onboarding, fallback to manual Cluj center location |
| **Chat Spam** | High | Medium | Client rate limiting (6 msgs/10sec), user blocking, report system; server-side spam rate limiting still planned |
| **Firestore Listener Memory Leaks** | Medium | High | Detach listeners in `.onDisappear`, test with Instruments |
| **MapKit Performance (100+ Pins)** | Medium | Medium | Pin clustering (Phase 2+), test with simulated high density |
| **GeoFirestore Query Performance** | Low | Medium | Cluj-wide (~15km) queries bounded, geohash limits result set |

## Product Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **Low User Adoption** | Medium | High | Partner with 2-3 Cluj student orgs, campus poster campaign |
| **Empty Map (No Pings)** | High | High | Seed 10 initial pings manually, recruit 20 beta testers |
| **Inappropriate Content** | Medium | Medium | Vision API moderation, keyword filter, <24hr report response |
| **Network Effects Failure** | Medium | High | Focus on single campus (Babeș-Bolyai) for critical mass |
| **Safety Concerns** | Low | High | User blocking, report system, manual review, clear guidelines |
| **Users Create Pings Outside Cluj** | Medium | Low | Client-side GeoJSON check, server-side validation backup |
| **Ping Expiration Not Working** | Low | High | Test cron job with emulators, monitor function execution logs |

## Operational Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **Firestore Costs Exceed Budget** | Low | Medium | Free tier covers expected usage, monitor daily |
| **Vision API Costs Spike** | Low | Low | First 1K images/month free, expected <500/month |
| **Cannot Reproduce Production Bug** | Medium | Medium | Crashlytics captures stack traces, detailed logging |
| **Cloud Functions Silent Failures** | Medium | High | Wrap in try-catch, log errors, monitor Firebase Console |
| **Orphaned Chats** | Low | Medium | Ping deletion, expiration, moderation removal, and account deletion all share backend `pingCleanup`; test cascade paths after every rules/function deploy |
| **User Data Not Deleted (GDPR)** | Low | Critical | Test `deleteAccount` function, verify all collections and username reservations are cleaned |
| **Username Reservation Backfill Missed** | Medium | High | Run one-time migration for existing `users.usernameLowercase` values before relying on strict `usernames/{normalizedUsername}` rules |

## Third-Party Dependencies

| Service | Risk | Mitigation |
|---------|------|------------|
| **Firebase Outage** | Low prob, High impact | Monitor [status dashboard](https://status.firebase.google.com), offline persistence allows reads |
| **Cloud Functions Cold Start** | Medium | 0-2sec latency acceptable for non-critical operations |
| **MapKit API Changes** | Low | MapKit stable, breaking changes rare |
| **APNs Certificate Expiration** | Low | Expires annually, set calendar reminder |
| **Vision API Rate Limiting** | Low | Default quota 1800/min, expected <10/min |
| **Vision API False Positives** | Medium | Provide user appeal, admin manual review queue |

## Weekly Review Checklist
- [ ] Check Firebase Console for cost trends ($0-2/month expected)
- [ ] Review Cloud Functions error logs
- [ ] Test critical flows (create ping, chat, message)
- [ ] Monitor beta tester feedback
- [ ] Update risk status (any new risks?)
- [ ] Verify App Store timeline on track (June 23 submission)

## Recent Risk Updates

**2026-05-06 - Client-owned destructive/counter writes - Mitigated**
- Ping deletion, boosts, chat participants, and reports moved behind Cloud Functions.
- Firestore rules now deny direct client counter/destructive writes for `pings`, `chats`, `boosts`, `chatParticipants`, and `reports`.
- Remaining risk: server-side spam rate limiting is still client-side only.

**2026-05-06 - Username availability without public user listing - Mitigated for new users**
- Added `usernames/{normalizedUsername}` reservation documents.
- Remaining risk: existing users need a backfill migration to reserve their current usernames.

## Risk Log Template
```
**[Date] - [Risk Name] - [Status]**
- What happened
- Impact on project
- Resolution applied
- Lessons learned
```
