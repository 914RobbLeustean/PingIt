# E2E Test Plan — Audit Remediation (2026-05-02)

**Device:** Physical iPhone (Netskope blocks simulator)
**Prerequisites:** Two test accounts (Account A, Account B), both email-verified. Firebase Console access for manual Firestore edits.

---

## 2026-05-06 Addendum — Server-Authoritative Regression Flows

Run these after deploying:

```bash
npm --prefix functions run build
firebase deploy --only functions,firestore:rules --project pingit-dev
```

### A. Ping deletion backend cascade
1. Sign in as Account A and create a ping.
2. Sign in as Account B, join the ping chat, send a message, and boost the ping.
3. Sign back in as Account A and delete the ping.
4. **Expected:** Ping disappears from the map; chat viewers see unavailable/dismiss behavior.
5. **Verify in Firestore:** Ping status is `removed`; associated `chats`, `chatMessages`, `chatParticipants`, and `boosts` are deleted.

### B. Non-creator delete blocked
1. Account A creates a ping.
2. Account B attempts to delete it. If no UI exposes this, call the `deletePing` callable from a test client as Account B.
3. **Expected:** Callable returns `permission-denied`; ping remains active.

### C. Boost once, no optimistic overcount
1. Account A creates a ping.
2. Account B opens the ping and taps **Boost**.
3. **Expected:** Button becomes boosted and count matches the server-returned value.
4. Tap/trigger boost again from Account B.
5. **Expected:** Count does not increment again; only one `boosts/{pingId}_{uid}` document exists.

### D. Chat join/leave idempotency
1. Account B joins Account A's chat.
2. Leave the chat, then rejoin.
3. Background/foreground or navigate away repeatedly to trigger repeated leave cleanup.
4. **Expected:** Participant counts increment once on active join and decrement once on active leave; repeated leave does not show errors or decrement below zero.

### E. Duplicate report UI
1. Account B reports Account A's ping/message once.
2. Report the same ping/message again from Account B.
3. **Expected:** Second attempt shows "You have already reported this content."
4. **Verify in Firestore:** Only one deterministic report document exists: `{accountBUserId}_{targetId}`.

### F. Username reservations
1. Create a new account with a unique username.
2. **Verify in Firestore:** `usernames/{usernameLowercase}` exists with `userId`.
3. Attempt to sign up or rename another account to the same username.
4. **Expected:** App shows username-taken behavior; no public `users` list query is needed.

### G. Direct Firestore writes denied
Using a non-admin authenticated client or rules test harness, attempt direct writes to:
- update/delete `pings/{pingId}`
- create/update/delete `boosts/{boostId}`
- create/update/delete `chatParticipants/{participantId}`
- create `reports/{reportId}`

**Expected:** All direct writes fail with `PERMISSION_DENIED`.

---

## 1. Firestore Rules — Pings Update Lockdown

### 1.1 Boost still works for non-creators
1. Sign in as Account A
2. Create a ping ("Test boost rule")
3. Sign out, sign in as Account B
4. Open the ping, tap **Boost**
5. **Expected:** Boost succeeds, count increments to 1, button shows "Boosted"

### 1.2 Self-boost blocked at rules level
1. Sign in as Account A
2. Open your own ping
3. **Expected:** Boost button is not visible (UI already hides it for creators). This is a defense-in-depth check — if someone bypassed the UI, the rule would reject it.

### 1.3 Arbitrary field update blocked (manual verification)
1. Open Firebase Console → Firestore → `pings` collection
2. Note a ping document's `creatorId`
3. Using the Firebase Console REST API or a test script, attempt to update the ping's `text` field as a different authenticated user
4. **Expected:** Write rejected with `PERMISSION_DENIED`

---

## 2. Suspension Enforcement

### 2.1 Temporarily suspended user sees suspension screen
**Setup:** In Firebase Console, edit Account A's user document:
- Set `suspensionStatus` = `"suspended"`
- Set `suspensionExpiresAt` = a timestamp 24 hours from now

1. Sign in as Account A
2. **Expected:** Brief loading spinner, then full-screen "Account Suspended" view appears
3. **Verify:** Red warning triangle icon, "Account Suspended" title, expiry date formatted correctly, contact email `trvpapes@gmail.com`, "Sign Out" button visible
4. **Verify:** No tab bar, no map, no way to navigate away except Sign Out

### 2.2 Expired suspension allows access
**Setup:** Edit Account A's user document:
- Keep `suspensionStatus` = `"suspended"`
- Set `suspensionExpiresAt` = a timestamp 1 hour in the past

1. Sign in as Account A
2. **Expected:** App loads normally to Map tab (suspension expired)

### 2.3 Permanent suspension (no expiry)
**Setup:** Edit Account A's user document:
- Set `suspensionStatus` = `"suspended"`
- Remove `suspensionExpiresAt` field entirely (or set to null)

1. Sign in as Account A
2. **Expected:** "Account Suspended" screen with "permanently suspended" text (no date shown)

### 2.4 Banned status
**Setup:** Edit Account A's user document:
- Set `suspensionStatus` = `"banned"`

1. Sign in as Account A
2. **Expected:** "Account Suspended" screen (banned users are always blocked regardless of expiry)

### 2.5 Sign Out from suspension screen
1. While on the "Account Suspended" screen, tap **Sign Out**
2. **Expected:** Returns to Welcome/Login screen

### 2.6 Clean up
**Setup:** Remove `suspensionStatus` and `suspensionExpiresAt` from Account A's user document in Firebase Console.

### 2.7 Normal user unaffected
1. Sign in as Account B (no suspension fields)
2. **Expected:** App loads normally, no delay beyond brief loading spinner

---

## 3. Privacy Profile Enforcement

### 3.1 Private profile hides creator identity
1. Sign in as Account A
2. Go to Settings → toggle **Private Profile** ON
3. Create a ping ("Private creator test")
4. Sign out, sign in as Account B
5. Open Account A's ping from the map
6. **Expected:** Creator section shows "Anonymous" with default person icon (no username, no profile picture)
7. **Expected:** Ping text, countdown, boost button, report/block buttons all still visible and functional

### 3.2 Creator sees own identity despite private profile
1. Sign in as Account A (still has Private Profile ON)
2. Open your own ping
3. **Expected:** Your real username and profile picture are shown (not "Anonymous")

### 3.3 Public profile shows identity normally
1. Sign in as Account A → Settings → toggle **Private Profile** OFF
2. Sign out, sign in as Account B
3. Open Account A's ping
4. **Expected:** Account A's real username and profile picture are shown

### 3.4 Chat still shows real identity after joining
1. With Account A having Private Profile ON, Account B opens A's ping
2. PingDetail shows "Anonymous"
3. Tap **Join Chat** → enter the chat
4. **Expected:** Inside the chat, messages from Account A show their real username and avatar (privacy applies only to PingDetailView, not inside chat)

---

## 4. Moderation Wordlist

### 4.1 English profanity blocked
1. Sign in, try to create a ping with text: "this is fucking great"
2. **Expected:** Blocked — error message "This message violates community guidelines."

### 4.2 Romanian profanity blocked
1. Try to create a ping with text: "du-te in muie"
2. **Expected:** Blocked

### 4.3 Case-insensitive matching
1. Try to send a chat message: "You are a RETARD"
2. **Expected:** Blocked

### 4.4 Clean text allowed
1. Create a ping with text: "Study session at the library at 3pm"
2. **Expected:** Ping created successfully

### 4.5 False positive check
1. Create a ping with text: "I love classic art"
2. **Expected:** Allowed (should not be blocked by substring matching — verify "ass" in "classic" does not trigger; the word "ass" was intentionally excluded from the wordlist to avoid this)

---

## 5. Notification Tap Navigation

> **Note:** Push notifications require an APNs key. If you don't have Apple Developer enrollment yet, you can simulate this by manually posting the `PingItOpenPing` notification. Otherwise skip this section and come back after APNs setup.

### 5.1 Notification navigates to ping (if push available)
1. Sign in as Account A on the test device
2. From a second device or Firebase Console, create a ping near Account A's location
3. Account A receives push notification → tap it
4. **Expected:** App opens → Map tab selected → PingDetailView for the notified ping appears

### 5.2 Notification for expired/deleted ping
1. Send a push notification with a `pingId` that no longer exists (or delete the ping before tapping)
2. Tap the notification
3. **Expected:** Map tab selected → alert "This ping is no longer available." → dismiss returns to map

### 5.3 Notification while on different tab
1. Be on the Profile or Settings tab
2. Tap a push notification for a valid ping
3. **Expected:** App switches to Map tab, then navigates to the ping

### 5.4 Manual simulation (if no APNs)
To simulate without real push notifications, add this temporary code in any view's `.onAppear`:
```swift
NotificationCenter.default.post(
    name: .init("PingItOpenPing"),
    object: nil,
    userInfo: ["pingId": "<a-real-ping-id>"]
)
```
Verify navigation works, then remove the temp code.

---

## 6. Empty States

### 6.1 Map with no pings
**Setup:** Either delete all pings in Firestore, or sign in to an account where all pings are from blocked users (so they're all filtered out).

1. Open the Map tab
2. **Expected:** Bottom overlay: "No pings nearby. Be the first to create one!" with `mappin.slash` icon, on a translucent material background

### 6.2 Empty state disappears when ping created
1. While seeing the empty state, tap **Create Ping** and create one
2. **Expected:** Empty state overlay disappears, new ping annotation appears on the map

---

## 7. Location Denied State

### 7.1 Location permission denied
1. Go to iOS Settings → PingIt → Location → set to **Never**
2. Open PingIt → Map tab
3. **Expected:** Top banner: red `location.slash` icon + "Location access denied. Enable in Settings to see your position." + **"Open Settings"** button
4. **Verify:** Map still shows Cluj-Napoca region (default center) — just no user location dot

### 7.2 Open Settings button works
1. Tap **"Open Settings"** in the location denied banner
2. **Expected:** iOS Settings opens to PingIt's settings page
3. Change Location to "While Using" → return to PingIt
4. **Expected:** Banner disappears, user location dot appears on map

### 7.3 Location authorized — no banner
1. With location permission granted, open the Map
2. **Expected:** No location denied banner visible

---

## 8. Chat Message Pagination

### 8.1 Initial load shows most recent messages
**Setup:** In a chat with 60+ messages (create them via rapid messaging or Firestore Console).

1. Open the chat
2. **Expected:** Most recent ~50 messages shown, scrolled to bottom
3. **Expected:** "Load earlier messages" text visible at the top of the message list

### 8.2 Load earlier messages
1. Scroll to the top of the chat
2. Tap **"Load earlier messages"**
3. **Expected:** Spinner appears briefly, then older messages prepend above. Scroll position stays near where you were (doesn't jump to bottom).
4. **Expected:** If fewer than 50 older messages remain, the "Load earlier messages" button disappears

### 8.3 Real-time new messages still arrive
1. With chat open, have Account B send a new message from another device/session
2. **Expected:** New message appears at the bottom in real-time (no page refresh needed)

### 8.4 Short chat (under 50 messages)
1. Open a chat with fewer than 50 messages
2. **Expected:** All messages shown, "Load earlier messages" button is NOT visible

### 8.5 Empty chat
1. Create a new ping, then open its chat before anyone has messaged
2. **Expected:** "No messages yet. Be the first to say something!" empty state shown (same as before)

---

## 9. Error States

### 9.1 BlockedUsersView error display
1. This is hard to trigger naturally. To verify: temporarily add a `throw` in the MockBlockService during development, or check that the `ContentUnavailableView` error template is visually correct by reviewing the code.
2. **Alternative:** Turn on Airplane Mode, go to Settings → Blocked Users
3. **Expected:** If Firestore cached data loads, you see the list. If it fails, you see "Something went wrong" with the error message.

---

## 10. Accessibility (VoiceOver)

### 10.1 Map view
1. Enable VoiceOver (Settings → Accessibility → VoiceOver → ON, or triple-click Side Button)
2. Navigate to Map tab
3. Swipe through elements
4. **Expected:** "Create Ping" button reads as "Create Ping, button"
5. If empty state visible: reads as one combined element "No pings nearby. Be the first to create one!"
6. If location denied banner visible: reads as one combined element with the text and "Open Settings"

### 10.2 Ping detail
1. Open a ping
2. Swipe through
3. **Expected:**
   - Creator section reads as one element: e.g., "john_doe, 2 hours remaining"
   - Boost button reads: "Boost this ping, button. Increases this ping's visibility" (or "Boosted" if already boosted)
   - Boost count reads: "Boost count, 3"
   - Report/Block buttons read their text labels

### 10.3 Chat
1. Open a chat
2. **Expected:**
   - Each message bubble reads as one element: sender + text + time
   - Send button reads: "Send, button. Sends your message"
   - "Load earlier messages" reads as expected

### 10.4 Profile
1. Go to Profile tab
2. **Expected:** Profile picture reads "Profile picture"

### 10.5 Blocked Users
1. Go to Settings → Blocked Users (with at least one blocked user)
2. **Expected:** Each avatar reads "Profile picture". Unblock button reads "Unblock"

### 10.6 Disable VoiceOver when done
Triple-click Side Button or use Settings to turn off VoiceOver.

---

## 11. Regression Checks

These features were NOT changed but should be verified to ensure nothing broke:

### 11.1 Auth flow
- [ ] Register new account works
- [ ] Login works
- [ ] Sign out works
- [ ] Email verification banner appears for unverified users

### 11.2 Core ping operations
- [ ] Create ping (text, location, expiration) works
- [ ] View ping on map works
- [ ] Delete own ping works
- [ ] Ping expiration countdown displays correctly

### 11.3 Chat
- [ ] Join chat works
- [ ] Send message works
- [ ] Real-time messages appear
- [ ] Content moderation blocks profanity in messages

### 11.4 Blocking
- [ ] Block user from ping detail works
- [ ] Blocked user's pings disappear from map
- [ ] Unblock from Settings works
- [ ] Block from chat context menu works

### 11.5 Boost & Hot Pings
- [ ] Boost ping works (non-creator)
- [ ] Double-boost prevented (button disabled after boost)
- [ ] Hot pings show flame icon on map

### 11.6 Settings
- [ ] Notification preference toggles save
- [ ] Privacy toggle saves (and now is enforced — tested in Section 3)
- [ ] Account deletion flow works

---

## Test Execution Log

| # | Test | Pass/Fail | Notes |
|---|------|-----------|-------|
| 1.1 | Boost works for non-creator | | |
| 2.1 | Temp suspension shows screen | | |
| 2.2 | Expired suspension allows access | | |
| 2.3 | Permanent suspension (no expiry) | | |
| 2.4 | Banned status | | |
| 2.5 | Sign out from suspension | | |
| 2.7 | Normal user unaffected | | |
| 3.1 | Private profile hides identity | | |
| 3.2 | Creator sees own identity | | |
| 3.3 | Public profile shows identity | | |
| 3.4 | Chat shows real identity | | |
| 4.1 | English profanity blocked | | |
| 4.2 | Romanian profanity blocked | | |
| 4.3 | Case-insensitive matching | | |
| 4.4 | Clean text allowed | | |
| 4.5 | False positive check | | |
| 5.1 | Notification → ping (if available) | | |
| 5.2 | Notification → expired ping | | |
| 6.1 | Map empty state | | |
| 6.2 | Empty state disappears | | |
| 7.1 | Location denied banner | | |
| 7.2 | Open Settings works | | |
| 7.3 | No banner when authorized | | |
| 8.1 | Initial 50 messages | | |
| 8.2 | Load earlier messages | | |
| 8.3 | Real-time new messages | | |
| 8.4 | Short chat (< 50) | | |
| 8.5 | Empty chat | | |
| 10.1 | VoiceOver — Map | | |
| 10.2 | VoiceOver — Ping detail | | |
| 10.3 | VoiceOver — Chat | | |
| 10.4 | VoiceOver — Profile | | |
| 10.5 | VoiceOver — Blocked Users | | |

---

## Pre-Testing Checklist

- [ ] Deploy updated Firestore rules: `firebase deploy --only firestore:rules`
- [ ] Create composite indexes in Firebase Console:
  - `chatMessages`: `chatId` ASC, `createdAt` DESC
  - `chatMessages`: `chatId` ASC, `createdAt` ASC
- [ ] Build and install app on physical iPhone
- [ ] Have two test accounts ready (both email-verified)
- [ ] Have Firebase Console open for manual Firestore edits (suspension tests)

---

_Estimated testing time: 45–60 minutes_
